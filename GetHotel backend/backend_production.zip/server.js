const express = require('express');
const dotenv = require('dotenv');
const cors = require('cors');
const helmet = require('helmet');
const morgan = require('morgan');
const errorHandler = require('./middleware/error');

dotenv.config();

const app = express();

app.use(cors({ origin: true, credentials: true }));
app.use(express.json({ limit: '50mb' }));
app.use(express.urlencoded({ limit: '50mb', extended: true }));
app.use(morgan('dev'));

// Diagnostic test routes (Matching both with and without /api)
const testHandler = async (req, res) => {
    let dbStatus = 'Checking...';
    try {
        const prisma = require('./config/db');
        await prisma.$connect();
        dbStatus = 'Connected! ✅';
    } catch (err) {
        dbStatus = `Failed: ${err.message} ❌`;
    }
    res.json({ 
        message: 'Backend is ALIVE',
        database: dbStatus,
        path_received: req.path,
        original_url: req.originalUrl
    });
};

app.get('/api/test', testHandler);
app.get('/test', testHandler);
app.get('/', (req, res) => res.json({ message: 'API Root' }));

// Route files
const auth = require('./routes/authRoutes');
const hotels = require('./routes/hotelRoutes');
const bookings = require('./routes/bookingRoutes');
const dailyRates = require('./routes/dailyRateRoutes');
const payments = require('./routes/paymentRoutes');
const partner = require('./routes/partnerRoutes');
const admin = require('./routes/adminRoutes');
const notifications = require('./routes/notificationRoutes');
const messages = require('./routes/messageRoutes');

// Mount routes (Matching both for flexibility)
const mount = (prefix) => {
    app.use(`${prefix}/auth`, auth);
    app.use(`${prefix}/hotels`, hotels);
    app.use(`${prefix}/bookings`, bookings);
    app.use(`${prefix}/daily-rates`, dailyRates);
    app.use(`${prefix}/payments`, payments);
    app.use(`${prefix}/partner`, partner);
    app.use(`${prefix}/admin`, admin);
    app.use(`${prefix}/notifications`, notifications);
    app.use(`${prefix}/messages`, messages);
};

mount('/api');
mount(''); // Also mount at root as fallback

// Error handler
app.use((err, req, res, next) => {
    console.error(`[ERROR] ${req.method} ${req.originalUrl}:`, err);
    res.status(err.status || 500).json({
        success: false,
        error: err.message || 'Server Error',
        path: req.originalUrl
    });
});

const PORT = process.env.PORT || 5000;
app.listen(PORT, () => {
    console.log(`Server running on port ${PORT}`);
});
