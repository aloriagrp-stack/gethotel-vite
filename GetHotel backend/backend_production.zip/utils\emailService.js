const nodemailer = require('nodemailer');

const transporter = nodemailer.createTransport({
    service: 'gmail',
    auth: {
        user: process.env.EMAIL_USER || 'shriyansh@gethotelstays.com',
        pass: process.env.EMAIL_PASS
    }
});

/**
 * Send booking confirmation emails to both customer and hotelier
 */
exports.sendBookingEmails = async (booking) => {
    try {
        const { guestName, guestEmail, hotel, room, checkIn, checkOut, totalPrice, amountPaid } = booking;
        const hotelEmail = hotel.email || hotel.userId?.email || 'admin@gethotelstays.com';
        
        const formatDate = (date) => new Date(date).toLocaleDateString('en-IN', {
            weekday: 'short', day: 'numeric', month: 'short', year: 'numeric'
        });

        const payAtHotel = totalPrice - amountPaid;

        // 1. EMAIL TO CUSTOMER
        const customerMailOptions = {
            from: `"GetHotelStays" <${process.env.EMAIL_USER}>`,
            to: guestEmail,
            subject: `Booking Confirmed: ${hotel.name}`,
            html: `
                <div style="font-family: Arial, sans-serif; max-width: 600px; margin: 0 auto; color: #333;">
                    <div style="background-color: #0f172a; padding: 40px; text-align: center; border-radius: 20px 20px 0 0;">
                        <h1 style="color: #fff; margin: 0; font-size: 24px; text-transform: uppercase; letter-spacing: 2px;">Booking Confirmed</h1>
                    </div>
                    <div style="padding: 40px; border: 1px solid #e2e8f0; border-top: none; border-radius: 0 0 20px 20px;">
                        <p style="font-size: 16px;">Hi <strong>${guestName}</strong>,</p>
                        <p style="font-size: 14px; color: #64748b;">Your luxury stay at <strong>${hotel.name}</strong> has been successfully booked.</p>
                        
                        <div style="background-color: #f8fafc; padding: 25px; border-radius: 15px; margin: 30px 0;">
                            <div style="margin-bottom: 15px; border-bottom: 1px solid #e2e8f0; padding-bottom: 15px;">
                                <span style="font-size: 10px; font-weight: bold; color: #64748b; text-transform: uppercase;">Dates</span><br/>
                                <span style="font-size: 14px; font-weight: bold;">${formatDate(checkIn)} - ${formatDate(checkOut)}</span>
                            </div>
                            <div style="margin-bottom: 15px; border-bottom: 1px solid #e2e8f0; padding-bottom: 15px;">
                                <span style="font-size: 10px; font-weight: bold; color: #64748b; text-transform: uppercase;">Room</span><br/>
                                <span style="font-size: 14px; font-weight: bold;">${room.name}</span>
                            </div>
                            <div>
                                <span style="font-size: 10px; font-weight: bold; color: #64748b; text-transform: uppercase;">Payment Summary</span><br/>
                                <div style="display: flex; justify-content: space-between; margin-top: 5px;">
                                    <span style="font-size: 13px;">Paid Online (18%):</span>
                                    <span style="font-size: 13px; font-weight: bold; color: #10b981;">₹${amountPaid.toLocaleString()}</span>
                                </div>
                                <div style="display: flex; justify-content: space-between; margin-top: 5px;">
                                    <span style="font-size: 13px;">Pay at Hotel (82%):</span>
                                    <span style="font-size: 13px; font-weight: bold; color: #3b82f6;">₹${payAtHotel.toLocaleString()}</span>
                                </div>
                            </div>
                        </div>

                        <div style="text-align: center; margin-top: 40px;">
                            <a href="https://gethotelstays.com/my-bookings" style="background-color: #2563eb; color: #fff; padding: 15px 30px; text-decoration: none; border-radius: 12px; font-weight: bold; font-size: 12px; text-transform: uppercase;">Manage Booking</a>
                        </div>
                    </div>
                    <p style="text-align: center; font-size: 11px; color: #94a3b8; margin-top: 20px;">
                        Need help? Contact us at support@gethotelstays.com
                    </p>
                </div>
            `
        };

        // 2. EMAIL TO HOTELIER
        const hotelierMailOptions = {
            from: `"Booking Alert" <${process.env.EMAIL_USER}>`,
            to: hotelEmail,
            subject: `New Booking Alert: ${guestName} - ${hotel.name}`,
            html: `
                <div style="font-family: Arial, sans-serif; max-width: 600px; margin: 0 auto; color: #333; border: 1px solid #e2e8f0; border-radius: 20px; overflow: hidden;">
                    <div style="background-color: #2563eb; padding: 30px; text-align: center;">
                        <h2 style="color: #fff; margin: 0; text-transform: uppercase; letter-spacing: 1px;">New Booking Received</h2>
                    </div>
                    <div style="padding: 30px;">
                        <p>Hi Admin,</p>
                        <p>You have received a new booking for <strong>${hotel.name}</strong>.</p>
                        
                        <table style="width: 100%; border-collapse: collapse; margin-top: 20px;">
                            <tr>
                                <td style="padding: 10px; border-bottom: 1px solid #f1f5f9; color: #64748b; font-size: 12px;">Customer</td>
                                <td style="padding: 10px; border-bottom: 1px solid #f1f5f9; font-weight: bold; font-size: 14px;">${guestName}</td>
                            </tr>
                            <tr>
                                <td style="padding: 10px; border-bottom: 1px solid #f1f5f9; color: #64748b; font-size: 12px;">Check-in</td>
                                <td style="padding: 10px; border-bottom: 1px solid #f1f5f9; font-weight: bold; font-size: 14px;">${formatDate(checkIn)}</td>
                            </tr>
                            <tr>
                                <td style="padding: 10px; border-bottom: 1px solid #f1f5f9; color: #64748b; font-size: 12px;">Check-out</td>
                                <td style="padding: 10px; border-bottom: 1px solid #f1f5f9; font-weight: bold; font-size: 14px;">${formatDate(checkOut)}</td>
                            </tr>
                            <tr>
                                <td style="padding: 10px; border-bottom: 1px solid #f1f5f9; color: #64748b; font-size: 12px;">Room</td>
                                <td style="padding: 10px; border-bottom: 1px solid #f1f5f9; font-weight: bold; font-size: 14px;">${room.name}</td>
                            </tr>
                        </table>
                        
                        <div style="margin-top: 30px; padding: 15px; background-color: #fff7ed; border: 1px solid #fdba74; border-radius: 10px;">
                            <p style="margin: 0; font-size: 12px; color: #9a3412;"><strong>Important:</strong> Customer has paid the booking fee online. Please collect <strong>₹${payAtHotel.toLocaleString()}</strong> from the guest at the hotel.</p>
                        </div>
                    </div>
                </div>
            `
        };

        await transporter.sendMail(customerMailOptions);
        await transporter.sendMail(hotelierMailOptions);
        console.log("Booking emails sent successfully.");
    } catch (error) {
        console.error("Failed to send booking emails:", error);
    }
};
