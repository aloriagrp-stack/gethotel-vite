const prisma = require('../config/db');

// @desc    Get all hotels
// @route   GET /api/hotels
// @access  Public
exports.getHotels = async (req, res, next) => {
    try {
        const hotels = await prisma.hotel.findMany({
            include: {
                rooms: true
            }
        });
        res.status(200).json({ success: true, count: hotels.length, data: hotels });
    } catch (err) {
        res.status(400).json({ success: false, message: err.message });
    }
};

// @desc    Get single hotel
// @route   GET /api/hotels/:id
// @access  Public
exports.getHotel = async (req, res, next) => {
    try {
        const hotel = await prisma.hotel.findUnique({
            where: { id: parseInt(req.params.id) },
            include: {
                rooms: true,
                reviews: {
                    include: {
                        user: {
                            select: {
                                name: true
                            }
                        }
                    }
                }
            }
        });

        if (!hotel) {
            return res.status(404).json({ success: false, message: 'Hotel not found' });
        }

        res.status(200).json({ success: true, data: hotel });
    } catch (err) {
        res.status(400).json({ success: false, message: err.message });
    }
};

// @desc    Create new hotel
// @route   POST /api/hotels
// @access  Private (Hotel Admin, Super Admin)
exports.createHotel = async (req, res, next) => {
    try {
        // Check if user is hotel_admin or super_admin
        if (req.user.role !== 'hotel_admin' && req.user.role !== 'super_admin') {
            return res.status(403).json({ success: false, message: 'Not authorized to create a hotel' });
        }

        const { 
            name, tagline, description, city, address, pricePerNight, 
            starRating, thumbnail, images, amenities,
            dining, wellness, faqs, safety, policies
        } = req.body;

        const hotel = await prisma.hotel.create({
            data: {
                name,
                tagline,
                description,
                city,
                address,
                pricePerNight: parseFloat(pricePerNight),
                starRating: parseInt(starRating),
                thumbnail,
                images,
                amenities,
                dining,
                wellness,
                faqs,
                safety,
                policies,
                userId: req.user.id
            },
        });

        res.status(201).json({ success: true, data: hotel });
    } catch (err) {
        res.status(400).json({ success: false, message: err.message });
    }
};

// @desc    Update hotel
// @route   PUT /api/hotels/:id
// @access  Private (Hotel Admin, Super Admin)
exports.updateHotel = async (req, res, next) => {
    try {
        const hotelId = parseInt(req.params.id);
        let hotel = await prisma.hotel.findUnique({
            where: { id: hotelId }
        });

        if (!hotel) {
            return res.status(404).json({ success: false, message: 'Hotel not found' });
        }

        // Make sure user is hotel owner or super admin
        if (hotel.userId !== req.user.id && req.user.role !== 'super_admin') {
            return res.status(403).json({ success: false, message: 'Not authorized to update this hotel' });
        }

        hotel = await prisma.hotel.update({
            where: { id: hotelId },
            data: req.body
        });

        res.status(200).json({ success: true, data: hotel });
    } catch (err) {
        res.status(400).json({ success: false, message: err.message });
    }
};

// @desc    Delete hotel
// @route   DELETE /api/hotels/:id
// @access  Private (Hotel Admin, Super Admin)
exports.deleteHotel = async (req, res, next) => {
    try {
        const hotelId = parseInt(req.params.id);
        const hotel = await prisma.hotel.findUnique({
            where: { id: hotelId }
        });

        if (!hotel) {
            return res.status(404).json({ success: false, message: 'Hotel not found' });
        }

        // Make sure user is hotel owner or super admin
        if (hotel.userId !== req.user.id && req.user.role !== 'super_admin') {
            return res.status(403).json({ success: false, message: 'Not authorized to delete this hotel' });
        }

        await prisma.hotel.delete({
            where: { id: hotelId }
        });

        res.status(200).json({ success: true, data: {} });
    } catch (err) {
        res.status(400).json({ success: false, message: err.message });
    }
};

// @desc    Get hotels for logged in admin
// @route   GET /api/hotels/my-hotels
// @access  Private (Hotel Admin, Super Admin)
exports.getMyHotels = async (req, res, next) => {
    try {
        const hotels = await prisma.hotel.findMany({
            where: { userId: req.user.id },
            include: { rooms: true }
        });

        res.status(200).json({
            success: true,
            count: hotels.length,
            data: hotels
        });
    } catch (err) {
        res.status(400).json({ success: false, message: err.message });
    }
};

// @desc    Create review for hotel
// @route   POST /api/hotels/:id/reviews
// @access  Private
exports.createReview = async (req, res, next) => {
    try {
        const hotelId = parseInt(req.params.id);
        const { rating, comment } = req.body;

        // Check if hotel exists
        const hotel = await prisma.hotel.findUnique({
            where: { id: hotelId }
        });

        if (!hotel) {
            return res.status(404).json({ success: false, message: 'Hotel not found' });
        }

        // Check if user has already reviewed this hotel
        const existingReview = await prisma.review.findUnique({
            where: {
                userId_hotelId: {
                    userId: req.user.id,
                    hotelId: hotelId
                }
            }
        });

        if (existingReview) {
            return res.status(400).json({ success: false, message: 'You have already reviewed this hotel' });
        }

        const review = await prisma.review.create({
            data: {
                rating: parseInt(rating),
                comment,
                userId: req.user.id,
                hotelId: hotelId
            },
            include: {
                user: {
                    select: { name: true }
                }
            }
        });

        // Update hotel guestRating and reviewCount
        const reviews = await prisma.review.findMany({
            where: { hotelId: hotelId }
        });

        const totalRating = reviews.reduce((acc, r) => acc + r.rating, 0);
        const avgRating = totalRating / reviews.length;

        await prisma.hotel.update({
            where: { id: hotelId },
            data: {
                guestRating: avgRating,
                reviewCount: reviews.length
            }
        });

        res.status(201).json({ success: true, data: review });
    } catch (err) {
        res.status(400).json({ success: false, message: err.message });
    }
};
