const express = require('express');
const {
    getHotels,
    getHotel,
    createHotel,
    updateHotel,
    deleteHotel,
    getMyHotels,
    createReview
} = require('../controllers/hotelController');

const { getRooms, addRoom, updateRoom, deleteRoom } = require('../controllers/roomController');

const router = express.Router();

const { protect, authorize } = require('../middleware/auth');

// Nested routes for rooms
router.route('/:hotelId/rooms')
    .get(getRooms)
    .post(protect, authorize('hotel_admin', 'super_admin'), addRoom);

router.route('/:hotelId/rooms/:roomId')
    .put(protect, authorize('hotel_admin', 'super_admin'), updateRoom)
    .delete(protect, authorize('hotel_admin', 'super_admin'), deleteRoom);

router.route('/')
    .get(getHotels)
    .post(protect, authorize('hotel_admin', 'super_admin'), createHotel);

router.route('/my-hotels')
    .get(protect, authorize('hotel_admin', 'super_admin'), getMyHotels);

router.route('/:id')
    .get(getHotel)
    .put(protect, authorize('hotel_admin', 'super_admin'), updateHotel)
    .delete(protect, authorize('hotel_admin', 'super_admin'), deleteHotel);

router.route('/:id/reviews')
    .post(protect, createReview);

module.exports = router;
