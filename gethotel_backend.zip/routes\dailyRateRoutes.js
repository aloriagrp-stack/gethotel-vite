const express = require('express');
const router = express.Router();
const { getDailyRates, updateDailyRate } = require('../controllers/dailyRateController');
const { protect, authorize } = require('../middleware/auth');

router.get('/', protect, getDailyRates);
router.post('/update', protect, authorize('hotel_admin'), updateDailyRate);

module.exports = router;
