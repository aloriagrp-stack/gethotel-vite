const prisma = require('../config/db');

// @desc    Create booking
// @route   POST /api/bookings
// @access  Private
exports.createBooking = async (req, res, next) => {
    try {
        const { hotelId, roomId, checkIn, checkOut, totalPrice, totalGuests } = req.body;

        const booking = await prisma.booking.create({
            data: {
                userId: req.user.id,
                hotelId: parseInt(hotelId),
                roomId: parseInt(roomId),
                checkIn: new Date(checkIn),
                checkOut: new Date(checkOut),
                totalPrice: parseFloat(totalPrice),
                totalGuests: parseInt(totalGuests),
                status: 'pending'
            }
        });

        res.status(201).json({ success: true, data: booking });
    } catch (err) {
        res.status(400).json({ success: false, message: err.message });
    }
};

// @desc    Get user's bookings
// @route   GET /api/bookings/my-bookings
// @access  Private
exports.getMyBookings = async (req, res, next) => {
    try {
        const bookings = await prisma.booking.findMany({
            where: { userId: req.user.id },
            include: {
                hotel: true,
                room: true
            },
            orderBy: {
                createdAt: 'desc'
            }
        });

        res.status(200).json({ success: true, count: bookings.length, data: bookings });
    } catch (err) {
        res.status(400).json({ success: false, message: err.message });
    }
};

// @desc    Get all bookings (Super Admin)
// @route   GET /api/bookings
// @access  Private (Super Admin)
exports.getBookings = async (req, res, next) => {
    try {
        const bookings = await prisma.booking.findMany({
            include: { hotel: true, room: true, user: true }
        });

        res.status(200).json({ success: true, count: bookings.length, data: bookings });
    } catch (err) {
        res.status(400).json({ success: false, message: err.message });
    }
};

// @desc    Update booking (Check-in/out)
// @route   PUT /api/bookings/:id
// @access  Private (Hotel Admin, Super Admin)
exports.updateBooking = async (req, res, next) => {
    try {
        const booking = await prisma.booking.update({
            where: { id: parseInt(req.params.id) },
            data: req.body
        });

        res.status(200).json({ success: true, data: booking });
    } catch (err) {
        res.status(400).json({ success: false, message: err.message });
    }
};
