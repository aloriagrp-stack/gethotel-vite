const Razorpay = require('razorpay');
const crypto = require('crypto');
const prisma = require('../config/db');

// Initialize Razorpay lazily or handle missing keys
let razorpay;
try {
    if (process.env.RAZORPAY_KEY_ID && process.env.RAZORPAY_KEY_SECRET) {
        razorpay = new Razorpay({
            key_id: process.env.RAZORPAY_KEY_ID,
            key_secret: process.env.RAZORPAY_KEY_SECRET,
        });
        console.log('Razorpay Initialized');
    } else {
        console.warn('Razorpay keys missing in .env. Payment features will not work.');
    }
} catch (error) {
    console.error('Razorpay Init Error:', error.message);
}

// @desc    Create Razorpay Order
// @route   POST /api/payments/create-order
// @access  Private
exports.createOrder = async (req, res) => {
    const { bookingId } = req.body;

    if (!razorpay) {
        return res.status(500).json({ success: false, message: 'Razorpay is not configured. Please add Key ID and Secret to .env' });
    }

    try {
        const booking = await prisma.booking.findUnique({
            where: { id: parseInt(bookingId) },
            include: { hotel: true }
        });

        if (!booking) {
            return res.status(404).json({ success: false, message: 'Booking not found' });
        }

        // Calculate 18% of total price for online payment
        const amountToPay = Math.round(booking.totalPrice * 0.18 * 100); // Amount in paisa

        const options = {
            amount: amountToPay,
            currency: 'INR',
            receipt: `receipt_booking_${booking.id}`,
        };

        const order = await razorpay.orders.create(options);

        // Update booking with Razorpay Order ID
        await prisma.booking.update({
            where: { id: booking.id },
            data: { razorpayOrderId: order.id }
        });

        res.status(200).json({
            success: true,
            orderId: order.id,
            amount: order.amount,
            currency: order.currency,
            bookingId: booking.id
        });
    } catch (err) {
        console.error(err);
        res.status(500).json({ success: false, message: 'Failed to create order' });
    }
};

// @desc    Verify Payment Signature
// @route   POST /api/payments/verify
// @access  Private
exports.verifyPayment = async (req, res) => {
    const { 
        razorpay_order_id, 
        razorpay_payment_id, 
        razorpay_signature 
    } = req.body;

    const body = razorpay_order_id + "|" + razorpay_payment_id;

    const expectedSignature = crypto
        .createHmac('sha256', process.env.RAZORPAY_KEY_SECRET)
        .update(body.toString())
        .digest('hex');

    const isAuthentic = expectedSignature === razorpay_signature;

    if (isAuthentic) {
        try {
            // Update booking status
            const booking = await prisma.booking.update({
                where: { razorpayOrderId: razorpay_order_id },
                data: {
                    paymentStatus: 'partial', // 18% paid
                    amountPaid: {
                        increment: 0 // We'll calculate actual amount later or just mark as partial
                    },
                    razorpayPaymentId: razorpay_payment_id,
                    status: 'confirmed'
                }
            });

            // Update amountPaid properly
            await prisma.booking.update({
                where: { id: booking.id },
                data: {
                    amountPaid: booking.totalPrice * 0.18
                }
            });

            res.status(200).json({ success: true, message: 'Payment verified successfully' });
        } catch (err) {
            console.error(err);
            res.status(500).json({ success: false, message: 'Payment verified but failed to update booking' });
        }
    } else {
        res.status(400).json({ success: false, message: 'Invalid payment signature' });
    }
};
