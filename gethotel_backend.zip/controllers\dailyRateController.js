const { PrismaClient } = require('@prisma/client');
const prisma = new PrismaClient();

const getDailyRates = async (req, res) => {
    try {
        const { roomId, startDate, endDate } = req.query;
        
        if (!roomId || !startDate || !endDate) {
            return res.status(400).json({ message: "roomId, startDate, and endDate are required" });
        }

        const rates = await prisma.dailyRate.findMany({
            where: {
                roomId: parseInt(roomId),
                date: {
                    gte: new Date(startDate),
                    lte: new Date(endDate)
                }
            }
        });

        res.json({ data: rates });
    } catch (error) {
        console.error(error);
        res.status(500).json({ message: "Server error" });
    }
};

const updateDailyRate = async (req, res) => {
    try {
        const { roomId, date, price, available } = req.body;

        if (!roomId || !date || price === undefined) {
            return res.status(400).json({ message: "roomId, date, and price are required" });
        }

        const updatedRate = await prisma.dailyRate.upsert({
            where: {
                roomId_date: {
                    roomId: parseInt(roomId),
                    date: new Date(date)
                }
            },
            update: {
                price: parseFloat(price),
                available: available !== undefined ? parseInt(available) : undefined
            },
            create: {
                roomId: parseInt(roomId),
                date: new Date(date),
                price: parseFloat(price),
                available: available !== undefined ? parseInt(available) : 1
            }
        });

        res.json({ message: "Rate updated successfully", data: updatedRate });
    } catch (error) {
        console.error(error);
        res.status(500).json({ message: "Server error" });
    }
};

module.exports = {
    getDailyRates,
    updateDailyRate
};
