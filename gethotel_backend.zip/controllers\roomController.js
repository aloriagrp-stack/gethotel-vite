const prisma = require('../config/db');

// @desc    Get rooms for a hotel
// @route   GET /api/hotels/:hotelId/rooms
// @access  Public
exports.getRooms = async (req, res, next) => {
    try {
        const rooms = await prisma.room.findMany({
            where: { hotelId: parseInt(req.params.hotelId) }
        });

        res.status(200).json({ success: true, count: rooms.length, data: rooms });
    } catch (err) {
        res.status(400).json({ success: false, message: err.message });
    }
};

// @desc    Add room to hotel
// @route   POST /api/hotels/:hotelId/rooms
// @access  Private (Hotel Admin, Super Admin)
exports.addRoom = async (req, res, next) => {
    try {
        const hotelId = parseInt(req.params.hotelId);
        
        // Check if hotel exists and user is authorized
        const hotel = await prisma.hotel.findUnique({
            where: { id: hotelId }
        });

        if (!hotel) {
            return res.status(404).json({ success: false, message: 'Hotel not found' });
        }

        if (hotel.userId !== req.user.id && req.user.role !== 'super_admin') {
            return res.status(403).json({ success: false, message: 'Not authorized to add a room to this hotel' });
        }

        const room = await prisma.room.create({
            data: {
                ...req.body,
                hotelId: hotelId,
                pricePerNight: parseFloat(req.body.pricePerNight),
                maxOccupancy: parseInt(req.body.maxOccupancy),
                sizeM2: parseInt(req.body.sizeM2)
            }
        });

        res.status(201).json({ success: true, data: room });
    } catch (err) {
        res.status(400).json({ success: false, message: err.message });
    }
};

// @desc    Update room
// @route   PUT /api/hotels/:hotelId/rooms/:roomId
// @access  Private (Hotel Admin, Super Admin)
exports.updateRoom = async (req, res, next) => {
    try {
        const hotelId = parseInt(req.params.hotelId);
        const roomId = parseInt(req.params.roomId);
        
        const hotel = await prisma.hotel.findUnique({
            where: { id: hotelId }
        });

        if (!hotel) {
            return res.status(404).json({ success: false, message: 'Hotel not found' });
        }

        if (hotel.userId !== req.user.id && req.user.role !== 'super_admin') {
            return res.status(403).json({ success: false, message: 'Not authorized' });
        }

        const room = await prisma.room.update({
            where: { id: roomId },
            data: {
                ...req.body,
                pricePerNight: req.body.pricePerNight ? parseFloat(req.body.pricePerNight) : undefined,
                maxOccupancy: req.body.maxOccupancy ? parseInt(req.body.maxOccupancy) : undefined,
                sizeM2: req.body.sizeM2 ? parseInt(req.body.sizeM2) : undefined
            }
        });

        res.status(200).json({ success: true, data: room });
    } catch (err) {
        res.status(400).json({ success: false, message: err.message });
    }
};

// @desc    Delete room
// @route   DELETE /api/hotels/:hotelId/rooms/:roomId
// @access  Private (Hotel Admin, Super Admin)
exports.deleteRoom = async (req, res, next) => {
    try {
        const hotelId = parseInt(req.params.hotelId);
        const roomId = parseInt(req.params.roomId);
        
        const hotel = await prisma.hotel.findUnique({
            where: { id: hotelId }
        });

        if (!hotel) {
            return res.status(404).json({ success: false, message: 'Hotel not found' });
        }

        if (hotel.userId !== req.user.id && req.user.role !== 'super_admin') {
            return res.status(403).json({ success: false, message: 'Not authorized' });
        }

        await prisma.room.delete({
            where: { id: roomId }
        });

        res.status(200).json({ success: true, data: {} });
    } catch (err) {
        res.status(400).json({ success: false, message: err.message });
    }
};
