:HL["/_next/static/chunks/d3cc8265880cfe8b.css","style"]
:HL["/_next/static/chunks/b884e85aeeb6ebb5.css","style"]
0:{"buildId":"yZQ3-d2ZjINgiJVkJC4IG","tree":{"name":"","paramType":null,"paramKey":"","hasRuntimePrefetch":false,"slots":{"children":{"name":"/_not-found","paramType":null,"paramKey":"/_not-found","hasRuntimePrefetch":false,"slots":{"children":{"name":"__PAGE__","paramType":null,"paramKey":"__PAGE__","hasRuntimePrefetch":false,"slots":null,"isRootLayout":false}},"isRootLayout":false}},"isRootLayout":true},"staleTime":300}
