1:"$Sreact.fragment"
2:I[92825,["/_next/static/chunks/ff1a16fafef87110.js","/_next/static/chunks/d2be314c3ece3fbe.js"],"ClientSegmentRoot"]
3:I[91886,["/_next/static/chunks/b9c3285fce7af18d.js","/_next/static/chunks/8489079dba811216.js","/_next/static/chunks/abdb5fa42445fb54.js","/_next/static/chunks/014f619987e7e6ae.js"],"default"]
4:I[39756,["/_next/static/chunks/ff1a16fafef87110.js","/_next/static/chunks/d2be314c3ece3fbe.js"],"default"]
5:I[37457,["/_next/static/chunks/ff1a16fafef87110.js","/_next/static/chunks/d2be314c3ece3fbe.js"],"default"]
0:{"buildId":"yZQ3-d2ZjINgiJVkJC4IG","rsc":["$","$1","c",{"children":[[["$","script","script-0",{"src":"/_next/static/chunks/014f619987e7e6ae.js","async":true}]],["$","$L2",null,{"Component":"$3","slots":{"children":["$","$L4",null,{"parallelRouterKey":"children","template":["$","$L5",null,{}]}]},"serverProvidedParams":{"params":{},"promises":["$@6"]}}]]}],"loading":null,"isPartial":false}
6:"$0:rsc:props:children:1:props:serverProvidedParams:params"
