module.exports=[67492,(a,b,c)=>{}];

//# sourceMappingURL=_next-internal_server_app_partner-dashboard_reviews_page_actions_2b6a95d0.js.map