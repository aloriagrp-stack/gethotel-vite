module.exports=[87140,(a,b,c)=>{}];

//# sourceMappingURL=_next-internal_server_app_admin_super_finance_page_actions_d6452c56.js.map