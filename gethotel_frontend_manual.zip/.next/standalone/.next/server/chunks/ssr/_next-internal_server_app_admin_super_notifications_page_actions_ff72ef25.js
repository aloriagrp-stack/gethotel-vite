module.exports=[63006,(a,b,c)=>{}];

//# sourceMappingURL=_next-internal_server_app_admin_super_notifications_page_actions_ff72ef25.js.map