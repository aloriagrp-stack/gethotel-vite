module.exports=[21595,(a,b,c)=>{}];

//# sourceMappingURL=_next-internal_server_app_bookings_details_%5Bid%5D_page_actions_7a0aac27.js.map