module.exports=[50279,(a,b,c)=>{}];

//# sourceMappingURL=_next-internal_server_app_admin_super_bookings_page_actions_cf2c5fe3.js.map