module.exports=[8996,(a,b,c)=>{}];

//# sourceMappingURL=_next-internal_server_app_bookings_dispute_%5Bid%5D_page_actions_55578496.js.map