module.exports=[58131,(a,b,c)=>{}];

//# sourceMappingURL=_next-internal_server_app_partner-dashboard_payments_page_actions_2312be14.js.map