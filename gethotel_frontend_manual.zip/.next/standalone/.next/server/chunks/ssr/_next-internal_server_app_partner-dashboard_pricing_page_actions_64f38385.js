module.exports=[880,(a,b,c)=>{}];

//# sourceMappingURL=_next-internal_server_app_partner-dashboard_pricing_page_actions_64f38385.js.map