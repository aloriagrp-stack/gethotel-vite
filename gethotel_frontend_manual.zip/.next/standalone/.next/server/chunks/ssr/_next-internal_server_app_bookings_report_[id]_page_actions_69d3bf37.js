module.exports=[16605,(a,b,c)=>{}];

//# sourceMappingURL=_next-internal_server_app_bookings_report_%5Bid%5D_page_actions_69d3bf37.js.map