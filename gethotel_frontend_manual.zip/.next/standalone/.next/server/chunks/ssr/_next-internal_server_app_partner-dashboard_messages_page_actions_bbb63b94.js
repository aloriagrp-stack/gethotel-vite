module.exports=[67089,(a,b,c)=>{}];

//# sourceMappingURL=_next-internal_server_app_partner-dashboard_messages_page_actions_bbb63b94.js.map