module.exports=[23591,(a,b,c)=>{}];

//# sourceMappingURL=_next-internal_server_app_admin_super_disputes_page_actions_55d2e750.js.map