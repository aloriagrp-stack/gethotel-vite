module.exports=[78389,(a,b,c)=>{}];

//# sourceMappingURL=_next-internal_server_app_hotel_%5Bid%5D_write-review_page_actions_7fa05daf.js.map