module.exports=[97923,(a,b,c)=>{}];

//# sourceMappingURL=_next-internal_server_app_partner-dashboard_frontdesk_page_actions_4aa5a9ce.js.map