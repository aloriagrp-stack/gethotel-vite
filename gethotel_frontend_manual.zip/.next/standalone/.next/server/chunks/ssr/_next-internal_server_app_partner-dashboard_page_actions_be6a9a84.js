module.exports=[52939,(a,b,c)=>{}];

//# sourceMappingURL=_next-internal_server_app_partner-dashboard_page_actions_be6a9a84.js.map