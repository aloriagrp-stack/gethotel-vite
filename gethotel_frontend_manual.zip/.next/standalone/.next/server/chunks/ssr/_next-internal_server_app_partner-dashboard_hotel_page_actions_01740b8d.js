module.exports=[35441,(a,b,c)=>{}];

//# sourceMappingURL=_next-internal_server_app_partner-dashboard_hotel_page_actions_01740b8d.js.map