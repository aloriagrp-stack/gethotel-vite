module.exports=[20415,(a,b,c)=>{}];

//# sourceMappingURL=_next-internal_server_app_booking_invoice_%5Bid%5D_page_actions_4d9bfd7b.js.map