module.exports=[10758,(a,b,c)=>{}];

//# sourceMappingURL=_next-internal_server_app_admin_super_stats_page_actions_8529fdf3.js.map