module.exports=[43327,(a,b,c)=>{}];

//# sourceMappingURL=_next-internal_server_app_admin_super_hotels_%5Bid%5D_page_actions_df22f9ff.js.map