module.exports=[40161,(a,b,c)=>{}];

//# sourceMappingURL=_next-internal_server_app_admin_super_requests_page_actions_07b6c321.js.map