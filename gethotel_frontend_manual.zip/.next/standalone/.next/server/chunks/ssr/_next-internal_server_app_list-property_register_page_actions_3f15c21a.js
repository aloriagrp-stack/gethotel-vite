module.exports=[21543,(a,b,c)=>{}];

//# sourceMappingURL=_next-internal_server_app_list-property_register_page_actions_3f15c21a.js.map