module.exports=[72977,(a,b,c)=>{}];

//# sourceMappingURL=_next-internal_server_app_admin_super_page_actions_1ecccad2.js.map