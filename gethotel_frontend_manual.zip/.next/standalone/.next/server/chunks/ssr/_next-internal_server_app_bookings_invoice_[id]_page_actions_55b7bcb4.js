module.exports=[53214,(a,b,c)=>{}];

//# sourceMappingURL=_next-internal_server_app_bookings_invoice_%5Bid%5D_page_actions_55b7bcb4.js.map