module.exports=[46367,(a,b,c)=>{}];

//# sourceMappingURL=_next-internal_server_app_partner-dashboard_staff_page_actions_1b438aa6.js.map