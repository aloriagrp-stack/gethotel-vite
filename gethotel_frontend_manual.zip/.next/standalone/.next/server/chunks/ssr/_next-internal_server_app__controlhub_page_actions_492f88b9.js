module.exports=[99646,(a,b,c)=>{}];

//# sourceMappingURL=_next-internal_server_app__controlhub_page_actions_492f88b9.js.map