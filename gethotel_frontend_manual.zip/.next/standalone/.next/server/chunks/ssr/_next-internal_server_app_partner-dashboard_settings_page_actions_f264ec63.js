module.exports=[55459,(a,b,c)=>{}];

//# sourceMappingURL=_next-internal_server_app_partner-dashboard_settings_page_actions_f264ec63.js.map