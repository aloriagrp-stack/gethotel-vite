module.exports=[29693,(a,b,c)=>{}];

//# sourceMappingURL=_next-internal_server_app_list-property_page_actions_6df068d6.js.map