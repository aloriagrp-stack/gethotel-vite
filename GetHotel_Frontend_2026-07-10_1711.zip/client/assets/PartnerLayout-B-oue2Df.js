import{a as e}from"./chunk-BNv3lrIs.js";import{t}from"./react-BFwN_vxz.js";import{c as n,i as r,n as i,s as a}from"./chunk-5KNZJZUH-BVkSsnsy.js";import{t as o}from"./jsx-runtime-DweEukaS.js";import{t as s}from"./proxy-DdMZRv-s.js";import{t as c}from"./bed-BN6E9PMu.js";import{t as l}from"./calendar-DQHBFyWv.js";import{t as u}from"./chevron-right-E-JpXqTA.js";import{t as d}from"./circle-x-Bmq6bQqk.js";import{t as f}from"./credit-card-DqvTlVQV.js";import{t as p}from"./layers-CTH6nGqf.js";import{t as m}from"./layout-dashboard-CVvrPILs.js";import{t as h}from"./lock-JKX0oPGJ.js";import{t as g}from"./message-square-DO8rWtqV.js";import{t as _}from"./plus-Cjp38lTH.js";import{t as v}from"./settings-YNWCLELh.js";import{t as y}from"./star-Ci9TJlT1.js";import{t as b}from"./ticket-Cp6mFkfT.js";import{r as x}from"./utils-CIm5q51k.js";import{D as S,E as C,c as w,d as T,f as E,m as D,n as O}from"./index-CWdCxErm.js";var k=e(t(),1),A=o();function j(){let{user:e,loading:t,logout:o}=S(),j=n(),M=a().pathname,[N,P]=(0,k.useState)(!1),[F,I]=(0,k.useState)(!1),[L,R]=(0,k.useState)(!1);(0,k.useEffect)(()=>{if(!t){let t=new URLSearchParams(window.location.search).get(`activeHotelId`);t&&(sessionStorage.setItem(`activeHotelId`,t),localStorage.setItem(`activeHotelId`,t));let n=sessionStorage.getItem(`activeHotelId`)||localStorage.getItem(`activeHotelId`);!e||e.role!==`hotel_admin`?j(`/partner`):n||j(`/partner-select`)}},[e,t,j]);let z=[{id:`dashboard`,label:`Dashboard`,icon:m,href:`/partner-dashboard`},{id:`bookings`,label:`Bookings`,icon:l,href:`/partner-dashboard/bookings`},{id:`hotel`,label:`Property Info`,icon:E,href:`/partner-dashboard/hotel`},{id:`rooms`,label:`Manage Rooms`,icon:c,href:`/partner-dashboard/rooms`},{id:`inventory`,label:`Rates & Inventory`,icon:p,href:`/partner-dashboard/inventory`},{id:`payments`,label:`Earnings`,icon:f,href:`/partner-dashboard/payments`},{id:`coupons`,label:`Promotions`,icon:b,href:`/partner-dashboard/coupons`},{id:`messages`,label:`Messages`,icon:g,href:`/partner-dashboard/messages`},{id:`reviews`,label:`Guest Reviews`,icon:y,href:`/partner-dashboard/reviews`},{id:`channel`,label:`Channel Sync`,icon:D,href:`/partner-dashboard/channel`},{id:`settings`,label:`Settings`,icon:v,href:`/partner-dashboard/settings`},{id:`switch`,label:`Switch Property`,icon:u,href:`/partner-select`}],B=z.find(e=>M===e.href)||z[0],V=()=>{o(),I(!1),j(`/partner`)};return t?(0,A.jsx)(`div`,{className:`min-h-screen flex items-center justify-center bg-slate-50`,children:(0,A.jsx)(`div`,{className:`w-10 h-10 border-4 border-blue-600 border-t-transparent rounded-none animate-spin`})}):(0,A.jsxs)(`div`,{className:`flex min-h-screen bg-[#FAF9F6] text-stone-900 partner-portal-wrapper`,children:[(0,A.jsxs)(`aside`,{className:x(`hidden lg:flex bg-white border-r border-stone-200/80 flex-col fixed inset-y-0 left-0 z-50 transition-all duration-300`,L?`w-24`:`w-72`),children:[(0,A.jsxs)(`div`,{className:`p-8 border-b border-stone-100 relative`,children:[L?null:(0,A.jsxs)(s.div,{initial:{opacity:0,x:-10},animate:{opacity:1,x:0},className:`overflow-hidden whitespace-nowrap`,children:[(0,A.jsxs)(`h1`,{className:`text-xl font-black text-stone-950 tracking-tight`,children:[`GetHotel`,(0,A.jsx)(`span`,{className:`text-stone-900 font-extrabold italic`,children:`Stays`})]}),(0,A.jsx)(`p`,{className:`text-[10px] font-black text-stone-400 uppercase tracking-[0.2em] mt-0.5`,children:`Partner Portal`})]}),(0,A.jsx)(`button`,{onClick:()=>R(!L),className:x(`absolute w-7 h-7 bg-stone-50 border border-stone-200 rounded-none flex items-center justify-center text-stone-400 hover:text-stone-950 hover:bg-white transition-all shadow-none z-[60] cursor-pointer`,L?`left-1/2 -translate-x-1/2 top-6`:`right-6 top-8`),children:(0,A.jsx)(u,{className:x(`w-4 h-4 transition-transform duration-300`,L?``:`rotate-180`)})})]}),(0,A.jsx)(`nav`,{className:`flex-1 p-6 space-y-1 overflow-y-auto custom-scrollbar`,children:z.map(t=>{let n=t.icon,r=M===t.href,a=e?.role===`hotel_admin`&&(!e.hotel||e.hotel.length===0),o=e?.partnerRequestStatus===`rejected`,s=a||o;return(0,A.jsxs)(i,{to:s?`#`:t.href,className:x(`w-full flex items-center justify-between px-4 py-3.5 rounded-none text-sm font-bold group transition-all`,r?`bg-stone-900 text-white shadow-none`:`text-stone-500 hover:text-stone-900 hover:bg-stone-50`,L&&`justify-center`,s&&`opacity-50 cursor-not-allowed`),onClick:e=>{s&&e.preventDefault()},title:L?t.label:``,children:[(0,A.jsxs)(`div`,{className:`flex items-center gap-3`,children:[(0,A.jsx)(n,{className:x(`w-5 h-5 shrink-0`,r?`text-white`:`text-stone-400 group-hover:text-stone-900`)}),!L&&(0,A.jsx)(`span`,{children:t.label})]}),s&&!L&&(0,A.jsx)(h,{className:`w-3 h-3 text-stone-300`}),r&&!L&&(0,A.jsx)(`div`,{className:`w-1.5 h-1.5 rounded-none bg-white/70`})]},t.id)})})]}),(0,A.jsxs)(`div`,{className:x(`flex-1 flex flex-col min-h-screen transition-all duration-300 min-w-0`,L?`lg:ml-24`:`lg:ml-72`),children:[(0,A.jsxs)(`header`,{className:`lg:hidden h-20 bg-white border-b border-stone-200 px-6 flex items-center justify-between sticky top-0 z-40`,children:[(0,A.jsxs)(`div`,{className:`flex items-center gap-3`,children:[(0,A.jsx)(`div`,{className:`w-10 h-10 bg-stone-900 rounded-none flex items-center justify-center text-white`,children:(0,A.jsx)(E,{className:`w-6 h-6`})}),(0,A.jsxs)(`div`,{children:[(0,A.jsx)(`h1`,{className:`text-sm font-black uppercase tracking-wider text-stone-950`,children:B?B.label:`Partner Portal`}),(0,A.jsx)(`p`,{className:`text-[9px] font-bold text-stone-400 uppercase tracking-widest`,children:`Partner Dashboard`})]})]}),(0,A.jsx)(`button`,{onClick:()=>P(!0),className:`p-2.5 bg-stone-50 rounded-none text-stone-600 border border-stone-200 cursor-pointer`,children:(0,A.jsx)(w,{className:`w-6 h-6`})})]}),N&&(0,A.jsx)(`div`,{onClick:()=>P(!1),className:`fixed inset-0 bg-stone-950/60 backdrop-blur-sm z-[60] lg:hidden`,children:(0,A.jsxs)(`div`,{onClick:e=>e.stopPropagation(),className:`w-80 h-full bg-white flex flex-col animate-slide-right`,children:[(0,A.jsxs)(`div`,{className:`p-6 border-b border-stone-100 flex items-center justify-between`,children:[(0,A.jsxs)(`div`,{className:`flex items-center gap-3`,children:[(0,A.jsx)(`div`,{className:`w-8 h-8 bg-stone-900 rounded-none flex items-center justify-center text-white`,children:(0,A.jsx)(E,{className:`w-5 h-5`})}),(0,A.jsx)(`span`,{className:`font-black text-stone-950 uppercase tracking-tight`,children:`Menu`})]}),(0,A.jsx)(`button`,{onClick:()=>P(!1),className:`p-2 text-stone-400 cursor-pointer`,children:(0,A.jsx)(O,{className:`w-6 h-6`})})]}),(0,A.jsx)(`nav`,{className:`flex-1 p-4 space-y-1 overflow-y-auto`,children:z.map(e=>{let t=e.icon,n=M===e.href;return(0,A.jsxs)(i,{to:e.href,onClick:()=>P(!1),className:x(`flex items-center gap-3 px-4 py-4 rounded-none text-sm font-bold transition-all`,n?`bg-stone-900 text-white`:`text-stone-500 hover:bg-stone-50`),children:[(0,A.jsx)(t,{className:`w-5 h-5`}),e.label]},e.id)})}),(0,A.jsx)(`div`,{className:`p-6 border-t border-stone-100`,children:(0,A.jsxs)(`button`,{onClick:()=>{I(!0),P(!1)},className:`w-full flex items-center gap-3 text-red-600 font-bold text-sm cursor-pointer`,children:[(0,A.jsx)(T,{className:`w-5 h-5`}),` Logout`]})})]})}),(0,A.jsx)(`main`,{className:`flex-1 p-6 lg:p-10 min-w-0 overflow-x-hidden`,children:e?.partnerRequestStatus===`rejected`?(0,A.jsxs)(`div`,{className:`flex flex-col items-center justify-center min-h-[80vh] text-center space-y-8 -mt-20 px-8`,children:[(0,A.jsx)(s.div,{initial:{opacity:0,scale:.5},animate:{opacity:1,scale:1},className:`w-24 h-24 bg-red-50 text-red-600 rounded-none flex items-center justify-center mx-auto mb-6`,children:(0,A.jsx)(d,{className:`w-12 h-12`})}),(0,A.jsxs)(`div`,{className:`max-w-2xl space-y-6`,children:[(0,A.jsxs)(`h2`,{className:`text-5xl md:text-6xl font-black text-slate-900 tracking-tighter leading-none italic uppercase`,children:[`Application `,(0,A.jsx)(`span`,{className:`text-red-600`,children:`Rejected`})]}),(0,A.jsx)(`p`,{className:`text-slate-500 font-bold text-lg md:text-xl leading-relaxed`,children:`We regret to inform you that your application to become a hotel partner has been declined by our administration.`})]}),(0,A.jsx)(`div`,{className:`p-6 bg-red-50/50 border border-red-100 rounded-none max-w-md w-full`,children:(0,A.jsx)(`p`,{className:`text-[13px] text-red-700 font-black uppercase tracking-widest leading-relaxed`,children:`This account has been permanently disabled. You will no longer be able to access the partner portal.`})}),(0,A.jsxs)(`button`,{onClick:V,className:`max-w-md w-full py-5 bg-slate-900 text-white rounded-none font-black text-sm uppercase tracking-widest hover:bg-black transition-all shadow-xl shadow-slate-200 flex items-center justify-center gap-3 group`,children:[(0,A.jsx)(T,{className:`w-5 h-5 group-hover:-translate-x-1 transition-transform`}),`Exit Portal Permanently`]})]}):e?.role===`hotel_admin`&&(!e.hotel||e.hotel.length===0)?(0,A.jsx)(`div`,{className:`flex flex-col items-center justify-center min-h-[80vh] text-center space-y-8 -mt-20`,children:(0,A.jsxs)(`div`,{className:`max-w-2xl space-y-6`,children:[(0,A.jsx)(s.div,{initial:{opacity:0,y:20},animate:{opacity:1,y:0},transition:{duration:.6,ease:`easeOut`},children:(0,A.jsxs)(`h2`,{className:`text-5xl md:text-6xl font-black text-slate-900 tracking-tighter leading-none italic uppercase`,children:[`Approval `,(0,A.jsx)(`span`,{className:`text-blue-600`,children:`Pending`})]})}),(0,A.jsx)(s.p,{initial:{opacity:0,y:20},animate:{opacity:1,y:0},transition:{duration:.6,delay:.2,ease:`easeOut`},className:`text-slate-500 font-medium text-lg md:text-xl leading-relaxed px-4`,children:`Your account is currently under review by our administration team. We are verifying your property details to ensure the best experience for our guests.`}),(0,A.jsxs)(s.div,{initial:{opacity:0,scale:.9},animate:{opacity:1,scale:1},transition:{duration:.4,delay:.4},className:`pt-10 flex flex-col items-center gap-6`,children:[(0,A.jsxs)(`div`,{className:`px-8 py-4 bg-emerald-50 text-emerald-600 rounded-none text-sm font-black uppercase tracking-[0.2em] flex items-center gap-4 border border-emerald-100/50 shadow-sm shadow-emerald-50`,children:[(0,A.jsx)(`div`,{className:`w-3 h-3 bg-emerald-500 rounded-none animate-ping`}),`Review in Progress`]}),(0,A.jsx)(`p`,{className:`text-[13px] text-slate-400 font-bold uppercase tracking-widest`,children:`You will receive an email once your account is fully enabled.`})]})]})}):(0,A.jsx)(r,{})}),(0,A.jsx)(`div`,{className:`lg:hidden fixed bottom-6 right-6 z-40`,children:(0,A.jsx)(`button`,{className:`w-14 h-14 bg-blue-600 rounded-none text-white shadow-2xl flex items-center justify-center hover:scale-110 active:scale-95 transition-all`,children:(0,A.jsx)(_,{className:`w-8 h-8`})})})]}),(0,A.jsx)(C,{children:F&&(0,A.jsxs)(A.Fragment,{children:[(0,A.jsx)(s.div,{initial:{opacity:0},animate:{opacity:1},exit:{opacity:0},className:`fixed inset-0 bg-slate-950/60 backdrop-blur-md z-[200]`,onClick:()=>I(!1)}),(0,A.jsx)(s.div,{initial:{opacity:0,scale:.9,y:20},animate:{opacity:1,scale:1,y:0},exit:{opacity:0,scale:.9,y:20},className:`fixed top-1/2 left-1/2 -translate-x-1/2 -translate-y-1/2 w-[90%] max-w-md bg-white rounded-none z-[210] overflow-hidden shadow-2xl border border-slate-100`,children:(0,A.jsxs)(`div`,{className:`p-10 text-center`,children:[(0,A.jsxs)(`div`,{className:`w-20 h-20 bg-red-50 rounded-none flex items-center justify-center mx-auto mb-6 relative`,children:[(0,A.jsx)(T,{className:`w-8 h-8 text-red-600`}),(0,A.jsx)(s.div,{animate:{scale:[1,1.2,1],opacity:[.2,.4,.2]},transition:{duration:2,repeat:1/0},className:`absolute inset-0 bg-red-500/10 rounded-none blur-xl`})]}),(0,A.jsxs)(`h3`,{className:`text-2xl font-black text-slate-950 mb-3 tracking-tight`,children:[`Ready to `,(0,A.jsx)(`span`,{className:`text-red-600 italic`,children:`Leave?`})]}),(0,A.jsx)(`p`,{className:`text-slate-500 font-bold mb-10 leading-relaxed`,children:`Are you sure you want to logout from Partner Portal?`}),(0,A.jsxs)(`div`,{className:`flex flex-col sm:flex-row gap-3`,children:[(0,A.jsx)(`button`,{onClick:V,className:`flex-1 py-4 bg-red-600 text-white rounded-none font-black shadow-xl shadow-red-600/20 hover:bg-red-700 transition-all hover:scale-105 active:scale-95`,children:`Yes, Logout`}),(0,A.jsx)(`button`,{onClick:()=>I(!1),className:`flex-1 py-4 bg-slate-100 text-slate-900 rounded-none font-black hover:bg-slate-200 transition-all active:scale-95`,children:`No, Stay`})]})]})})]})}),(0,A.jsx)(`style`,{children:`
                .custom-scrollbar::-webkit-scrollbar {
                    width: 4px;
                    height: 4px;
                }
                .custom-scrollbar::-webkit-scrollbar-track {
                    background: transparent;
                }
                .custom-scrollbar::-webkit-scrollbar-thumb {
                    background: #E7E5E4;
                    border-radius: 0px;
                }
                .custom-scrollbar::-webkit-scrollbar-thumb:hover {
                    background: #D6D3D1;
                }
                @keyframes slide-right {
                    from { transform: translateX(-100%); }
                    to { transform: translateX(0); }
                }
                .animate-slide-right {
                    animation: slide-right 0.3s cubic-bezier(0.16, 1, 0.3, 1);
                }

                /* Off-White Minimalism Global Overrides */
                .partner-portal-wrapper {
                    font-family: 'Inter', system-ui, -apple-system, sans-serif !important;
                }
                .partner-portal-wrapper h1, 
                .partner-portal-wrapper h2, 
                .partner-portal-wrapper h3, 
                .partner-portal-wrapper h4, 
                .partner-portal-wrapper h5 {
                    font-family: 'Inter', system-ui, -apple-system, sans-serif !important;
                    letter-spacing: -0.03em !important;
                    color: #1C1917 !important;
                }

                /* Overriding typical panel cards to premium, border-only minimalist panels */
                .partner-portal-wrapper .bg-white {
                    background-color: #FFFFFF !important;
                    border: 1px solid #E7E5E4 !important;
                    border-radius: 0px !important;
                    box-shadow: 0 1px 2px 0 rgba(0, 0, 0, 0.01) !important;
                }

                /* Neutralizing colorful cards and stats boxes */
                .partner-portal-wrapper .shadow-premium,
                .partner-portal-wrapper .shadow-sm {
                    box-shadow: 0 1px 2px 0 rgba(0, 0, 0, 0.01) !important;
                }

                /* Solid black / dark stone minimalist primary action buttons */
                .partner-portal-wrapper button.bg-blue-600,
                .partner-portal-wrapper a.bg-blue-600,
                .partner-portal-wrapper .bg-blue-600:not(.nav-active-dot) {
                    background-color: #1C1917 !important;
                    color: #FFFFFF !important;
                    border-radius: 0px !important;
                    border: 1px solid #1C1917 !important;
                    box-shadow: none !important;
                    transition: all 0.2s ease !important;
                    cursor: pointer;
                }
                .partner-portal-wrapper button.bg-blue-600:hover,
                .partner-portal-wrapper a.bg-blue-600:hover {
                    background-color: #2E2A27 !important;
                    border-color: #2E2A27 !important;
                }

                /* Text colors - Override main branding blue with dark stone for text links */
                .partner-portal-wrapper .text-blue-600 {
                    color: #1C1917 !important;
                }
                .partner-portal-wrapper .hover:text-blue-600:hover {
                    color: #000000 !important;
                }

                /* Muted, neutral background for stats icons instead of saturated blue/green/amber/purple */
                .partner-portal-wrapper .bg-blue-50,
                .partner-portal-wrapper .bg-emerald-50,
                .partner-portal-wrapper .bg-amber-50,
                .partner-portal-wrapper .bg-purple-50 {
                    background-color: #F5F5F4 !important;
                    color: #44403C !important;
                    border-radius: 0px !important;
                }
                .partner-portal-wrapper .text-blue-600,
                .partner-portal-wrapper .text-emerald-600,
                .partner-portal-wrapper .text-amber-600,
                .partner-portal-wrapper .text-purple-600 {
                    color: #44403C !important;
                }

                /* Inputs & selections styling override */
                .partner-portal-wrapper input,
                .partner-portal-wrapper select,
                .partner-portal-wrapper textarea {
                    background-color: #FAF9F6 !important;
                    border: 1px solid #E7E5E4 !important;
                    border-radius: 0px !important;
                    color: #1C1917 !important;
                    padding: 8px 12px !important;
                    font-size: 13px !important;
                }
                .partner-portal-wrapper input:focus,
                .partner-portal-wrapper select:focus,
                .partner-portal-wrapper textarea:focus {
                    border-color: #1C1917 !important;
                    outline: none !important;
                    box-shadow: 0 0 0 1px #1C1917 !important;
                }

                /* Muted secondary buttons */
                .partner-portal-wrapper .border-slate-200,
                .partner-portal-wrapper .border-slate-100 {
                    border-color: #E7E5E4 !important;
                }

                /* Clean, flat tables override */
                .partner-portal-wrapper table {
                    border-collapse: collapse !important;
                    width: 100% !important;
                }
                .partner-portal-wrapper th {
                    background-color: #FAF9F6 !important;
                    color: #57534E !important;
                    font-size: 11px !important;
                    font-weight: 800 !important;
                    letter-spacing: 0.08em !important;
                    text-transform: uppercase !important;
                    border-bottom: 2px solid #E7E5E4 !important;
                    padding: 14px 18px !important;
                    text-align: left !important;
                }
                .partner-portal-wrapper td {
                    border-bottom: 1px solid #FAF9F6 !important;
                    padding: 14px 18px !important;
                    background-color: #FFFFFF !important;
                    color: #44403C !important;
                    font-size: 13px !important;
                }
                .partner-portal-wrapper tr:hover td {
                    background-color: #FAF9F6 !important;
                }
            `})]})}export{j as default};