"use client";

import { useState, useEffect } from "react";
import Hero from "@/components/home/Hero";
import TrendingHotels from "@/components/home/TrendingHotels";
import WhyGetHotel from "@/components/home/WhyGetHotel";
import ExploreByDestinations from "@/components/home/ExploreByDestinations";
import FeaturedCollections from "@/components/home/FeaturedCollections";
import { hotelApi } from "@/lib/api";
import { hotels as mockHotels } from "@/data/hotels";

export default function HomePage() {
  const [trendingHotels, setTrendingHotels] = useState([]);

  useEffect(() => {
    const fetchTrending = async () => {
      try {
        const res = await hotelApi.getHotels();
        if (res.data && res.data.length > 0) {
            setTrendingHotels(res.data.slice(0, 12));
        } else {
            setTrendingHotels(mockHotels.slice(0, 12) as any);
        }
      } catch (err) {
        console.error("Failed to fetch trending hotels:", err);
        setTrendingHotels(mockHotels.slice(0, 12) as any);
      }
    };
    fetchTrending();
  }, []);

  return (
    <main className="flex flex-col">
      <Hero />
      <TrendingHotels hotels={trendingHotels} />
      <ExploreByDestinations />
      <FeaturedCollections />
      <WhyGetHotel />
    </main>
  );
}
