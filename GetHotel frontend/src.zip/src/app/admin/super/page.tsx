"use client";

import { useState, useEffect } from "react";
import { useRouter } from "next/navigation";
import { useAuth } from "@/context/AuthContext";
import { hotelApi } from "@/lib/api";
import { 
    LayoutDashboard, Hotel, Users, 
    BarChart3, Settings, LogOut, 
    Bell, Search, Plus, Filter,
    CheckCircle2, XCircle, Clock,
    CreditCard, TrendingUp, MoreVertical,
    ArrowUpRight, ArrowDownRight, Globe, ChevronRight, Loader2
} from "lucide-react";
import { cn } from "@/lib/utils";
import Image from "next/image";

export default function SuperAdminDashboard() {
    const [activeTab, setActiveTab] = useState("overview");
    const { user, loading: authLoading } = useAuth();
    const router = useRouter();

    const [hotels, setHotels] = useState<any[]>([]);
    const [loading, setLoading] = useState(true);

    // Auth Protection
    useEffect(() => {
        if (!authLoading && (!user || user.role !== 'super_admin')) {
            router.push('/login');
        }
    }, [user, authLoading, router]);

    // Fetch Data
    useEffect(() => {
        const fetchAllData = async () => {
            try {
                setLoading(true);
                const res = await hotelApi.getHotels();
                setHotels(res.data);
            } catch (err) {
                console.error("Super Admin fetch failed", err);
            } finally {
                setLoading(false);
            }
        };
        if (user?.role === 'super_admin') fetchAllData();
    }, [user]);

    const stats = [
        { label: "Total Revenue", value: "₹" + (hotels.length * 15400).toLocaleString(), trend: "+12.5%", isUp: true, icon: CreditCard },
        { label: "Total Hotels", value: hotels.length.toString(), trend: "+4", isUp: true, icon: Hotel },
        { label: "Active Users", value: "8,204", trend: "+18%", isUp: true, icon: Users },
        { label: "Bookings", value: "482", trend: "-2%", isUp: false, icon: BarChart3 },
    ];

    if (authLoading || loading) {
        return (
            <div className="min-h-screen flex items-center justify-center bg-slate-50">
                <Loader2 className="w-10 h-10 animate-spin text-brand-600" />
            </div>
        );
    }

    const navItems = [
        { id: "overview", label: "Dashboard", icon: LayoutDashboard },
        { id: "hotels", label: "Hotels", icon: Hotel },
        { id: "users", label: "Users", icon: Users },
        { id: "analytics", label: "Stats", icon: BarChart3 },
        { id: "finance", label: "Billing", icon: CreditCard },
        { id: "settings", label: "Settings", icon: Settings },
    ];

    return (
        <div className="flex min-h-screen bg-slate-50 font-sans">
            
            {/* Sidebar - Sharp Edges */}
            <aside className="w-64 bg-slate-900 text-white flex flex-col hidden lg:flex border-r border-slate-800">
                <div className="p-6 border-b border-slate-800">
                    <h1 className="text-xl font-bold tracking-tight uppercase">
                        Admin<span className="text-slate-400">Hub</span>
                    </h1>
                </div>

                <nav className="flex-1 p-4 space-y-1">
                    {navItems.map((item) => {
                        const Icon = item.icon;
                        return (
                            <button
                                key={item.id}
                                onClick={() => setActiveTab(item.id)}
                                className={cn(
                                    "w-full flex items-center gap-3 px-4 py-3 rounded text-xs font-bold uppercase tracking-wider transition-none",
                                    activeTab === item.id 
                                        ? "bg-slate-800 text-white border-l-4 border-brand-500" 
                                        : "text-slate-400 hover:bg-slate-800 hover:text-white"
                                )}
                            >
                                <Icon className="w-4 h-4" />
                                {item.label}
                            </button>
                        );
                    })}
                </nav>

                <div className="p-4 border-t border-slate-800">
                    <button className="flex items-center gap-3 px-4 py-2 text-slate-500 hover:text-red-400 text-xs font-bold uppercase tracking-wider">
                        <LogOut className="w-4 h-4" /> Logout
                    </button>
                </div>
            </aside>

            {/* Main Content */}
            <main className="flex-1 overflow-y-auto">
                <div className="p-8">
                    <header className="flex flex-col md:flex-row md:items-center justify-between gap-6 mb-8 border-b border-slate-200 pb-8">
                        <div>
                            <h2 className="text-2xl font-bold text-slate-900 uppercase tracking-tight">System Overview</h2>
                            <p className="text-slate-500 text-xs font-medium">Monitoring platform statistics and property requests.</p>
                        </div>
                        <div className="flex items-center gap-3">
                            <div className="relative">
                                <Search className="absolute left-3 top-1/2 -translate-y-1/2 w-4 h-4 text-slate-400" />
                                <input 
                                    type="text"
                                    placeholder="Search..."
                                    className="pl-10 pr-4 py-2 bg-white border border-slate-200 rounded-sm w-64 focus:outline-none focus:border-slate-400 font-medium text-xs shadow-sm"
                                />
                            </div>
                            <button className="p-2 bg-white border border-slate-200 rounded-sm hover:bg-slate-50 relative shadow-sm">
                                <Bell className="w-4 h-4 text-slate-600" />
                            </button>
                        </div>
                    </header>

                    {/* Stats Grid - Rectangular & Sharp */}
                    <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-4 mb-8">
                        {stats.map((stat) => {
                            const Icon = stat.icon;
                            return (
                                <div key={stat.label} className="bg-white p-5 border border-slate-200 shadow-sm flex flex-col justify-between">
                                    <div className="flex justify-between items-start mb-4">
                                        <div className="text-slate-400">
                                            <Icon className="w-5 h-5" />
                                        </div>
                                        <span className={cn(
                                            "text-[10px] font-bold px-2 py-0.5 rounded-sm",
                                            stat.isUp ? "bg-emerald-100 text-emerald-700" : "bg-red-100 text-red-700"
                                        )}>
                                            {stat.trend}
                                        </span>
                                    </div>
                                    <div>
                                        <p className="text-slate-400 font-bold text-[10px] uppercase tracking-wider mb-1">{stat.label}</p>
                                        <h3 className="text-2xl font-bold text-slate-900 tracking-tight">{stat.value}</h3>
                                    </div>
                                </div>
                            );
                        })}
                    </div>

                    <div className="grid grid-cols-1 lg:grid-cols-3 gap-6">
                        {/* Table Style List */}
                        <div className="lg:col-span-2 bg-white border border-slate-200 shadow-sm overflow-hidden">
                            <div className="px-6 py-4 border-b border-slate-100 bg-slate-50/50 flex items-center justify-between">
                                <h3 className="text-sm font-bold text-slate-900 uppercase tracking-wider">Property Management</h3>
                                <button className="text-[10px] font-bold text-slate-500 uppercase tracking-widest border border-slate-200 px-3 py-1 hover:bg-white transition-all">
                                    View Database
                                </button>
                            </div>
                            <div className="divide-y divide-slate-100">
                                {hotels.slice(0, 5).map((hotel) => (
                                    <div key={hotel.id} className="px-6 py-4 flex items-center justify-between hover:bg-slate-50 transition-none">
                                        <div className="flex items-center gap-4">
                                            <div className="w-10 h-10 border border-slate-100 bg-slate-100 shrink-0">
                                                <Image src={hotel.thumbnail} alt={hotel.name} width={40} height={40} className="object-cover w-full h-full grayscale" />
                                            </div>
                                            <div className="text-left">
                                                <h4 className="font-bold text-slate-900 text-sm truncate w-40">{hotel.name}</h4>
                                                <p className="text-[10px] text-slate-400 font-bold uppercase tracking-tight">{hotel.city}</p>
                                            </div>
                                        </div>
                                        <div className="flex gap-2">
                                            <button className="px-3 py-1.5 bg-emerald-600 text-white text-[10px] font-bold uppercase rounded-sm hover:bg-emerald-700">Approve</button>
                                            <button className="px-3 py-1.5 border border-slate-200 text-slate-400 text-[10px] font-bold uppercase rounded-sm hover:bg-slate-50">Reject</button>
                                        </div>
                                    </div>
                                ))}
                            </div>
                        </div>

                        {/* Side Actions List */}
                        <div className="space-y-6">
                            <div className="bg-white border border-slate-200 shadow-sm p-6">
                                <h3 className="text-sm font-bold text-slate-900 uppercase tracking-wider mb-6 pb-2 border-b border-slate-100">System Actions</h3>
                                <div className="space-y-2">
                                    <button className="w-full py-3 bg-slate-900 text-white font-bold text-[10px] uppercase tracking-widest rounded-sm hover:bg-slate-800 transition-none flex items-center justify-center gap-2">
                                        <Plus className="w-3 h-3" /> New Property
                                    </button>
                                    <button className="w-full py-3 border border-slate-200 text-slate-600 font-bold text-[10px] uppercase tracking-widest rounded-sm hover:bg-slate-50 transition-none flex items-center justify-center gap-2">
                                        <Globe className="w-3 h-3" /> Platform Logs
                                    </button>
                                </div>
                            </div>

                            <div className="bg-white border border-slate-200 shadow-sm p-6">
                                <h3 className="text-sm font-bold text-slate-900 uppercase tracking-wider mb-6 pb-2 border-b border-slate-100">Recent Logs</h3>
                                <div className="space-y-4">
                                    {[
                                        { msg: "Hotel Request #8402", time: "12:04 PM" },
                                        { msg: "System Sync Completed", time: "11:55 AM" },
                                        { msg: "Billing Exported", time: "10:30 AM" },
                                    ].map((item) => (
                                        <div key={item.msg} className="flex justify-between items-center text-left">
                                            <p className="text-[11px] font-bold text-slate-600">{item.msg}</p>
                                            <span className="text-[9px] font-medium text-slate-400">{item.time}</span>
                                        </div>
                                    ))}
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
            </main>
        </div>
    );
}
