"use client";

import Link from "next/link";
import { Shield, Hotel, ArrowRight } from "lucide-react";

export default function AdminEntryPage() {
    return (
        <div className="min-h-screen bg-[#F4F9FF] flex items-center justify-center p-6">
            <div className="max-w-4xl w-full">
                <div className="text-center mb-16">
                    <p className="text-[10px] font-black uppercase tracking-[0.4em] text-brand-600 mb-4">Internal Systems</p>
                    <h1 className="text-5xl font-display font-black text-slate-900 tracking-tighter italic">
                        Control <span className="text-brand-600">Portals</span>
                    </h1>
                </div>

                <div className="grid grid-cols-1 md:grid-cols-2 gap-8 font-sans">
                    {/* Super Admin Card */}
                    <Link href="/admin/super" className="group">
                        <div className="bg-slate-950 p-10 rounded-[40px] text-white hover:shadow-2xl hover:shadow-slate-950/20 transition-all border border-white/5 relative overflow-hidden">
                            <div className="absolute top-0 right-0 w-32 h-32 bg-brand-600/10 rounded-full blur-[60px]" />
                            <div className="w-16 h-16 bg-white/10 rounded-2xl flex items-center justify-center mb-8 border border-white/10 transition-transform group-hover:scale-110">
                                <Shield className="w-8 h-8 text-brand-400" />
                            </div>
                            <h2 className="text-2xl font-black italic mb-3">Super Admin</h2>
                            <p className="text-slate-400 text-sm font-bold leading-relaxed mb-8">Platform-wide management, property approvals, and financial oversight.</p>
                            <div className="flex items-center gap-3 text-xs font-black uppercase tracking-widest text-brand-400">
                                Access Master Hub <ArrowRight className="w-4 h-4 group-hover:translate-x-2 transition-transform" />
                            </div>
                        </div>
                    </Link>

                    {/* Hotel Admin Card */}
                    <Link href="/partner" className="group">
                        <div className="bg-white p-10 rounded-[40px] text-slate-900 hover:shadow-2xl hover:shadow-brand-600/5 transition-all border border-slate-100 relative overflow-hidden">
                            <div className="absolute top-0 right-0 w-32 h-32 bg-brand-600/5 rounded-full blur-[60px]" />
                            <div className="w-16 h-16 bg-brand-50 rounded-2xl flex items-center justify-center mb-8 border border-brand-100 transition-transform group-hover:scale-110">
                                <Hotel className="w-8 h-8 text-brand-600" />
                            </div>
                            <h2 className="text-2xl font-black italic mb-3">Hotel Admin</h2>
                            <p className="text-slate-400 text-sm font-bold leading-relaxed mb-8">Property operations, guest tracking, room inventory, and local reviews.</p>
                            <div className="flex items-center gap-3 text-xs font-black uppercase tracking-widest text-brand-600">
                                Access Ops Center <ArrowRight className="w-4 h-4 group-hover:translate-x-2 transition-transform" />
                            </div>
                        </div>
                    </Link>
                </div>
            </div>
        </div>
    );
}
