"use client";

import { useState, useEffect, Suspense } from "react";
import { useParams, useSearchParams, useRouter } from "next/navigation";
import Image from "next/image";
import Link from "next/link";
import { 
    ChevronLeft, 
    Calendar, 
    Users, 
    CreditCard, 
    ShieldCheck, 
    MapPin, 
    Check, 
    AlertCircle,
    Loader2
} from "lucide-react";
import { hotelApi, bookingApi, paymentApi } from "@/lib/api";
import { formatPrice, formatDate } from "@/lib/utils";
import { motion, AnimatePresence } from "framer-motion";

function BookingContent() {
    const params = useParams();
    const searchParams = useSearchParams();
    const router = useRouter();
    
    const hotelId = params.id as string;
    const roomId = searchParams.get("roomId");
    const checkInStr = searchParams.get("checkIn");
    const checkOutStr = searchParams.get("checkOut");
    const guestsCount = searchParams.get("guests") || "2";

    const [hotel, setHotel] = useState<any>(null);
    const [room, setRoom] = useState<any>(null);
    const [loading, setLoading] = useState(true);
    const [bookingLoading, setBookingLoading] = useState(false);
    const [error, setError] = useState<string | null>(null);
    const [success, setSuccess] = useState(false);

    useEffect(() => {
        const fetchData = async () => {
            try {
                setLoading(true);
                const hotelRes = await hotelApi.getHotel(hotelId);
                setHotel(hotelRes.data);
                
                if (roomId) {
                    const roomsRes = await fetch(`http://localhost:5000/api/hotels/${hotelId}/rooms`).then(r => r.json());
                    const selectedRoom = roomsRes.data?.find((r: any) => r.id === parseInt(roomId));
                    setRoom(selectedRoom);
                } else {
                    setRoom(hotelRes.data.rooms?.[0]);
                }
            } catch (err: any) {
                setError(err.message || "Failed to load booking details.");
            } finally {
                setLoading(false);
            }
        };

        if (hotelId) fetchData();
    }, [hotelId, roomId]);

    const nights = (() => {
        if (!checkInStr || !checkOutStr) return 0;
        const diff = (new Date(checkOutStr).getTime() - new Date(checkInStr).getTime()) / (1000 * 60 * 60 * 24);
        return Math.max(0, Math.floor(diff));
    })();

    const pricePerNight = room?.pricePerNight || hotel?.pricePerNight || 0;
    const subtotal = pricePerNight * (nights || 1);
    const taxes = Math.round(subtotal * 0.12);
    const total = subtotal + taxes;

    const handleConfirmBooking = async () => {
        const token = localStorage.getItem('token');
        if (!token) {
            router.push(`/login?redirect=/booking/${hotelId}${window.location.search}`);
            return;
        }

        try {
            setBookingLoading(true);
            setError(null);

            // 1. Create Booking in DB
            const bookingRes = await bookingApi.createBooking({
                hotelId: parseInt(hotelId),
                roomId: room?.id || 1,
                checkIn: checkInStr || new Date().toISOString(),
                checkOut: checkOutStr || new Date(Date.now() + 86400000).toISOString(),
                totalPrice: total,
                totalGuests: parseInt(guestsCount)
            });

            const booking = bookingRes.data;

            // 2. Create Razorpay Order
            const orderRes = await paymentApi.createOrder(booking.id);
            
            // 3. Open Razorpay Checkout
            const options = {
                key: process.env.NEXT_PUBLIC_RAZORPAY_KEY_ID,
                amount: orderRes.amount,
                currency: orderRes.currency,
                name: "GetHotel.",
                description: `Booking for ${hotel?.name}`,
                image: "/logo.png",
                order_id: orderRes.orderId,
                handler: async function (response: any) {
                    try {
                        setBookingLoading(true);
                        // 4. Verify Payment
                        await paymentApi.verifyPayment({
                            razorpay_order_id: response.razorpay_order_id,
                            razorpay_payment_id: response.razorpay_payment_id,
                            razorpay_signature: response.razorpay_signature
                        });
                        setSuccess(true);
                        setTimeout(() => {
                            router.push("/my-bookings");
                        }, 3000);
                    } catch (err: any) {
                        setError(err.message || "Payment verification failed.");
                    } finally {
                        setBookingLoading(false);
                    }
                },
                prefill: {
                    name: "", // You can get this from AuthContext if needed
                    email: "",
                    contact: ""
                },
                theme: {
                    color: "#4F46E5"
                }
            };

            const rzp = new (window as any).Razorpay(options);
            rzp.open();

        } catch (err: any) {
            setError(err.message || "Booking failed. Please try again.");
        } finally {
            setBookingLoading(false);
        }
    };

    if (loading) return (
        <div className="min-h-screen flex items-center justify-center bg-slate-50">
            <div className="flex flex-col items-center gap-4">
                <Loader2 className="w-10 h-10 text-brand-600 animate-spin" />
                <p className="text-slate-500 font-bold italic">Preparing your luxury stay...</p>
            </div>
        </div>
    );

    if (success) return (
        <div className="min-h-screen flex items-center justify-center bg-emerald-50 px-4">
            <motion.div 
                initial={{ scale: 0.9, opacity: 0 }}
                animate={{ scale: 1, opacity: 1 }}
                className="max-w-md w-full bg-white rounded-[40px] p-10 text-center shadow-2xl border border-emerald-100"
            >
                <div className="w-20 h-20 bg-emerald-100 rounded-full flex items-center justify-center mx-auto mb-6">
                    <Check className="w-10 h-10 text-emerald-600" />
                </div>
                <h2 className="text-3xl font-black text-slate-900 mb-4 tracking-tight">Booking Confirmed!</h2>
                <p className="text-slate-600 font-medium mb-8">
                    Bhai, teri booking ho gayi hai! Redirecting you to your bookings...
                </p>
                <div className="w-full h-1.5 bg-slate-100 rounded-full overflow-hidden">
                    <motion.div 
                        initial={{ width: 0 }}
                        animate={{ width: "100%" }}
                        transition={{ duration: 3 }}
                        className="h-full bg-emerald-500"
                    />
                </div>
            </motion.div>
        </div>
    );

    return (
        <div className="min-h-screen bg-slate-50 pt-24 pb-12">
            <div className="max-w-6xl mx-auto px-6">
                <Link href={`/hotel/${hotelId}`} className="inline-flex items-center gap-2 text-slate-500 hover:text-brand-600 font-bold text-sm mb-8 transition-colors group">
                    <ChevronLeft className="w-4 h-4 group-hover:-translate-x-1 transition-transform" />
                    Back to Hotel
                </Link>

                <div className="grid grid-cols-1 lg:grid-cols-3 gap-10">
                    {/* Left: Booking Details */}
                    <div className="lg:col-span-2 space-y-8">
                        <section className="bg-white rounded-[40px] p-8 md:p-10 shadow-xl shadow-slate-200/50 border border-white">
                            <h2 className="text-2xl font-black text-slate-900 mb-8 italic uppercase tracking-tight">Review Your Stay</h2>
                            
                            <div className="flex flex-col md:flex-row gap-8 items-start">
                                <div className="relative w-full md:w-64 h-44 rounded-3xl overflow-hidden shadow-lg shrink-0">
                                    <Image 
                                        src={room?.images?.[0] || hotel?.thumbnail || "https://images.unsplash.com/photo-1566073771259-6a8506099945?w=800&q=80"} 
                                        alt="Room" 
                                        fill 
                                        className="object-cover"
                                    />
                                </div>
                                <div className="flex-1">
                                    <div className="flex items-center gap-2 mb-2">
                                        <div className="px-2.5 py-0.5 bg-brand-50 text-brand-600 rounded-lg text-[10px] font-black uppercase tracking-widest">Selected Stay</div>
                                        <div className="flex text-amber-400 text-xs">{"★".repeat(hotel?.starRating || 5)}</div>
                                    </div>
                                    <h3 className="text-2xl font-black text-slate-900 mb-1">{hotel?.name}</h3>
                                    <p className="text-slate-500 font-bold text-sm flex items-center gap-1.5 mb-4">
                                        <MapPin className="w-3.5 h-3.5 text-brand-500" />
                                        {hotel?.city}, {hotel?.address}
                                    </p>
                                    <div className="p-4 bg-slate-50 rounded-2xl border border-slate-100">
                                        <p className="text-xs font-black text-slate-400 uppercase tracking-widest mb-1">Room Type</p>
                                        <p className="text-base font-black text-slate-800">{room?.name || "Deluxe Room"}</p>
                                        <p className="text-xs text-slate-500 font-bold mt-0.5">{room?.bedConfiguration} • {room?.sizeM2}m² • Max {room?.maxOccupancy} Guests</p>
                                    </div>
                                </div>
                            </div>

                            <div className="grid grid-cols-1 md:grid-cols-2 gap-4 mt-8">
                                <div className="p-6 bg-brand-50/30 rounded-3xl border border-brand-100/50 flex items-center gap-4">
                                    <div className="w-12 h-12 bg-white rounded-2xl flex items-center justify-center shadow-sm">
                                        <Calendar className="w-6 h-6 text-brand-600" />
                                    </div>
                                    <div>
                                        <p className="text-[10px] font-black text-brand-500 uppercase tracking-widest mb-0.5">Check-in</p>
                                        <p className="text-base font-black text-slate-900">{checkInStr ? formatDate(checkInStr) : "Not Selected"}</p>
                                    </div>
                                </div>
                                <div className="p-6 bg-brand-50/30 rounded-3xl border border-brand-100/50 flex items-center gap-4">
                                    <div className="w-12 h-12 bg-white rounded-2xl flex items-center justify-center shadow-sm">
                                        <Calendar className="w-6 h-6 text-brand-600" />
                                    </div>
                                    <div>
                                        <p className="text-[10px] font-black text-brand-500 uppercase tracking-widest mb-0.5">Check-out</p>
                                        <p className="text-base font-black text-slate-900">{checkOutStr ? formatDate(checkOutStr) : "Not Selected"}</p>
                                    </div>
                                </div>
                            </div>
                        </section>

                        <section className="bg-white rounded-[40px] p-8 md:p-10 shadow-xl shadow-slate-200/50 border border-white">
                            <h2 className="text-2xl font-black text-slate-900 mb-8 italic uppercase tracking-tight">Traveller Details</h2>
                            <div className="space-y-4">
                                <div className="flex items-center gap-4 p-5 bg-slate-50 rounded-3xl border border-slate-100">
                                    <div className="w-10 h-10 bg-white rounded-xl flex items-center justify-center text-lg shadow-sm">👤</div>
                                    <div className="flex-1">
                                        <p className="text-[10px] font-black text-slate-400 uppercase tracking-widest mb-0.5">Primary Guest</p>
                                        <p className="text-sm font-bold text-slate-800">You (Logged in)</p>
                                    </div>
                                    <div className="flex items-center gap-2 bg-emerald-50 text-emerald-600 px-3 py-1 rounded-full text-[10px] font-black uppercase">
                                        <ShieldCheck className="w-3 h-3" />
                                        Verified
                                    </div>
                                </div>
                                <div className="flex items-center gap-4 p-5 bg-slate-50 rounded-3xl border border-slate-100">
                                    <div className="w-10 h-10 bg-white rounded-xl flex items-center justify-center shadow-sm">
                                        <Users className="w-5 h-5 text-slate-400" />
                                    </div>
                                    <div className="flex-1">
                                        <p className="text-[10px] font-black text-slate-400 uppercase tracking-widest mb-0.5">Guests Count</p>
                                        <p className="text-sm font-bold text-slate-800">{guestsCount} Guests</p>
                                    </div>
                                </div>
                            </div>
                        </section>

                        <div className="p-6 bg-blue-50 rounded-3xl border border-blue-100 flex items-start gap-4">
                            <AlertCircle className="w-5 h-5 text-blue-600 shrink-0 mt-0.5" />
                            <p className="text-xs text-blue-700 font-medium leading-relaxed">
                                <span className="font-black">Cancellation Policy:</span> Free cancellation up to 24 hours before check-in. After that, 100% of the first night will be charged.
                            </p>
                        </div>
                    </div>

                    {/* Right: Price Summary */}
                    <div className="relative">
                        <div className="sticky top-28 space-y-6">
                            <div className="bg-white rounded-[40px] p-8 shadow-2xl shadow-brand-500/10 border border-white relative overflow-hidden">
                                <div className="absolute top-0 right-0 w-32 h-32 bg-brand-50 rounded-full -translate-y-16 translate-x-16 blur-3xl opacity-50" />
                                
                                <h3 className="text-xl font-black text-slate-900 mb-6 italic uppercase tracking-tight">Price Summary</h3>
                                
                                <div className="space-y-4 mb-8">
                                    <div className="flex justify-between items-center text-sm">
                                        <span className="text-slate-500 font-bold">{formatPrice(pricePerNight)} x {nights || 1} nights</span>
                                        <span className="text-slate-900 font-black">{formatPrice(subtotal)}</span>
                                    </div>
                                    <div className="flex justify-between items-center text-sm">
                                        <span className="text-slate-500 font-bold">Taxes & Service Fees (12%)</span>
                                        <span className="text-slate-900 font-black">{formatPrice(taxes)}</span>
                                    </div>
                                    <div className="pt-4 border-t border-slate-100 space-y-4">
                                        <div className="flex justify-between items-center">
                                            <span className="text-sm font-black text-slate-900 uppercase tracking-tighter">Total Amount</span>
                                            <span className="text-2xl font-black text-slate-950 tracking-tighter">{formatPrice(total)}</span>
                                        </div>
                                        
                                        <div className="bg-brand-600 rounded-[24px] p-5 text-white shadow-xl shadow-brand-100">
                                            <div className="flex justify-between items-center mb-1">
                                                <span className="text-[10px] font-black uppercase tracking-widest opacity-80">Payable Now (18%)</span>
                                                <span className="text-xl font-black italic">{formatPrice(Math.round(total * 0.18))}</span>
                                            </div>
                                            <p className="text-[8px] font-bold uppercase tracking-widest opacity-60">To confirm your reservation</p>
                                        </div>

                                        <div className="flex justify-between items-center px-2 py-3 bg-slate-50 rounded-2xl border border-slate-100">
                                            <span className="text-[10px] font-black text-slate-500 uppercase tracking-widest">Pay at Hotel (82%)</span>
                                            <span className="text-sm font-black text-slate-900 italic">{formatPrice(total - Math.round(total * 0.18))}</span>
                                        </div>
                                    </div>
                                </div>

                                {error && (
                                    <div className="mb-6 p-4 bg-red-50 text-red-600 rounded-2xl text-xs font-bold border border-red-100 flex items-center gap-2">
                                        <AlertCircle className="w-4 h-4" />
                                        {error}
                                    </div>
                                )}

                                <button
                                    onClick={handleConfirmBooking}
                                    disabled={bookingLoading}
                                    className="w-full py-5 bg-slate-900 text-white font-black rounded-[24px] hover:bg-black active:scale-95 transition-all shadow-xl shadow-slate-200 flex flex-col items-center justify-center gap-0.5 text-lg uppercase tracking-tight relative overflow-hidden group"
                                >
                                    <div className="absolute inset-0 bg-brand-600 translate-y-full group-hover:translate-y-0 transition-transform duration-500" />
                                    {bookingLoading ? (
                                        <Loader2 className="w-6 h-6 animate-spin relative z-10" />
                                    ) : (
                                        <>
                                            <span className="relative z-10">Pay {formatPrice(Math.round(total * 0.18))} Now</span>
                                            <span className="text-[9px] font-black uppercase tracking-[0.2em] opacity-40 group-hover:opacity-100 relative z-10 transition-opacity">Confirm & Secure Stay</span>
                                        </>
                                    )}
                                </button>
                                
                                <p className="mt-4 text-[10px] text-slate-400 text-center font-bold uppercase tracking-widest">
                                    Safe & Secure Payments by GetHotel
                                </p>
                            </div>

                            <div className="bg-slate-900 rounded-[32px] p-6 text-white overflow-hidden relative">
                                <div className="absolute top-0 right-0 w-24 h-24 bg-white/10 rounded-full -translate-y-12 translate-x-12 blur-2xl" />
                                <div className="flex items-center gap-4 relative z-10">
                                    <div className="w-10 h-10 bg-brand-600 rounded-xl flex items-center justify-center text-lg">✨</div>
                                    <div>
                                        <p className="text-xs font-black uppercase tracking-widest text-brand-400">Exclusive Perk</p>
                                        <p className="text-sm font-bold text-slate-200 mt-0.5">Complimentary Welcome Drink on arrival.</p>
                                    </div>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    );
}

export default function BookingPage() {
    return (
        <Suspense fallback={<div>Loading...</div>}>
            <BookingContent />
        </Suspense>
    );
}
