"use client";

import { useState, useEffect } from "react";
import Link from "next/link";
import Image from "next/image";
import { 
    Calendar, 
    MapPin, 
    CheckCircle2, 
    Clock, 
    ChevronRight, 
    Hotel,
    Loader2,
    Ticket
} from "lucide-react";
import { bookingApi } from "@/lib/api";
import { formatPrice, formatDate } from "@/lib/utils";
import { motion } from "framer-motion";

export default function MyBookingsPage() {
    const [bookings, setBookings] = useState<any[]>([]);
    const [loading, setLoading] = useState(true);
    const [error, setError] = useState<string | null>(null);

    useEffect(() => {
        const fetchBookings = async () => {
            const token = localStorage.getItem('token');
            if (!token) {
                setError("Please login to view your bookings.");
                setLoading(false);
                return;
            }

            try {
                const res = await bookingApi.getMyBookings();
                setBookings(res.data || []);
            } catch (err: any) {
                setError(err.message || "Failed to load bookings.");
            } finally {
                setLoading(false);
            }
        };

        fetchBookings();
    }, []);

    if (loading) return (
        <div className="min-h-screen flex items-center justify-center bg-slate-50 pt-20">
            <Loader2 className="w-10 h-10 text-brand-600 animate-spin" />
        </div>
    );

    return (
        <div className="min-h-screen bg-slate-50 pt-32 pb-20">
            <div className="max-w-5xl mx-auto px-6">
                <div className="flex flex-col md:flex-row md:items-end justify-between gap-6 mb-12">
                    <div>
                        <div className="flex items-center gap-3 mb-4">
                            <div className="w-10 h-10 rounded-2xl bg-brand-600 flex items-center justify-center shadow-lg shadow-brand-600/30">
                                <Ticket className="w-5 h-5 text-white" />
                            </div>
                            <h1 className="text-4xl font-black text-slate-900 tracking-tight italic">My Bookings</h1>
                        </div>
                        <p className="text-slate-500 font-bold ml-1">Manage and view your upcoming luxury stays.</p>
                    </div>
                    <div className="px-5 py-2.5 bg-white rounded-2xl border border-slate-200 shadow-sm flex items-center gap-2">
                        <span className="w-2 h-2 rounded-full bg-emerald-500 animate-pulse" />
                        <span className="text-xs font-black text-slate-700 uppercase tracking-widest">{bookings.length} Verified Stays</span>
                    </div>
                </div>

                {error ? (
                    <div className="bg-white rounded-[40px] p-16 text-center shadow-xl border border-slate-100">
                        <div className="w-20 h-20 bg-red-50 rounded-full flex items-center justify-center mx-auto mb-6">
                            <Clock className="w-10 h-10 text-red-400" />
                        </div>
                        <h3 className="text-2xl font-black text-slate-900 mb-4">{error}</h3>
                        <Link href="/login" className="btn-primary inline-flex">Go to Login</Link>
                    </div>
                ) : bookings.length === 0 ? (
                    <div className="bg-white rounded-[40px] p-20 text-center shadow-xl border border-slate-100 relative overflow-hidden">
                        <div className="absolute top-0 right-0 w-64 h-64 bg-brand-50 rounded-full -translate-y-32 translate-x-32 blur-3xl opacity-30" />
                        <div className="w-24 h-24 bg-slate-50 rounded-full flex items-center justify-center mx-auto mb-8">
                            <Hotel className="w-12 h-12 text-slate-300" />
                        </div>
                        <h3 className="text-3xl font-black text-slate-900 mb-4 italic">No Stays Planned Yet?</h3>
                        <p className="text-slate-500 font-bold mb-10 max-w-sm mx-auto">
                            Abhi tak koi booking nahi ki? Explore our premium hotels and start your luxury journey today.
                        </p>
                        <Link href="/hotels" className="btn-primary px-12 py-5 text-lg">Explore Hotels</Link>
                    </div>
                ) : (
                    <div className="space-y-6">
                        {bookings.map((booking, i) => (
                            <motion.div 
                                initial={{ opacity: 0, y: 20 }}
                                animate={{ opacity: 1, y: 0 }}
                                transition={{ delay: i * 0.1 }}
                                key={booking.id}
                                className="bg-white rounded-[40px] overflow-hidden border border-slate-100 shadow-xl hover:shadow-2xl transition-all group"
                            >
                                <div className="flex flex-col md:flex-row">
                                    <div className="relative w-full md:w-80 h-56 shrink-0 overflow-hidden">
                                        <Image 
                                            src={booking.room?.images?.[0] || booking.hotel?.thumbnail || "https://images.unsplash.com/photo-1566073771259-6a8506099945?w=800&q=80"} 
                                            alt="Hotel" 
                                            fill 
                                            className="object-cover group-hover:scale-110 transition-transform duration-700"
                                        />
                                        <div className="absolute top-4 left-4">
                                            <div className="px-4 py-2 bg-white/90 backdrop-blur-md rounded-2xl shadow-lg flex items-center gap-2">
                                                <div className={`w-2 h-2 rounded-full ${booking.status === 'confirmed' ? 'bg-emerald-500' : 'bg-amber-500 animate-pulse'}`} />
                                                <span className="text-[10px] font-black uppercase tracking-widest text-slate-900">{booking.status}</span>
                                            </div>
                                        </div>
                                    </div>
                                    <div className="flex-1 p-8 md:p-10 flex flex-col justify-between">
                                        <div className="flex flex-col md:flex-row md:items-start justify-between gap-4 mb-6">
                                            <div>
                                                <h3 className="text-2xl font-black text-slate-900 mb-1 group-hover:text-brand-600 transition-colors">{booking.hotel?.name}</h3>
                                                <p className="text-slate-400 font-bold text-sm flex items-center gap-1.5">
                                                    <MapPin className="w-3.5 h-3.5 text-brand-500" />
                                                    {booking.hotel?.city}, {booking.hotel?.address}
                                                </p>
                                            </div>
                                            <div className="text-right">
                                                <p className="text-[10px] font-black text-slate-400 uppercase tracking-widest mb-1">Total Paid</p>
                                                <p className="text-2xl font-black text-brand-600 tracking-tighter">{formatPrice(booking.totalPrice)}</p>
                                            </div>
                                        </div>

                                        <div className="grid grid-cols-2 sm:grid-cols-3 gap-6 pt-6 border-t border-slate-50">
                                            <div>
                                                <p className="text-[9px] font-black text-slate-400 uppercase tracking-widest mb-1">Check-in</p>
                                                <div className="flex items-center gap-2">
                                                    <Calendar className="w-3.5 h-3.5 text-brand-500" />
                                                    <span className="text-sm font-black text-slate-800">{formatDate(booking.checkIn)}</span>
                                                </div>
                                            </div>
                                            <div>
                                                <p className="text-[9px] font-black text-slate-400 uppercase tracking-widest mb-1">Check-out</p>
                                                <div className="flex items-center gap-2">
                                                    <Calendar className="w-3.5 h-3.5 text-brand-500" />
                                                    <span className="text-sm font-black text-slate-800">{formatDate(booking.checkOut)}</span>
                                                </div>
                                            </div>
                                            <div className="hidden sm:block">
                                                <p className="text-[9px] font-black text-slate-400 uppercase tracking-widest mb-1">Room Type</p>
                                                <div className="flex items-center gap-2">
                                                    <Hotel className="w-3.5 h-3.5 text-brand-500" />
                                                    <span className="text-sm font-black text-slate-800 truncate">{booking.room?.name || "Deluxe Stay"}</span>
                                                </div>
                                            </div>
                                        </div>
                                    </div>
                                    <div className="md:w-20 border-t md:border-t-0 md:border-l border-slate-50 flex items-center justify-center p-6 md:p-0">
                                        <Link 
                                            href={`/hotel/${booking.hotel?.id}`}
                                            className="w-12 h-12 rounded-full bg-slate-50 flex items-center justify-center text-slate-400 hover:bg-brand-600 hover:text-white hover:scale-110 transition-all shadow-sm"
                                        >
                                            <ChevronRight className="w-6 h-6" />
                                        </Link>
                                    </div>
                                </div>
                            </motion.div>
                        ))}
                    </div>
                )}
            </div>
        </div>
    );
}
