"use client";

import { useState } from "react";
import { useRouter } from "next/navigation";
import { useAuth } from "@/context/AuthContext";
import { Mail, Lock, User, Loader2, ArrowRight } from "lucide-react";
import Link from "next/link";
import { motion } from "framer-motion";

export default function RegisterPage() {
    const [name, setName] = useState("");
    const [email, setEmail] = useState("");
    const [password, setPassword] = useState("");
    const [loading, setLoading] = useState(false);
    const [error, setError] = useState("");
    const { register } = useAuth();
    const router = useRouter();

    const handleSubmit = async (e: React.FormEvent) => {
        e.preventDefault();
        setLoading(true);
        setError("");
        try {
            await register({ name, email, password, role: 'user' });
            router.push("/");
        } catch (err: any) {
            setError(err.message || "Registration failed. Please try again.");
        } finally {
            setLoading(false);
        }
    };

    return (
        <div className="min-h-screen bg-white flex flex-col items-center justify-center p-6 relative">
            {/* Minimal Background Decoration */}
            <div className="absolute top-0 left-0 w-full h-full overflow-hidden pointer-events-none">
                <div className="absolute top-[-10%] left-[-5%] w-[30%] h-[30%] bg-brand-50/50 blur-[120px] rounded-full" />
                <div className="absolute bottom-[-10%] right-[-5%] w-[30%] h-[30%] bg-slate-50/50 blur-[120px] rounded-full" />
            </div>

            <motion.div 
                initial={{ opacity: 0, y: 10 }}
                animate={{ opacity: 1, y: 0 }}
                className="w-full max-w-sm relative z-10"
            >
                <div className="mb-12 text-center md:text-left">
                    <h1 className="text-6xl font-black text-slate-950 tracking-tighter italic mb-4">
                        Join Us.
                    </h1>
                    <p className="text-slate-500 font-bold text-sm tracking-tight">
                        Become part of the most <span className="text-brand-600">exclusive</span> travel club.
                    </p>
                </div>

                {error && (
                    <motion.div 
                        initial={{ opacity: 0, x: -10 }}
                        animate={{ opacity: 1, x: 0 }}
                        className="mb-8 p-4 bg-red-50 text-red-600 rounded-2xl text-[10px] font-black uppercase tracking-widest border border-red-100"
                    >
                        {error}
                    </motion.div>
                )}

                <form onSubmit={handleSubmit} className="space-y-6">
                    <div className="space-y-1">
                        <input 
                            type="text" 
                            required
                            placeholder="FULL NAME"
                            value={name}
                            onChange={(e) => setName(e.target.value)}
                            className="w-full bg-slate-50 border-none rounded-2xl px-6 py-5 text-xs font-black text-slate-900 placeholder:text-slate-300 focus:bg-white focus:ring-2 focus:ring-slate-950 transition-all outline-none uppercase tracking-widest"
                        />
                    </div>

                    <div className="space-y-1">
                        <input 
                            type="email" 
                            required
                            placeholder="EMAIL ADDRESS"
                            value={email}
                            onChange={(e) => setEmail(e.target.value)}
                            className="w-full bg-slate-50 border-none rounded-2xl px-6 py-5 text-xs font-black text-slate-900 placeholder:text-slate-300 focus:bg-white focus:ring-2 focus:ring-slate-950 transition-all outline-none uppercase tracking-widest"
                        />
                    </div>

                    <div className="space-y-1">
                        <input 
                            type="password" 
                            required
                            placeholder="CHOOSE PASSWORD"
                            value={password}
                            onChange={(e) => setPassword(e.target.value)}
                            className="w-full bg-slate-50 border-none rounded-2xl px-6 py-5 text-xs font-black text-slate-900 placeholder:text-slate-300 focus:bg-white focus:ring-2 focus:ring-slate-950 transition-all outline-none uppercase tracking-widest"
                        />
                    </div>

                    <button 
                        type="submit" 
                        disabled={loading}
                        className="w-full py-5 bg-brand-600 text-white font-black rounded-2xl shadow-xl shadow-brand-100 hover:bg-brand-700 hover:scale-[1.02] active:scale-[0.98] transition-all flex items-center justify-center gap-3 text-xs uppercase tracking-widest"
                    >
                        {loading ? <Loader2 className="w-5 h-5 animate-spin" /> : "Create Account"}
                    </button>
                </form>

                <div className="pt-10 text-center md:text-left">
                    <p className="text-[10px] font-black text-slate-400 uppercase tracking-widest">
                        Already have an account? <br />
                        <Link href="/login" className="text-slate-950 hover:underline mt-2 inline-block">Sign In to Your Empire</Link>
                    </p>
                </div>
            </motion.div>
        </div>
    );
}
