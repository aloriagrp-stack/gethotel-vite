import { notFound } from "next/navigation";
import type { Metadata } from "next";
import HotelDetailContent from "./HotelDetailContent";

interface Props {
    params: Promise<{ id: string }>;
}

import { hotels } from "@/data/hotels";

async function fetchHotel(id: string) {
    try {
        const res = await fetch(`http://192.168.43.117:5000/api/hotels/${id}`, { 
            cache: 'no-store',
            next: { revalidate: 0 } 
        });
        if (res.ok) {
            const json = await res.json();
            return json.data;
        }
    } catch (err) {
        console.warn("Backend fetch failed, falling back to mock data");
    }
    
    // Fallback to local mock data
    return hotels.find(h => h.id === id) || null;
}

export async function generateMetadata({ params }: Props): Promise<Metadata> {
    const { id } = await params;
    const hotel = await fetchHotel(id);
    if (!hotel) return { title: "Hotel Not Found" };
    return {
        title: `${hotel.name} — ${hotel.city} | GetHotel Luxury`,
        description: hotel.description,
    };
}

export default async function HotelDetailPage({ params }: Props) {
    const { id } = await params;
    const hotel = await fetchHotel(id);
    
    if (!hotel) notFound();

    return <HotelDetailContent initialHotel={hotel} id={id} />;
}
