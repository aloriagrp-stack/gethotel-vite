"use client";

import { useState, useEffect } from "react";
import Image from "next/image";
import Link from "next/link";
import { 
    MapPin, 
    ChevronRight, 
    Check, 
    Loader2,
    Shield,
    Star,
    Award,
    Coffee,
    Wifi,
    Zap,
} from "lucide-react";
import { motion, AnimatePresence } from "framer-motion";
import ImageGallery from "@/components/hotels/ImageGallery";
import PriceBox from "@/components/hotels/PriceBox";
import { ratingLabel, amenityIcon, amenityLabel, formatDate, formatPrice } from "@/lib/utils";
import { hotelApi } from "@/lib/api";

interface Room {
    id: string | number;
    name: string;
    description?: string;
    pricePerNight: number;
    capacity?: number;
    maxOccupancy: number;
    sizeM2?: number;
    bedConfiguration?: string;
    isAvailable?: boolean;
    images?: string[];
    amenities?: string[];
}

interface Dining {
    enabled: boolean;
    list: { name: string; cuisine: string; time: string }[];
}

interface Policy {
    checkIn?: string;
    checkOut?: string;
    cancellation?: string;
    children?: string;
    payment?: string;
}

interface FAQ {
    question: string;
    answer: string;
}

interface Review {
    id: string | number;
    rating: number;
    comment: string;
    createdAt: string;
    user: { name: string } | null;
}

interface Hotel {
    id: string | number;
    name: string;
    tagline?: string;
    description: string;
    city: string;
    address: string;
    starRating: number;
    guestRating: number;
    reviewCount: number;
    pricePerNight: number;
    thumbnail: string;
    images?: string[];
    amenities?: string[];
    badge?: string;
    dining?: Dining;
    wellness?: { enabled: boolean; list: { name: string; icon: string; info: string }[] };
    faqs?: FAQ[];
    safety?: string[];
    policies?: Policy;
    reviews?: Review[];
}

const fadeInUp = {
    initial: { opacity: 0, y: 20 },
    animate: { opacity: 1, y: 0 },
    transition: { duration: 0.5, ease: [0.16, 1, 0.3, 1] }
};

const staggerContainer = {
    animate: {
        transition: {
            staggerChildren: 0.1
        }
    }
};

export default function HotelDetailContent({ initialHotel, id }: { initialHotel: Hotel, id: string }) {
    const [hotel] = useState<Hotel>(initialHotel);
    const [rooms, setRooms] = useState<Room[]>([]);
    const [loading, setLoading] = useState(true);

    useEffect(() => {
        const fetchRooms = async () => {
            try {
                const roomsRes = await hotelApi.getRooms(id);
                setRooms(roomsRes.data || []);
            } catch (err) {
                console.error("Failed to fetch rooms:", err);
            } finally {
                setLoading(false);
            }
        };
        fetchRooms();
    }, [id]);

    const hotelImages = hotel.images || [];
    const hotelAmenities = hotel.amenities || [];
    const reviews = hotel.reviews || [];

    // Safety check for star rating to avoid Array(NaN) error
    const starCount = Math.max(0, Math.floor(Number(hotel.starRating) || 0));

    return (
        <div className="min-h-screen bg-[#fcfdff] pt-20 text-slate-900 pb-20 overflow-x-hidden relative">
            {/* 100 Billion Dollar Atmospheric Elements */}
            <div className="absolute top-0 left-0 right-0 h-[800px] bg-gradient-to-b from-brand-50/40 to-transparent pointer-events-none -z-10" />
            
            <motion.div 
                animate={{ 
                    scale: [1, 1.2, 1],
                    rotate: [0, 90, 0],
                    opacity: [0.1, 0.2, 0.1]
                }}
                transition={{ duration: 20, repeat: Infinity, ease: "linear" }}
                className="absolute top-[10%] -left-[10%] w-[600px] h-[600px] bg-brand-200/20 rounded-full blur-[120px] pointer-events-none -z-10"
            />
            
            <motion.div 
                animate={{ 
                    scale: [1.2, 1, 1.2],
                    rotate: [90, 0, 90],
                    opacity: [0.05, 0.15, 0.05]
                }}
                transition={{ duration: 25, repeat: Infinity, ease: "linear" }}
                className="absolute top-[40%] -right-[10%] w-[500px] h-[500px] bg-purple-200/10 rounded-full blur-[100px] pointer-events-none -z-10"
            />

            {/* Premium Marquee / Luxe Bar */}
            <div className="bg-slate-900 py-3 overflow-hidden border-y border-white/5">
                <motion.div 
                    animate={{ x: [0, -1000] }}
                    transition={{ duration: 30, repeat: Infinity, ease: "linear" }}
                    className="flex whitespace-nowrap gap-20 items-center"
                >
                    {[1, 2, 3, 4, 5].map((i) => (
                        <div key={i} className="flex items-center gap-20">
                            <span className="text-[10px] font-black text-brand-400 uppercase tracking-[0.5em] italic flex items-center gap-3">
                                <Star className="w-3 h-3 fill-brand-400" /> Signature Luxury Experience
                            </span>
                            <span className="text-[10px] font-black text-white/40 uppercase tracking-[0.5em] italic flex items-center gap-3">
                                <Check className="w-3 h-3" /> Best Rate Guaranteed
                            </span>
                            <span className="text-[10px] font-black text-brand-400 uppercase tracking-[0.5em] italic flex items-center gap-3">
                                <Award className="w-3 h-3" /> Premier Partner
                            </span>
                        </div>
                    ))}
                </motion.div>
            </div>

            <div className="container-page py-8 relative">
                {/* Breadcrumb */}
                <motion.nav 
                    initial={{ opacity: 0, x: -10 }}
                    animate={{ opacity: 1, x: 0 }}
                    className="flex items-center gap-2 text-xs font-bold uppercase tracking-widest text-slate-400 mb-8"
                >
                    <Link href="/" className="hover:text-brand-600 transition-colors">Home</Link>
                    <ChevronRight className="w-3 h-3 opacity-40" />
                    <Link href="/hotels" className="hover:text-brand-600 transition-colors">Hotels</Link>
                    <ChevronRight className="w-3 h-3 opacity-40" />
                    <span className="text-slate-900 truncate">{hotel.name}</span>
                </motion.nav>

                {/* Hotel Header Section */}
                <div className="flex flex-col lg:flex-row lg:items-end justify-between gap-8 mb-10">
                    <motion.div 
                        initial={{ opacity: 0, y: 30 }}
                        animate={{ opacity: 1, y: 0 }}
                        transition={{ duration: 0.6, ease: [0.16, 1, 0.3, 1] }}
                        className="flex-1"
                    >
                        <div className="flex flex-wrap items-center gap-3 mb-5">
                            {hotel.badge && (
                                <span className="px-4 py-1.5 bg-brand-600 text-white text-[10px] font-black uppercase tracking-[0.2em] rounded-full shadow-lg shadow-brand-200">
                                    {hotel.badge}
                                </span>
                            )}
                            <div className="flex items-center gap-1 bg-white px-3 py-1.5 rounded-full shadow-sm border border-slate-100">
                                {[...Array(starCount)].map((_, i) => (
                                    <Star key={i} className="w-3 h-3 fill-gold-500 text-gold-500" />
                                ))}
                                <span className="ml-1 text-[10px] font-black text-slate-600 uppercase tracking-widest">{hotel.starRating} Star Property</span>
                            </div>
                        </div>
                        
                        <h1 className="text-5xl sm:text-7xl lg:text-8xl font-black text-slate-950 mb-6 tracking-tighter leading-[0.9] italic">
                            {hotel.name}
                        </h1>
                        
                        <div className="flex flex-col sm:flex-row sm:items-center gap-4 text-slate-500">
                            <div className="flex items-center gap-2 bg-slate-100/50 px-4 py-2 rounded-2xl border border-slate-200/60 backdrop-blur-sm">
                                <MapPin className="w-4 h-4 text-brand-500 shrink-0" />
                                <span className="text-sm font-bold text-slate-700">{hotel.address}</span>
                            </div>
                            {hotel.tagline && <p className="text-brand-600 font-bold italic text-lg sm:ml-2">"{hotel.tagline}"</p>}
                        </div>
                    </motion.div>

                    <motion.div 
                        initial={{ opacity: 0, scale: 0.9 }}
                        animate={{ opacity: 1, scale: 1 }}
                        transition={{ delay: 0.2, duration: 0.5 }}
                        className="flex items-center gap-5 bg-white p-5 rounded-[32px] shadow-premium border border-slate-50"
                    >
                        <div className="text-right">
                            <p className="text-[10px] text-slate-400 font-black uppercase tracking-[0.15em] mb-1">Guest Rating</p>
                            <p className="text-sm font-black text-slate-950 italic">{ratingLabel(hotel.guestRating)}</p>
                            <p className="text-[10px] text-brand-600 font-bold mt-0.5">{(hotel.reviewCount || 0).toLocaleString()} Reviews</p>
                        </div>
                        <div className="w-16 h-16 bg-brand-600 rounded-2xl flex items-center justify-center text-2xl font-black text-white italic shadow-xl shadow-brand-100">
                            {hotel.guestRating}
                        </div>
                    </motion.div>
                </div>

                {/* Main Gallery Container */}
                <motion.div 
                    initial={{ opacity: 0, y: 40 }}
                    animate={{ opacity: 1, y: 0 }}
                    transition={{ delay: 0.3, duration: 0.8, ease: [0.16, 1, 0.3, 1] }}
                    className="rounded-[48px] overflow-hidden shadow-2xl border-4 border-white ring-1 ring-slate-100"
                >
                    {hotelImages.length > 0 ? (
                        <ImageGallery images={hotelImages} hotelName={hotel.name} />
                    ) : (
                        <div className="aspect-video bg-slate-100 flex items-center justify-center text-slate-400 font-bold italic">
                            No imagery available for this property.
                        </div>
                    )}
                </motion.div>

                {/* Content Grid */}
                <div className="mt-16 grid grid-cols-1 lg:grid-cols-3 gap-12 relative">
                    {/* Left Side: Information */}
                    <div className="lg:col-span-2 space-y-16">
                        {/* Highlights Row */}
                        <motion.div 
                            variants={staggerContainer}
                            initial="initial"
                            whileInView="animate"
                            viewport={{ once: true }}
                            className="grid grid-cols-2 sm:grid-cols-4 gap-4"
                        >
                            {[
                                { icon: Award, label: "Top Rated", sub: "Guest Choice" },
                                { icon: Shield, label: "Secure", sub: "Stay Safe" },
                                { icon: Coffee, label: "Breakfast", sub: "Available" },
                                { icon: Wifi, label: "Fast WiFi", sub: "Free Access" }
                            ].map((item, i) => (
                                <motion.div key={i} variants={fadeInUp} className="bg-white p-5 rounded-3xl border border-slate-100 shadow-sm hover:shadow-md transition-all group">
                                    <div className="w-10 h-10 bg-brand-50 rounded-xl flex items-center justify-center mb-3 group-hover:scale-110 transition-transform">
                                        <item.icon className="w-5 h-5 text-brand-600" />
                                    </div>
                                    <p className="text-xs font-black text-slate-900 uppercase tracking-widest">{item.label}</p>
                                    <p className="text-[10px] text-slate-400 font-bold mt-0.5">{item.sub}</p>
                                </motion.div>
                            ))}
                        </motion.div>

                        {/* About Section */}
                        <motion.section 
                            variants={fadeInUp}
                            initial="initial"
                            whileInView="animate"
                            viewport={{ once: true }}
                            className="relative"
                        >
                            <div className="flex items-center gap-4 mb-8">
                                <h2 className="text-2xl font-black text-slate-950 tracking-tighter italic uppercase">The Property</h2>
                                <div className="h-px bg-slate-200 flex-1" />
                            </div>
                            <div className="prose prose-slate max-w-none">
                                <p className="text-slate-600 leading-[2] text-xl font-medium first-letter:text-7xl first-letter:font-black first-letter:text-brand-600 first-letter:mr-3 first-letter:float-left first-letter:leading-[0.8] italic">
                                    {hotel.description}
                                </p>
                            </div>
                            
                            {/* Quick Stats Grid */}
                            <div className="grid grid-cols-2 md:grid-cols-4 gap-4 mt-12">
                                <div className="bg-slate-50 p-6 rounded-[32px] border border-slate-100">
                                    <p className="text-[9px] font-black text-slate-400 uppercase tracking-widest mb-1">Built</p>
                                    <p className="text-lg font-black text-slate-900 italic">2018</p>
                                </div>
                                <div className="bg-slate-50 p-6 rounded-[32px] border border-slate-100">
                                    <p className="text-[9px] font-black text-slate-400 uppercase tracking-widest mb-1">Floors</p>
                                    <p className="text-lg font-black text-slate-900 italic">12</p>
                                </div>
                                <div className="bg-slate-50 p-6 rounded-[32px] border border-slate-100">
                                    <p className="text-[9px] font-black text-slate-400 uppercase tracking-widest mb-1">Staff</p>
                                    <p className="text-lg font-black text-slate-900 italic">24/7</p>
                                </div>
                                <div className="bg-slate-50 p-6 rounded-[32px] border border-slate-100">
                                    <p className="text-[9px] font-black text-slate-400 uppercase tracking-widest mb-1">Check-in</p>
                                    <p className="text-lg font-black text-slate-900 italic">14:00</p>
                                </div>
                            </div>
                        </motion.section>

                        {/* Amenities Cloud */}
                        {hotelAmenities.length > 0 && (
                            <motion.section 
                                initial={{ opacity: 0 }}
                                whileInView={{ opacity: 1 }}
                                viewport={{ once: true }}
                                className="space-y-8"
                            >
                                <div className="flex items-center gap-4 mb-2">
                                    <h2 className="text-2xl font-black text-slate-950 tracking-tighter italic uppercase">Amenities & Perks</h2>
                                    <div className="h-px bg-slate-200 flex-1" />
                                </div>
                                <div className="grid grid-cols-2 sm:grid-cols-3 gap-5">
                                    {hotelAmenities.map((amenity, i) => (
                                        <motion.div
                                            key={amenity}
                                            initial={{ opacity: 0, scale: 0.9 }}
                                            whileInView={{ opacity: 1, scale: 1 }}
                                            transition={{ delay: i * 0.05 }}
                                            viewport={{ once: true }}
                                            className="flex items-center gap-4 p-4 bg-white/60 backdrop-blur-md rounded-3xl border border-slate-100 hover:border-brand-200 hover:bg-white transition-all group shadow-sm hover:shadow-md"
                                        >
                                            <span className="text-2xl grayscale group-hover:grayscale-0 transition-all transform group-hover:scale-125 duration-500">
                                                {amenityIcon(amenity)}
                                            </span>
                                            <span className="text-[11px] font-black text-slate-700 uppercase tracking-widest">
                                                {amenityLabel(amenity)}
                                            </span>
                                        </motion.div>
                                    ))}
                                </div>
                            </motion.section>
                        )}

                        {/* Rooms List */}
                        <section id="rooms" className="scroll-mt-32">
                            <div className="flex items-center gap-4 mb-10">
                                <h2 className="text-2xl font-black text-slate-950 tracking-tighter italic uppercase">Signature Suites</h2>
                                <div className="h-px bg-slate-200 flex-1" />
                            </div>
                            
                            <div className="space-y-6">
                                {loading ? (
                                    <div className="py-20 flex flex-col items-center gap-4">
                                        <Loader2 className="w-10 h-10 text-brand-600 animate-spin" />
                                        <p className="text-xs font-black text-slate-400 uppercase tracking-widest">Finding available suites...</p>
                                    </div>
                                ) : rooms.length > 0 ? (
                                    rooms.map((room, i) => (
                                        <motion.div
                                            key={room.id}
                                            initial={{ opacity: 0, x: -20 }}
                                            whileInView={{ opacity: 1, x: 0 }}
                                            transition={{ delay: i * 0.1 }}
                                            viewport={{ once: true }}
                                            className={`group relative overflow-hidden rounded-[40px] border p-1 transition-all duration-500 ${
                                                room.isAvailable !== false
                                                ? "border-slate-100 bg-white shadow-xl hover:shadow-2xl hover:-translate-y-1"
                                                : "border-slate-100 bg-slate-50 opacity-70"
                                            }`}
                                        >
                                            <div className="flex flex-col md:flex-row gap-6 p-5">
                                                <div className="relative w-full md:w-64 aspect-[4/3] rounded-[32px] overflow-hidden shrink-0 shadow-lg ring-4 ring-slate-50">
                                                    {(room.images && room.images.length > 0) ? (
                                                        <Image
                                                            src={room.images[0]}
                                                            alt={room.name}
                                                            fill
                                                            className="object-cover group-hover:scale-110 transition-transform duration-700"
                                                            sizes="300px"
                                                        />
                                                    ) : (
                                                        <div className="w-full h-full bg-slate-100 flex items-center justify-center text-slate-300">No Image</div>
                                                    )}
                                                </div>
                                                
                                                <div className="flex-1 flex flex-col justify-between py-2">
                                                    <div>
                                                        <div className="flex items-center justify-between mb-3">
                                                            <h3 className="text-2xl font-black text-slate-900 tracking-tight">{room.name}</h3>
                                                            {room.isAvailable === false && (
                                                                <span className="px-3 py-1 bg-red-50 text-red-600 text-[10px] font-black uppercase tracking-widest rounded-full">Fully Booked</span>
                                                            )}
                                                        </div>
                                                        <p className="text-xs text-slate-500 font-bold uppercase tracking-[0.15em] flex items-center gap-3">
                                                            {room.sizeM2 && <span>{room.sizeM2}m²</span>}
                                                            {room.sizeM2 && room.bedConfiguration && <span className="w-1 h-1 bg-slate-300 rounded-full" />}
                                                            {room.bedConfiguration && <span>{room.bedConfiguration}</span>}
                                                            {room.maxOccupancy && <span className="w-1 h-1 bg-slate-300 rounded-full" />}
                                                            {room.maxOccupancy && <span>Up to {room.maxOccupancy} Guests</span>}
                                                        </p>
                                                        <div className="flex flex-wrap gap-2 mt-5">
                                                            {room.amenities?.slice(0, 5).map((a) => (
                                                                <span key={a} className="px-3 py-1 bg-slate-50 text-slate-500 text-[10px] font-bold uppercase tracking-widest rounded-lg border border-slate-100">
                                                                    {a}
                                                                </span>
                                                            ))}
                                                        </div>
                                                    </div>

                                                    <div className="flex items-center justify-between mt-8 md:mt-0 pt-6 border-t border-slate-50">
                                                        <div>
                                                            <p className="text-2xl font-black text-slate-950">{formatPrice(room.pricePerNight)}</p>
                                                            <p className="text-[10px] text-slate-400 font-black uppercase tracking-widest">Per Night · Incl. Taxes</p>
                                                        </div>
                                                        {room.isAvailable !== false && (
                                                            <Link
                                                                href={`/booking/${hotel.id}?roomId=${room.id}`}
                                                                className="px-8 py-3.5 bg-brand-600 hover:bg-brand-700 text-white text-xs font-black rounded-2xl transition-all shadow-lg shadow-brand-100 active:scale-95 uppercase tracking-[0.2em]"
                                                            >
                                                                Reserve Suite
                                                            </Link>
                                                        )}
                                                    </div>
                                                </div>
                                            </div>
                                        </motion.div>
                                    ))
                                ) : (
                                    <div className="p-12 bg-slate-50 rounded-[40px] text-center border-2 border-dashed border-slate-200">
                                        <p className="text-slate-400 font-bold italic uppercase tracking-widest">All suites are currently occupied.</p>
                                    </div>
                                )}
                            </div>
                        </section>

                        {/* Policies & Details */}
                        <motion.section 
                            initial={{ opacity: 0, y: 30 }}
                            whileInView={{ opacity: 1, y: 0 }}
                            viewport={{ once: true }}
                            className="bg-white rounded-[48px] p-10 border border-slate-100 shadow-xl"
                        >
                            <h2 className="text-2xl font-black text-slate-950 tracking-tighter italic uppercase mb-10">House Policies & Payment</h2>
                            <div className="grid grid-cols-1 md:grid-cols-2 gap-10">
                                <div className="space-y-8">
                                    <div className="flex gap-5">
                                        <div className="w-12 h-12 bg-brand-600 rounded-2xl flex items-center justify-center shrink-0 shadow-lg shadow-brand-100">
                                            <Zap className="w-6 h-6 text-white fill-white" />
                                        </div>
                                        <div>
                                            <p className="text-[10px] font-black text-brand-600 uppercase tracking-widest mb-1">Partial Payment Model</p>
                                            <p className="text-sm font-black text-slate-900 leading-tight">Pay only 18% now to secure your stay.</p>
                                            <p className="text-xs text-slate-500 font-medium mt-1">Remaining 82% can be paid directly at the hotel during check-in.</p>
                                        </div>
                                    </div>
                                    <div className="flex gap-5">
                                        <div className="w-12 h-12 bg-brand-50 rounded-2xl flex items-center justify-center shrink-0">
                                            <Coffee className="w-6 h-6 text-brand-600" />
                                        </div>
                                        <div>
                                            <p className="text-[10px] font-black text-slate-400 uppercase tracking-widest mb-1">Timing</p>
                                            <p className="text-sm font-bold text-slate-800">Check-in: {hotel.policies?.checkIn || "14:00"}</p>
                                            <p className="text-sm font-bold text-slate-800">Check-out: {hotel.policies?.checkOut || "11:00"}</p>
                                        </div>
                                    </div>
                                    <div className="flex gap-5">
                                        <div className="w-12 h-12 bg-emerald-50 rounded-2xl flex items-center justify-center shrink-0">
                                            <Check className="w-6 h-6 text-emerald-600" />
                                        </div>
                                        <div>
                                            <p className="text-[10px] font-black text-slate-400 uppercase tracking-widest mb-1">Cancellation</p>
                                            <p className="text-sm font-bold text-slate-800 leading-relaxed">
                                                {hotel.policies?.cancellation || "Free cancellation until 48h before check-in."}
                                            </p>
                                        </div>
                                    </div>
                                </div>
                                <div className="space-y-8">
                                    <div className="flex gap-5">
                                        <div className="w-12 h-12 bg-amber-50 rounded-2xl flex items-center justify-center shrink-0">
                                            <Shield className="w-6 h-6 text-amber-600" />
                                        </div>
                                        <div>
                                            <p className="text-[10px] font-black text-slate-400 uppercase tracking-widest mb-1">Guest Safety</p>
                                            <p className="text-sm font-bold text-slate-800 leading-relaxed">
                                                Property follows premium hygiene protocols. Staff is fully vaccinated.
                                            </p>
                                        </div>
                                    </div>
                                    <div className="flex gap-5">
                                        <div className="w-12 h-12 bg-purple-50 rounded-2xl flex items-center justify-center shrink-0">
                                            <Award className="w-6 h-6 text-purple-600" />
                                        </div>
                                        <div>
                                            <p className="text-[10px] font-black text-slate-400 uppercase tracking-widest mb-1">Membership</p>
                                            <p className="text-sm font-bold text-slate-800 leading-relaxed">
                                                StayEase Rewards members get 10% off on all spa treatments.
                                            </p>
                                        </div>
                                    </div>
                                </div>
                            </div>
                        </motion.section>

                        {/* Review Showcase */}
                        <section className="space-y-10">
                            <div className="flex items-end justify-between">
                                <h2 className="text-2xl font-black text-slate-950 tracking-tighter italic uppercase">Guest Stories</h2>
                                <Link 
                                    href={`/hotel/${hotel.id}/write-review`}
                                    className="px-6 py-3 bg-slate-950 text-white text-[10px] font-black rounded-2xl hover:bg-black transition-all uppercase tracking-widest shadow-xl shadow-slate-200"
                                >
                                    Share Your Experience
                                </Link>
                            </div>
                            
                            <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
                                {reviews.length > 0 ? (
                                    reviews.map((review, i) => (
                                        <motion.div 
                                            key={review.id || i}
                                            initial={{ opacity: 0, scale: 0.95 }}
                                            whileInView={{ opacity: 1, scale: 1 }}
                                            viewport={{ once: true }}
                                            className="bg-white rounded-[40px] p-8 border border-slate-100 shadow-lg hover:shadow-xl transition-all"
                                        >
                                            <div className="flex items-center gap-4 mb-6">
                                                {review.user?.name && (
                                                    <Image
                                                        src={`https://i.pravatar.cc/150?u=${review.user.name}`}
                                                        alt={review.user.name}
                                                        width={50}
                                                        height={50}
                                                        className="rounded-2xl grayscale hover:grayscale-0 transition-all duration-500 ring-2 ring-slate-50"
                                                    />
                                                )}
                                                <div className="flex-1">
                                                    <h4 className="font-black text-slate-950 text-sm tracking-tight">{review.user?.name || "Verified Guest"}</h4>
                                                    <div className="flex items-center gap-2 mt-0.5">
                                                        <div className="flex gap-0.5">
                                                            {[...Array(5)].map((_, star) => (
                                                                <Star key={star} className={`w-2.5 h-2.5 ${star < review.rating ? 'fill-brand-600 text-brand-600' : 'fill-slate-100 text-slate-100'}`} />
                                                            ))}
                                                        </div>
                                                        <span className="text-[9px] text-slate-400 font-black uppercase tracking-widest italic">{formatDate(review.createdAt)}</span>
                                                    </div>
                                                </div>
                                            </div>
                                            <p className="text-slate-600 text-sm leading-relaxed font-medium italic opacity-90">
                                                "{review.comment}"
                                            </p>
                                        </motion.div>
                                    ))
                                ) : (
                                    <div className="col-span-full p-16 bg-white rounded-[40px] border border-dashed border-slate-200 text-center">
                                        <p className="text-slate-400 font-bold italic uppercase tracking-widest text-xs">Waiting for its first legend. Will it be you?</p>
                                    </div>
                                )}
                            </div>
                        </section>
                    </div>

                    {/* Right Side: Sticky Pricing Card */}
                    <div className="hidden lg:block relative">
                        <motion.div 
                            initial={{ opacity: 0, x: 20 }}
                            animate={{ opacity: 1, x: 0 }}
                            transition={{ delay: 0.5, duration: 0.6 }}
                            className="sticky top-28"
                        >
                            <PriceBox
                                hotelId={hotel.id.toString()}
                                pricePerNight={hotel.pricePerNight}
                            />
                            
                            {/* Upsell Card */}
                            <div className="mt-6 bg-brand-600 rounded-[32px] p-6 text-white shadow-xl shadow-brand-100 relative overflow-hidden group">
                                <Award className="absolute -right-4 -bottom-4 w-32 h-32 text-brand-500 opacity-20 transform -rotate-12 group-hover:rotate-0 transition-transform duration-1000" />
                                <div className="relative z-10">
                                    <h4 className="font-black italic uppercase tracking-tighter text-xl mb-2">Member Perks</h4>
                                    <p className="text-xs font-bold text-brand-100 mb-4 opacity-80 leading-relaxed">
                                        Unlock secret prices and 24/7 VIP concierge support when you sign in.
                                    </p>
                                    <Link href="/auth/login" className="text-[10px] font-black uppercase tracking-[0.2em] bg-white text-brand-600 px-4 py-2 rounded-full inline-block hover:scale-105 transition-transform">
                                        Join Now
                                    </Link>
                                </div>
                            </div>
                        </motion.div>
                    </div>
                </div>

                {/* Mobile Bottom Bar */}
                <AnimatePresence>
                    <motion.div 
                        initial={{ y: 100 }}
                        animate={{ y: 0 }}
                        className="fixed bottom-6 left-6 right-6 lg:hidden bg-slate-900/95 backdrop-blur-2xl border border-white/10 p-5 z-40 rounded-[32px] shadow-2xl flex items-center justify-between"
                    >
                        <div className="flex flex-col">
                            <p className="text-[8px] text-slate-400 font-black uppercase tracking-[0.2em] mb-0.5">Pay Now (18%)</p>
                            <p className="text-xl font-black text-white tracking-tight italic">
                                {formatPrice(Math.round((hotel.pricePerNight + (hotel.pricePerNight * 0.12)) * 0.18))}
                            </p>
                            <p className="text-[7px] text-brand-400 font-bold uppercase tracking-widest mt-0.5">Deposit only</p>
                        </div>
                        <Link
                            href={`/booking/${hotel.id}`}
                            className="px-8 py-4 bg-brand-600 hover:bg-brand-500 text-white font-black rounded-2xl transition-all shadow-xl shadow-brand-600/20 active:scale-95 text-xs uppercase tracking-[0.2em]"
                        >
                            Reserve
                        </Link>
                    </motion.div>
                </AnimatePresence>
            </div>
        </div>
    );
}
