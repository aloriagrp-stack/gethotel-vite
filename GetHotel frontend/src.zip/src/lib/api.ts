const API_URL = process.env.NEXT_PUBLIC_API_URL || 'http://192.168.43.117:5000/api';

export const apiFetch = async (endpoint: string, options: RequestInit = {}) => {
    const token = typeof window !== 'undefined' ? localStorage.getItem('token') : null;

    const headers = {
        'Content-Type': 'application/json',
        ...(token && { Authorization: `Bearer ${token}` }),
        ...options.headers,
    };

    const response = await fetch(`${API_URL}${endpoint}`, {
        ...options,
        headers,
    });

    const data = await response.json();

    if (!response.ok) {
        throw new Error(data.message || 'Something went wrong');
    }

    return data;
};

export const authApi = {
    login: (credentials: any) => apiFetch('/auth/login', { method: 'POST', body: JSON.stringify(credentials) }),
    register: (userData: any) => apiFetch('/auth/register', { method: 'POST', body: JSON.stringify(userData) }),
    googleLogin: (idToken: string) => apiFetch('/auth/google', { method: 'POST', body: JSON.stringify({ idToken }) }),
    getMe: () => apiFetch('/auth/me'),
};

export const hotelApi = {
    getHotels: () => apiFetch('/hotels'),
    getHotel: (id: string) => apiFetch(`/hotels/${id}`),
    getMyHotels: () => apiFetch('/hotels/my-hotels'),
    createHotel: (hotelData: any) => apiFetch('/hotels', { method: 'POST', body: JSON.stringify(hotelData) }),
    updateHotel: (id: string, hotelData: any) => apiFetch(`/hotels/${id}`, { method: 'PUT', body: JSON.stringify(hotelData) }),
    deleteHotel: (id: string) => apiFetch(`/hotels/${id}`, { method: 'DELETE' }),
    createReview: (hotelId: number, reviewData: any) => apiFetch(`/hotels/${hotelId}/reviews`, { method: 'POST', body: JSON.stringify(reviewData) }),
    getRooms: (id: string) => apiFetch(`/hotels/${id}/rooms`),
    addRoom: (hotelId: number, roomData: any) => apiFetch(`/hotels/${hotelId}/rooms`, { method: 'POST', body: JSON.stringify(roomData) }),
    updateRoom: (hotelId: number, roomId: number, roomData: any) => apiFetch(`/hotels/${hotelId}/rooms/${roomId}`, { method: 'PUT', body: JSON.stringify(roomData) }),
    deleteRoom: (hotelId: number, roomId: number) => apiFetch(`/hotels/${hotelId}/rooms/${roomId}`, { method: 'DELETE' }),
};

export const bookingApi = {
    createBooking: (bookingData: any) => apiFetch('/bookings', { method: 'POST', body: JSON.stringify(bookingData) }),
    getBookings: () => apiFetch('/bookings'),
    getMyBookings: () => apiFetch('/bookings/my-bookings'),
    getBooking: (id: string) => apiFetch(`/bookings/${id}`),
    updateBooking: (id: number, bookingData: any) => apiFetch(`/bookings/${id}`, { method: 'PUT', body: JSON.stringify(bookingData) }),
};

export const dailyRateApi = {
    getRates: (roomId: number, startDate: string, endDate: string) => 
        apiFetch(`/daily-rates?roomId=${roomId}&startDate=${startDate}&endDate=${endDate}`),
    updateRate: (rateData: { roomId: number, date: string, price: number, available?: number }) => 
        apiFetch('/daily-rates/update', { method: 'POST', body: JSON.stringify(rateData) }),
};

export const paymentApi = {
    createOrder: (bookingId: number) => apiFetch('/payments/create-order', { method: 'POST', body: JSON.stringify({ bookingId }) }),
    verifyPayment: (paymentData: any) => apiFetch('/payments/verify', { method: 'POST', body: JSON.stringify(paymentData) }),
};
