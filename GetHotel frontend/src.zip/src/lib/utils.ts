import { type ClassValue, clsx } from "clsx";
import { twMerge } from "tailwind-merge";

export function cn(...inputs: ClassValue[]) {
    return twMerge(clsx(inputs));
}

export function formatPrice(amount: number, currency = "INR"): string {
    return new Intl.NumberFormat("en-IN", {
        style: "currency",
        currency,
        maximumFractionDigits: 0,
    }).format(amount);
}

export function formatDate(dateStr: string): string {
    return new Date(dateStr).toLocaleDateString("en-IN", {
        day: "numeric",
        month: "short",
        year: "numeric",
    });
}

export function ratingLabel(rating: number): string {
    if (rating >= 9.5) return "Exceptional";
    if (rating >= 9) return "Superb";
    if (rating >= 8.5) return "Excellent";
    if (rating >= 8) return "Very Good";
    if (rating >= 7) return "Good";
    return "Fair";
}

export function ratingColor(rating: number): string {
    if (rating >= 9) return "bg-emerald-600";
    if (rating >= 8) return "bg-green-600";
    if (rating >= 7) return "bg-yellow-500";
    return "bg-orange-500";
}

export function statusColor(status: string): {
    bg: string;
    text: string;
    border: string;
} {
    switch (status) {
        case "confirmed":
            return {
                bg: "bg-emerald-50",
                text: "text-emerald-700",
                border: "border-emerald-200",
            };
        case "pending":
            return {
                bg: "bg-amber-50",
                text: "text-amber-700",
                border: "border-amber-200",
            };
        case "cancelled":
            return {
                bg: "bg-red-50",
                text: "text-red-700",
                border: "border-red-200",
            };
        case "completed":
            return {
                bg: "bg-sky-50",
                text: "text-sky-700",
                border: "border-sky-200",
            };
        default:
            return {
                bg: "bg-slate-50",
                text: "text-slate-700",
                border: "border-slate-200",
            };
    }
}

export function amenityIcon(amenity: string): string {
    const icons: Record<string, string> = {
        wifi: "📶",
        pool: "🏊",
        spa: "💆",
        gym: "🏋️",
        restaurant: "🍽️",
        bar: "🍹",
        parking: "🅿️",
        airport_shuttle: "🚌",
        pet_friendly: "🐾",
        air_conditioning: "❄️",
        room_service: "🛎️",
        laundry: "👕",
        conference_room: "💼",
        ev_charging: "⚡",
        beach_access: "🏖️",
        kids_club: "🧒",
    };
    return icons[amenity] ?? "✓";
}

export function amenityLabel(amenity: string): string {
    const labels: Record<string, string> = {
        wifi: "Free Wi-Fi",
        pool: "Swimming Pool",
        spa: "Spa & Wellness",
        gym: "Fitness Center",
        restaurant: "Restaurant",
        bar: "Bar & Lounge",
        parking: "Free Parking",
        airport_shuttle: "Airport Shuttle",
        pet_friendly: "Pet Friendly",
        air_conditioning: "Air Conditioning",
        room_service: "24/7 Room Service",
        laundry: "Laundry Service",
        conference_room: "Conference Room",
        ev_charging: "EV Charging",
        beach_access: "Beach Access",
        kids_club: "Kids Club",
    };
    return labels[amenity] ?? amenity;
}
