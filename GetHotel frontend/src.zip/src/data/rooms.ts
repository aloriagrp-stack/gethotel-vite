import type { Room } from "@/types";

export const rooms: Room[] = [
    // Hotel 1 - The Grand Meridian
    {
        id: "r1",
        hotelId: "1",
        name: "Superior King Room",
        type: "standard",
        description:
            "Elegantly appointed room with plush king bed, designer bath amenities, and city views from the 15th floor.",
        maxOccupancy: 2,
        bedConfiguration: "1 King Bed",
        sizeM2: 38,
        pricePerNight: 12500,
        images: [
            "https://images.unsplash.com/photo-1631049307264-da0ec9d70304?w=800&q=80",
        ],
        amenities: ["Free Wi-Fi", "AC", "Mini Bar", "Safe", "Bathtub", "City View"],
        isAvailable: true,
    },
    {
        id: "r2",
        hotelId: "1",
        name: "Deluxe Twin Room",
        type: "deluxe",
        description:
            "Spacious twin room perfect for colleagues or friends, featuring premium linens and a marble shower.",
        maxOccupancy: 2,
        bedConfiguration: "2 Twin Beds",
        sizeM2: 42,
        pricePerNight: 14000,
        images: [
            "https://images.unsplash.com/photo-1582719508461-905c673771fd?w=800&q=80",
        ],
        amenities: ["Free Wi-Fi", "AC", "Mini Bar", "Safe", "Walk-in Shower", "Work Desk"],
        isAvailable: true,
    },
    {
        id: "r3",
        hotelId: "1",
        name: "Meridian Grand Suite",
        type: "suite",
        description:
            "The pinnacle of luxury – a 90m² suite with a separate living area, private balcony, and butler service.",
        maxOccupancy: 3,
        bedConfiguration: "1 King Bed + Sofa Bed",
        sizeM2: 90,
        pricePerNight: 28000,
        images: [
            "https://images.unsplash.com/photo-1571003123894-1f0594d2b5d9?w=800&q=80",
        ],
        amenities: [
            "Free Wi-Fi",
            "AC",
            "Mini Bar",
            "Safe",
            "Jacuzzi",
            "Balcony",
            "Butler Service",
            "Living Room",
        ],
        isAvailable: true,
    },

    // Hotel 2 – Serenity Beach Resort
    {
        id: "r4",
        hotelId: "2",
        name: "Garden View Cottage",
        type: "standard",
        description:
            "Thatched-roof cottage surrounded by lush tropical gardens, a short stroll from the beach.",
        maxOccupancy: 2,
        bedConfiguration: "1 Queen Bed",
        sizeM2: 32,
        pricePerNight: 18000,
        images: [
            "https://images.unsplash.com/photo-1555396273-367ea4eb4db5?w=800&q=80",
        ],
        amenities: ["Free Wi-Fi", "AC", "Outdoor Shower", "Porch", "Garden View"],
        isAvailable: true,
    },
    {
        id: "r5",
        hotelId: "2",
        name: "Beach Villa",
        type: "villa",
        description:
            "Private beachfront villa with direct sand access, plunge pool, and open-air daybed.",
        maxOccupancy: 4,
        bedConfiguration: "1 King Bed + 1 Twin Bed",
        sizeM2: 120,
        pricePerNight: 42000,
        images: [
            "https://images.unsplash.com/photo-1613490493576-7fde63acd811?w=800&q=80",
        ],
        amenities: [
            "Free Wi-Fi",
            "AC",
            "Private Pool",
            "Direct Beach Access",
            "Outdoor Shower",
            "Butler Service",
        ],
        isAvailable: false,
    },

    // Hotel 7 – Rajputana Heritage Hotel
    {
        id: "r6",
        hotelId: "7",
        name: "Haveli Chamber",
        type: "standard",
        description:
            "Arched doorways, hand-painted murals and a four-poster bed create a truly royal experience.",
        maxOccupancy: 2,
        bedConfiguration: "1 King Bed",
        sizeM2: 40,
        pricePerNight: 15000,
        images: [
            "https://images.unsplash.com/photo-1463288889890-a56b2853c40f?w=800&q=80",
        ],
        amenities: [
            "Free Wi-Fi",
            "AC",
            "Heritage Furnishings",
            "Courtyard View",
            "Mini Bar",
        ],
        isAvailable: true,
    },
    {
        id: "r7",
        hotelId: "7",
        name: "Maharaja Royal Suite",
        type: "suite",
        description:
            "The grandest room in the palace, with original antique furniture, private terrace, and a drawing room.",
        maxOccupancy: 2,
        bedConfiguration: "1 Super King Bed",
        sizeM2: 110,
        pricePerNight: 38000,
        images: [
            "https://images.unsplash.com/photo-1584132967334-10e028bd69f7?w=800&q=80",
        ],
        amenities: [
            "Free Wi-Fi",
            "AC",
            "Private Terrace",
            "Drawing Room",
            "Butler Service",
            "Jacuzzi",
            "Heritage Décor",
        ],
        isAvailable: true,
    },
];

export const getRoomsByHotelId = (hotelId: string) =>
    rooms.filter((r) => r.hotelId === hotelId);
