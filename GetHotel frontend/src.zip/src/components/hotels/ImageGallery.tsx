"use client";

import { useState } from "react";
import Image from "next/image";
import { X, ChevronLeft, ChevronRight, Grid2X2, Maximize2 } from "lucide-react";
import { motion, AnimatePresence } from "framer-motion";
import { cn } from "@/lib/utils";

interface ImageGalleryProps {
    images?: string[];
    hotelName: string;
}

export default function ImageGallery({ images = [], hotelName }: ImageGalleryProps) {
    const [lightboxOpen, setLightboxOpen] = useState(false);
    const [activeIndex, setActiveIndex] = useState(0);

    if (!images || images.length === 0) {
        return (
            <div className="w-full h-[450px] bg-slate-100 flex items-center justify-center rounded-[40px] border-2 border-dashed border-slate-200">
                <p className="text-slate-400 font-bold italic uppercase tracking-widest text-xs">No imagery provided for this property</p>
            </div>
        );
    }

    const openLightbox = (index: number) => {
        setActiveIndex(index);
        setLightboxOpen(true);
    };

    const prev = () => setActiveIndex((i) => (i - 1 + images.length) % images.length);
    const next = () => setActiveIndex((i) => (i + 1) % images.length);

    return (
        <>
            {/* Gallery Grid */}
            <div className="relative group/gallery overflow-hidden">
                <div className="grid grid-cols-4 grid-rows-2 gap-3 h-[450px] sm:h-[550px]">
                    {/* Main image - 1st half */}
                    <motion.div
                        initial={{ opacity: 0, scale: 1.1 }}
                        animate={{ opacity: 1, scale: 1 }}
                        transition={{ duration: 1.2, ease: [0.16, 1, 0.3, 1] }}
                        className="col-span-2 row-span-2 relative cursor-pointer overflow-hidden group"
                        onClick={() => openLightbox(0)}
                    >
                        <Image
                            src={images[0]}
                            alt={`${hotelName} - main`}
                            fill
                            className="object-cover group-hover:scale-105 transition-all duration-1000 ease-out"
                            priority
                            sizes="(max-width: 768px) 100vw, 50vw"
                        />
                        <div className="absolute inset-0 bg-black/0 group-hover:bg-black/20 transition-all duration-500 flex items-center justify-center opacity-0 group-hover:opacity-100">
                             <Maximize2 className="w-10 h-10 text-white drop-shadow-lg" />
                        </div>
                    </motion.div>

                    {/* Side images - 2nd half */}
                    {images.slice(1, 5).map((src, i) => (
                        <motion.div
                            key={i}
                            initial={{ opacity: 0, x: 20 }}
                            animate={{ opacity: 1, x: 0 }}
                            transition={{ delay: 0.2 + i * 0.1, duration: 0.8 }}
                            className="relative cursor-pointer overflow-hidden group"
                            onClick={() => openLightbox(i + 1)}
                        >
                            <Image
                                src={src}
                                alt={`${hotelName} - photo ${i + 2}`}
                                fill
                                className="object-cover group-hover:scale-110 transition-all duration-1000 ease-out"
                                sizes="(max-width: 768px) 50vw, 25vw"
                                loading="lazy"
                            />
                            <div className="absolute inset-0 bg-black/0 group-hover:bg-black/20 transition-all duration-500" />
                        </motion.div>
                    ))}
                </div>

                {/* Floating "Show all" button */}
                <motion.button
                    initial={{ opacity: 0, y: 20 }}
                    animate={{ opacity: 1, y: 0 }}
                    transition={{ delay: 0.8 }}
                    onClick={() => openLightbox(0)}
                    className="absolute bottom-8 right-8 px-6 py-3.5 bg-white/90 backdrop-blur-xl hover:bg-white text-slate-900 text-[10px] font-black uppercase tracking-[0.2em] rounded-2xl shadow-premium flex items-center gap-3 transition-all active:scale-95 border border-white/50 z-10"
                >
                    <Grid2X2 className="w-4 h-4 text-brand-600" />
                    Explore {images.length} Imagery
                </motion.button>
            </div>

            {/* Lightbox */}
            <AnimatePresence>
                {lightboxOpen && (
                    <motion.div
                        initial={{ opacity: 0 }}
                        animate={{ opacity: 1 }}
                        exit={{ opacity: 0 }}
                        className="fixed inset-0 z-[100] bg-black/98 flex items-center justify-center backdrop-blur-3xl"
                        onClick={() => setLightboxOpen(false)}
                    >
                        <motion.button
                            initial={{ opacity: 0, y: -20 }}
                            animate={{ opacity: 1, y: 0 }}
                            onClick={() => setLightboxOpen(false)}
                            className="absolute top-8 right-8 w-14 h-14 bg-white/5 hover:bg-white/10 text-white rounded-full flex items-center justify-center transition-all border border-white/10"
                        >
                            <X className="w-6 h-6" />
                        </motion.button>

                        <button
                            onClick={(e) => { e.stopPropagation(); prev(); }}
                            className="absolute left-8 w-14 h-14 bg-white/5 hover:bg-white/10 text-white rounded-full flex items-center justify-center transition-all border border-white/10 group"
                        >
                            <ChevronLeft className="w-6 h-6 group-hover:-translate-x-1 transition-transform" />
                        </button>

                        <motion.div
                            key={activeIndex}
                            initial={{ opacity: 0, scale: 0.9, x: 20 }}
                            animate={{ opacity: 1, scale: 1, x: 0 }}
                            exit={{ opacity: 0, scale: 0.9, x: -20 }}
                            transition={{ type: "spring", damping: 25, stiffness: 200 }}
                            className="relative w-full max-w-5xl h-[75vh] mx-24"
                            onClick={(e) => e.stopPropagation()}
                        >
                            <Image
                                src={images[activeIndex]}
                                alt={`${hotelName} - ${activeIndex + 1}`}
                                fill
                                className="object-contain drop-shadow-2xl"
                                sizes="100vw"
                            />
                        </motion.div>

                        <button
                            onClick={(e) => { e.stopPropagation(); next(); }}
                            className="absolute right-8 w-14 h-14 bg-white/5 hover:bg-white/10 text-white rounded-full flex items-center justify-center transition-all border border-white/10 group"
                        >
                            <ChevronRight className="w-6 h-6 group-hover:translate-x-1 transition-transform" />
                        </button>

                        {/* Footer Info */}
                        <div className="absolute bottom-8 left-0 right-0 flex flex-col items-center gap-6">
                            <p className="text-[10px] font-black text-white/40 uppercase tracking-[0.3em]">
                                {activeIndex + 1} / {images.length} · {hotelName}
                            </p>
                            <div className="flex items-center gap-2.5">
                                {images.map((_, i) => (
                                    <button
                                        key={i}
                                        onClick={(e) => { e.stopPropagation(); setActiveIndex(i); }}
                                        className={cn(
                                            "h-1.5 rounded-full transition-all duration-500",
                                            i === activeIndex ? "bg-brand-500 w-8" : "bg-white/20 w-1.5 hover:bg-white/40"
                                        )}
                                    />
                                ))}
                            </div>
                        </div>
                    </motion.div>
                )}
            </AnimatePresence>
        </>
    );
}
