"use client";

import { useState, useEffect } from "react";
import { useRouter } from "next/navigation";
import {
    Calendar,
    Users,
    Shield,
    Check,
    Minus,
    Plus,
    ChevronDown,
    ChevronUp,
    Zap,
    Lock,
} from "lucide-react";
import { motion, AnimatePresence } from "framer-motion";
import { formatPrice } from "@/lib/utils";

interface PriceBoxProps {
    hotelId: string;
    pricePerNight: number;
    initialCheckIn?: string;
    initialCheckOut?: string;
    initialGuests?: number;
}

export default function PriceBox({
    hotelId,
    pricePerNight,
    initialCheckIn = "",
    initialCheckOut = "",
    initialGuests = 2,
}: PriceBoxProps) {
    const router = useRouter();
    const today = new Date().toISOString().split("T")[0];

    // Default check-in = tomorrow, check-out = day after tomorrow
    const defaultCheckIn = (() => {
        const d = new Date();
        d.setDate(d.getDate() + 1);
        return d.toISOString().split("T")[0];
    })();
    const defaultCheckOut = (() => {
        const d = new Date();
        d.setDate(d.getDate() + 3);
        return d.toISOString().split("T")[0];
    })();

    const [checkIn, setCheckIn] = useState(initialCheckIn || defaultCheckIn);
    const [checkOut, setCheckOut] = useState(initialCheckOut || defaultCheckOut);
    const [guests, setGuests] = useState(initialGuests);
    const [showGuests, setShowGuests] = useState(false);

    // Compute nights
    const nights = (() => {
        if (!checkIn || !checkOut) return 0;
        const diff =
            (new Date(checkOut).getTime() - new Date(checkIn).getTime()) /
            (1000 * 60 * 60 * 24);
        return Math.max(0, Math.floor(diff));
    })();

    const subtotal = pricePerNight * nights;
    const taxes = Math.round(subtotal * 0.12);
    const total = subtotal + taxes;

    // Auto-fix checkout if before check-in
    useEffect(() => {
        if (checkIn && checkOut && checkOut <= checkIn) {
            const d = new Date(checkIn);
            d.setDate(d.getDate() + 2);
            setCheckOut(d.toISOString().split("T")[0]);
        }
    }, [checkIn, checkOut]);

    const handleBook = () => {
        const params = new URLSearchParams({
            checkIn,
            checkOut,
            guests: String(guests),
        });
        router.push(`/booking/${hotelId}?${params.toString()}`);
    };

    return (
        <div className="bg-white rounded-[40px] border border-slate-100 p-8 shadow-premium relative">
            {/* Scarcity Tag */}
            <div className="absolute -top-3 left-1/2 -translate-x-1/2 bg-amber-500 text-white text-[9px] font-black uppercase tracking-[0.2em] px-4 py-1.5 rounded-full shadow-lg flex items-center gap-2 whitespace-nowrap">
                <Zap className="w-3 h-3 fill-white" />
                High Demand: 2 Rooms Left
            </div>

            {/* Price Header */}
            <div className="mb-8 flex items-end justify-between">
                <div>
                    <p className="text-[10px] font-black text-slate-400 uppercase tracking-widest mb-1">Price starts at</p>
                    <div className="flex items-baseline gap-1">
                        <span className="text-3xl font-black text-slate-950 tracking-tight">
                            {formatPrice(pricePerNight)}
                        </span>
                        <span className="text-[11px] font-bold text-slate-400 uppercase">/ night</span>
                    </div>
                </div>
                <div className="bg-emerald-50 px-3 py-1.5 rounded-xl flex items-center gap-2">
                    <div className="w-1.5 h-1.5 bg-emerald-500 rounded-full animate-pulse" />
                    <span className="text-[10px] font-black text-emerald-700 uppercase tracking-widest">Best Rate</span>
                </div>
            </div>

            {/* Booking Form */}
            <div className="space-y-4 mb-8">
                {/* Date Grid */}
                <div className="grid grid-cols-2 gap-2">
                    <div className="p-4 bg-slate-50/50 rounded-[24px] border border-slate-100 hover:border-brand-200 transition-colors cursor-pointer group">
                        <p className="text-[9px] font-black text-slate-400 uppercase tracking-widest mb-1">Check-in</p>
                        <input
                            type="date"
                            value={checkIn}
                            min={today}
                            onChange={(e) => setCheckIn(e.target.value)}
                            className="bg-transparent border-none outline-none text-sm font-black text-slate-900 w-full cursor-pointer uppercase tracking-tight"
                        />
                    </div>
                    <div className="p-4 bg-slate-50/50 rounded-[24px] border border-slate-100 hover:border-brand-200 transition-colors cursor-pointer group">
                        <p className="text-[9px] font-black text-slate-400 uppercase tracking-widest mb-1">Check-out</p>
                        <input
                            type="date"
                            value={checkOut}
                            min={checkIn || today}
                            onChange={(e) => setCheckOut(e.target.value)}
                            className="bg-transparent border-none outline-none text-sm font-black text-slate-900 w-full cursor-pointer uppercase tracking-tight"
                        />
                    </div>
                </div>

                {/* Guests Selector */}
                <div className="relative">
                    <button
                        onClick={() => setShowGuests(!showGuests)}
                        className="w-full flex items-center justify-between p-4 bg-slate-50/50 rounded-[24px] border border-slate-100 hover:border-brand-200 transition-all text-left"
                    >
                        <div>
                            <p className="text-[9px] font-black text-slate-400 uppercase tracking-widest mb-1">Occupancy</p>
                            <p className="text-sm font-black text-slate-900 uppercase tracking-tight">
                                {guests} {guests === 1 ? "Guest" : "Guests"}
                            </p>
                        </div>
                        <ChevronDown className={`w-4 h-4 text-slate-400 transition-transform duration-300 ${showGuests ? 'rotate-180' : ''}`} />
                    </button>

                    <AnimatePresence>
                        {showGuests && (
                            <motion.div 
                                initial={{ opacity: 0, y: 10, scale: 0.95 }}
                                animate={{ opacity: 1, y: 0, scale: 1 }}
                                exit={{ opacity: 0, y: 10, scale: 0.95 }}
                                className="absolute top-[calc(100%+8px)] left-0 right-0 bg-white rounded-[32px] border border-slate-100 shadow-premium p-6 z-50"
                            >
                                <div className="flex items-center justify-between">
                                    <div>
                                        <p className="text-xs font-black text-slate-900 uppercase tracking-tight">Adults</p>
                                        <p className="text-[10px] text-slate-400 font-bold">Ages 13 or above</p>
                                    </div>
                                    <div className="flex items-center gap-5">
                                        <button 
                                            onClick={() => setGuests(Math.max(1, guests - 1))}
                                            className="w-10 h-10 rounded-full border border-slate-100 flex items-center justify-center hover:bg-slate-50 transition-colors"
                                        >
                                            <Minus className="w-4 h-4 text-slate-900" />
                                        </button>
                                        <span className="text-lg font-black text-slate-950 w-4 text-center italic">{guests}</span>
                                        <button 
                                            onClick={() => setGuests(Math.min(10, guests + 1))}
                                            className="w-10 h-10 rounded-full border border-slate-100 flex items-center justify-center hover:bg-slate-50 transition-colors"
                                        >
                                            <Plus className="w-4 h-4 text-slate-900" />
                                        </button>
                                    </div>
                                </div>
                                <button 
                                    onClick={() => setShowGuests(false)}
                                    className="w-full mt-6 py-3 bg-slate-950 text-white text-[10px] font-black uppercase tracking-[0.2em] rounded-2xl"
                                >
                                    Confirm
                                </button>
                            </motion.div>
                        )}
                    </AnimatePresence>
                </div>
            </div>

            {/* Price Summary */}
            {nights > 0 && (
                <div className="mb-8 space-y-3 px-1">
                    <div className="flex justify-between text-xs font-bold text-slate-500">
                        <span>{formatPrice(pricePerNight)} × {nights} nights</span>
                        <span className="text-slate-900">{formatPrice(subtotal)}</span>
                    </div>
                    <div className="flex justify-between text-xs font-bold text-slate-500">
                        <span>Luxe Service Fee (12%)</span>
                        <span className="text-slate-900">{formatPrice(taxes)}</span>
                    </div>
                    <div className="h-px bg-slate-50 my-2" />
                    <div className="flex justify-between items-center mb-4">
                        <span className="text-sm font-black text-slate-950 uppercase tracking-tighter italic">Total Amount</span>
                        <span className="text-2xl font-black text-slate-950 tracking-tight italic">{formatPrice(total)}</span>
                    </div>

                    {/* Deposit Breakdown */}
                    <div className="bg-brand-50/50 rounded-2xl p-4 border border-brand-100 space-y-2">
                        <div className="flex justify-between items-center">
                            <span className="text-[10px] font-black text-brand-600 uppercase tracking-widest">Pay Now (18%)</span>
                            <span className="text-lg font-black text-brand-600 italic">{formatPrice(Math.round(total * 0.18))}</span>
                        </div>
                        <div className="flex justify-between items-center opacity-60">
                            <span className="text-[9px] font-bold text-slate-500 uppercase tracking-widest">Pay at Hotel (82%)</span>
                            <span className="text-sm font-black text-slate-700 italic">{formatPrice(total - Math.round(total * 0.18))}</span>
                        </div>
                    </div>
                </div>
            )}

            {/* CTA */}
            <button
                onClick={handleBook}
                disabled={nights === 0}
                className="w-full py-5 bg-brand-600 hover:bg-brand-700 text-white font-black rounded-[24px] shadow-xl shadow-brand-100 transition-all active:scale-[0.98] disabled:opacity-50 disabled:grayscale uppercase tracking-[0.2em] text-xs flex items-center justify-center gap-3"
            >
                {nights === 0 ? "Select Dates" : "Confirm Booking"}
                <Zap className="w-3.5 h-3.5 fill-white" />
            </button>

            {/* Trust Footer */}
            <div className="mt-8 space-y-4">
                <div className="flex items-center gap-4 p-4 bg-slate-50/50 rounded-2xl border border-slate-100">
                    <Lock className="w-5 h-5 text-slate-400" />
                    <div>
                        <p className="text-[10px] font-black text-slate-900 uppercase tracking-widest">Encrypted Payment</p>
                        <p className="text-[9px] text-slate-400 font-bold">Your data is safe with us</p>
                    </div>
                </div>
                
                <div className="flex items-center justify-between px-2">
                    <div className="flex items-center gap-2">
                        <Shield className="w-3 h-3 text-emerald-500" />
                        <span className="text-[9px] font-black text-slate-400 uppercase tracking-widest">Free Cancellation</span>
                    </div>
                    <div className="flex items-center gap-2">
                        <Check className="w-3 h-3 text-emerald-500" />
                        <span className="text-[9px] font-black text-slate-400 uppercase tracking-widest">No Hidden Fees</span>
                    </div>
                </div>
            </div>
        </div>
    );
}
