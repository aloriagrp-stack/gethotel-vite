"use client";

import Link from "next/link";
import { usePathname } from "next/navigation";
import { useState, useEffect, useRef } from "react";
import {
    Menu, X, MapPin, User, Heart, Bell,
    LogOut, Settings, ClipboardList, ChevronDown, UserSquare2
} from "lucide-react";
import { cn } from "@/lib/utils";
import { useWishlist } from "@/context/WishlistContext";
import { useAuth } from "@/context/AuthContext";
import { motion, AnimatePresence } from "framer-motion";

const navTranslations: Record<string, Record<string, string>> = {
    en: { home: "Home", hotels: "Hotels", bookings: "My Bookings" },
    hi: { home: "होम", hotels: "होटल", bookings: "मेरी बुकिंग" },
    de: { home: "Startseite", hotels: "Hotels", bookings: "Buchungen" },
    ja: { home: "ホーム", hotels: "ホテル", bookings: "予約" },
    fr: { home: "Accueil", hotels: "Hôtels", bookings: "Réservations" },
    es: { home: "Inicio", hotels: "Hoteles", bookings: "Mis Reservas" },
    zh: { home: "首页", hotels: "酒店", bookings: "我的预订" },
    ar: { home: "الرئيسية", hotels: "الفنادق", bookings: "حجوزاتي" },
    ru: { home: "Главная", hotels: "Отели", bookings: "Бронирования" },
    pt: { home: "Início", hotels: "Hotéis", bookings: "Reservas" }
};

export default function Navbar() {
    const [langCode, setLangCode] = useState("en");

    useEffect(() => {
        // Initial sync
        const saved = localStorage.getItem('user-language');
        if (saved) setLangCode(saved);

        // Sync on change (event listener for localStorage or custom event)
        const handleSync = () => {
            const current = localStorage.getItem('user-language');
            if (current) setLangCode(current);
        };
        window.addEventListener('storage', handleSync);
        // Custom event for same-window updates
        window.addEventListener('languageChanged', handleSync);
        
        return () => {
            window.removeEventListener('storage', handleSync);
            window.removeEventListener('languageChanged', handleSync);
        };
    }, []);

    const t = (key: string) => navTranslations[langCode]?.[key] || navTranslations['en'][key] || key;

    const navLinks = [
        { href: "/", label: t('home') },
        { href: "/hotels", label: t('hotels') },
        { href: "/my-bookings", label: t('bookings') },
    ];
    const pathname = usePathname();
    const [isScrolled, setIsScrolled] = useState(false);
    const [mobileOpen, setMobileOpen] = useState(false);
    const [dropdownOpen, setDropdownOpen] = useState(false);
    const dropdownRef = useRef<HTMLDivElement>(null);

    const { count: wishlistCount } = useWishlist();
    const { user, logout } = useAuth();

    // Is the current page a hero-style page (transparent navbar allowed)?
    const isHero = pathname === "/" || pathname === "/hotels";

    useEffect(() => {
        const handleScroll = () => setIsScrolled(window.scrollY > 40);
        window.addEventListener("scroll", handleScroll, { passive: true });
        return () => window.removeEventListener("scroll", handleScroll);
    }, []);

    // Close dropdown on click outside
    useEffect(() => {
        const handleClickOutside = (event: MouseEvent) => {
            if (dropdownRef.current && !dropdownRef.current.contains(event.target as Node)) {
                setDropdownOpen(false);
            }
        };
        document.addEventListener("mousedown", handleClickOutside);
        return () => document.removeEventListener("mousedown", handleClickOutside);
    }, []);

    // Transparent on hero (home), white always on other pages
    const solidBg = !isHero || isScrolled;

    return (
        <header
            className={cn(
                "fixed top-0 left-0 right-0 z-50 transition-all duration-700",
                isScrolled
                    ? "bg-white/80 backdrop-blur-2xl border-b border-black/5 shadow-[0_8px_40px_rgba(0,0,0,0.04)] py-1"
                    : "bg-transparent border-b border-transparent py-5"
            )}
        >
            <div className="max-w-7xl mx-auto px-6 lg:px-10">
                <div className="flex items-center justify-between h-20">

                    {/* Logo with Premium Feel */}
                    <Link
                        href="/"
                        className="flex items-center gap-2 group shrink-0"
                    >
                        <div className="relative">
                            <span className="text-3xl font-black tracking-tighter text-slate-950 group-hover:text-brand-600 transition-all duration-500 italic">
                                GetHotel<span className="text-brand-600 not-italic">.</span>
                            </span>
                            <motion.div 
                                className="absolute -bottom-1 left-0 h-0.5 bg-brand-600 rounded-full"
                                initial={{ width: 0 }}
                                whileHover={{ width: "100%" }}
                                transition={{ duration: 0.3 }}
                            />
                        </div>
                    </Link>

                    {/* Desktop Nav - Standard Text Style */}
                    <nav className="hidden md:flex items-center gap-16 absolute left-1/2 -translate-x-1/2">
                        {navLinks.map((link) => (
                            <Link
                                key={link.href}
                                href={link.href}
                                className={cn(
                                    "text-[10px] font-black uppercase tracking-[0.2em] transition-all duration-300 relative group/nav",
                                    pathname === link.href
                                        ? "text-slate-950"
                                        : "text-slate-500 hover:text-slate-950"
                                )}
                            >
                                {link.label}
                                <motion.div 
                                    className={cn(
                                        "absolute -bottom-1 left-0 h-0.5 bg-brand-600 rounded-full",
                                        pathname === link.href ? "w-full" : "w-0 group-hover/nav:w-full"
                                    )}
                                    transition={{ duration: 0.3 }}
                                />
                            </Link>
                        ))}
                    </nav>

                    {/* Desktop Actions */}
                    <div className="hidden md:flex items-center gap-4 shrink-0">
                        <button
                            className="w-10 h-10 flex items-center justify-center rounded-full transition-all text-slate-400 hover:text-slate-950 hover:bg-white/60 hover:shadow-sm"
                        >
                            <Bell className="w-4.5 h-4.5" />
                        </button>

                        <Link
                            href="/wishlist"
                            className="relative w-10 h-10 flex items-center justify-center rounded-full transition-all text-slate-400 hover:text-red-500 hover:bg-red-50/50"
                        >
                            <Heart className="w-4.5 h-4.5" />
                            {wishlistCount > 0 && (
                                <span className="absolute top-1.5 right-1.5 w-4 h-4 bg-red-600 text-white text-[9px] font-black rounded-full flex items-center justify-center ring-2 ring-white">
                                    {wishlistCount > 9 ? "9+" : wishlistCount}
                                </span>
                            )}
                        </Link>
                        
                        <div className="w-px h-6 mx-1 bg-slate-200/60" />

                        {/* Profile Section / Login Button */}
                        <div className="relative" ref={dropdownRef}>
                            {user ? (
                                <button
                                    onClick={() => setDropdownOpen(!dropdownOpen)}
                                    className="flex items-center gap-2.5 pl-2 pr-4 py-2 rounded-full border border-slate-200/80 bg-white/80 backdrop-blur-md text-slate-900 hover:border-brand-300 hover:shadow-xl transition-all duration-500 text-sm font-bold select-none shadow-premium-sm"
                                >
                                    <div className="w-9 h-9 bg-gradient-to-br from-indigo-600 to-purple-600 rounded-full flex items-center justify-center shrink-0 border-2 border-white shadow-lg">
                                        <span className="text-white text-sm font-black uppercase">
                                            {user.name ? user.name.charAt(0) : user.email.charAt(0)}
                                        </span>
                                    </div>
                                    <span className="hidden lg:inline text-xs font-black uppercase tracking-widest">{user?.name?.split(' ')[0] || "Account"}</span>
                                    <ChevronDown className={cn("w-3.5 h-3.5 text-slate-400 transition-transform duration-500", dropdownOpen && "rotate-180")} />
                                </button>
                            ) : (
                                <Link
                                    href="/login"
                                    className="px-8 py-3 bg-slate-950 text-white rounded-full text-[10px] font-black uppercase tracking-[0.2em] hover:bg-brand-600 hover:scale-[1.05] active:scale-[0.98] transition-all duration-500 shadow-xl shadow-slate-200"
                                >
                                    Sign In
                                </Link>
                            )}

                            {/* Dropdown Menu - Luxury Glass */}
                            <AnimatePresence>
                                {dropdownOpen && user && (
                                    <motion.div
                                        initial={{ opacity: 0, y: 15, scale: 0.95 }}
                                        animate={{ opacity: 1, y: 0, scale: 1 }}
                                        exit={{ opacity: 0, y: 10, scale: 0.95 }}
                                        className="absolute right-0 mt-4 w-72 bg-white/90 backdrop-blur-2xl rounded-[32px] border border-white shadow-[0_32px_80px_rgba(0,0,0,0.15)] overflow-hidden py-3 z-[60]"
                                        onClick={() => setDropdownOpen(false)}
                                    >
                                        <div className="px-4 py-3 border-b border-slate-50 mb-1">
                                            <p className="text-sm font-bold text-slate-900">{user?.name || "Welcome!"}</p>
                                            <p className="text-[11px] text-slate-500 truncate">{user?.email || "Explore your next stay"}</p>
                                        </div>

                                        <Link href="/profile" className="flex items-center gap-3 px-4 py-2.5 text-sm font-semibold text-slate-600 hover:bg-slate-50 hover:text-brand-600 transition-colors">
                                            <UserSquare2 className="w-4 h-4 opacity-70" />
                                            Profile Overview
                                        </Link>
                                        <Link href="/my-bookings" className="flex items-center gap-3 px-4 py-2.5 text-sm font-semibold text-slate-600 hover:bg-slate-50 hover:text-brand-600 transition-colors">
                                            <ClipboardList className="w-4 h-4 opacity-70" />
                                            My Bookings
                                        </Link>

                                        <div className="h-px bg-slate-50 my-1 mx-2" />

                                        <button
                                            onClick={logout}
                                            className="w-full flex items-center gap-3 px-4 py-2.5 text-sm text-red-600 font-bold hover:bg-red-50 transition-colors"
                                        >
                                            <LogOut className="w-4 h-4" />
                                            Logout
                                        </button>
                                    </motion.div>
                                )}
                            </AnimatePresence>
                        </div>
                    </div>

                    {/* Mobile Menu Trigger */}
                    <button
                        onClick={() => setMobileOpen(!mobileOpen)}
                        className="md:hidden flex items-center justify-center transition-all duration-300 active:scale-90"
                        aria-label="Toggle menu"
                    >
                        {mobileOpen ? (
                            <div className="p-2 rounded-full bg-black/5 text-slate-600">
                                <X className="w-6 h-6" />
                            </div>
                        ) : (
                            user ? (
                                <div className="w-10 h-10 rounded-full bg-gradient-to-br from-indigo-600 to-purple-600 flex items-center justify-center shadow-lg border border-white/20">
                                    <span className="text-white text-xs font-black uppercase">
                                        {user.name ? user.name.charAt(0) : user.email.charAt(0)}
                                    </span>
                                </div>
                            ) : (
                                <div className="w-10 h-10 rounded-full bg-brand-600 flex items-center justify-center shadow-lg border border-brand-400/20">
                                    <User className="w-5 h-5 text-white" />
                                </div>
                            )
                        )}
                    </button>
                </div>
            </div>

            {/* Mobile Menu Sidebar (Right Side) */}
            <AnimatePresence>
                {mobileOpen && (
                    <>
                        {/* Backdrop */}
                        <motion.div
                            initial={{ opacity: 0 }}
                            animate={{ opacity: 1 }}
                            exit={{ opacity: 0 }}
                            onClick={() => setMobileOpen(false)}
                            className="fixed inset-0 z-40 md:hidden"
                        />

                        {/* Sidebar Drawer */}
                        <motion.div
                            initial={{ x: "100%", opacity: 0 }}
                            animate={{ x: 0, opacity: 1 }}
                            exit={{ x: "100%", opacity: 0 }}
                            transition={{ type: "spring", damping: 30, stiffness: 300 }}
                            className="fixed top-[76px] right-4 w-[240px] z-50 md:hidden overflow-hidden bg-white border border-black/5 shadow-[0_20px_50px_rgba(0,0,0,0.15)] rounded-[32px] flex flex-col"
                        >
                            <div className="px-3 py-6 space-y-2">
                                {/* Menu Links */}
                                <nav className="space-y-1.5">
                                    {navLinks.map((link) => (
                                        <Link
                                            key={link.href}
                                            href={link.href}
                                            onClick={() => setMobileOpen(false)}
                                            className={cn(
                                                "flex items-center gap-3 px-4 py-3.5 rounded-[20px] transition-all duration-300",
                                                pathname === link.href
                                                    ? "bg-brand-600 text-white shadow-lg shadow-brand-600/20"
                                                    : "text-slate-900 hover:bg-black/5 font-bold"
                                            )}
                                        >
                                            {link.label === "Home" && <MapPin className={cn("w-4 h-4", pathname === link.href ? "text-white" : "text-brand-600")} />}
                                            {link.label === "Hotels" && <Heart className={cn("w-4 h-4", pathname === link.href ? "text-white" : "text-brand-600")} />}
                                            {link.label === "My Bookings" && <ClipboardList className={cn("w-4 h-4", pathname === link.href ? "text-white" : "text-brand-600")} />}
                                            <span className="text-[11px] font-black uppercase tracking-[0.15em]">{link.label}</span>
                                        </Link>
                                    ))}
                                </nav>

                                <div className="h-px bg-black/5 mx-4 my-2" />

                                <Link
                                    href="/wishlist"
                                    onClick={() => setMobileOpen(false)}
                                    className="flex items-center gap-3 px-4 py-3 text-slate-500 hover:text-red-500 transition-colors"
                                >
                                    <Heart className="w-4 h-4" />
                                    <span className="text-[10px] font-black uppercase tracking-widest">Wishlist</span>
                                    {wishlistCount > 0 && (
                                        <span className="ml-auto w-4 h-4 bg-red-500 text-white text-[9px] font-bold rounded-full flex items-center justify-center">
                                            {wishlistCount}
                                        </span>
                                    )}
                                </Link>

                                <Link
                                    href="/my-bookings"
                                    onClick={() => setMobileOpen(false)}
                                    className="flex items-center gap-3 px-4 py-3 text-slate-500 hover:text-brand-600 transition-colors"
                                >
                                    <ClipboardList className="w-4 h-4" />
                                    <span className="text-[10px] font-black uppercase tracking-widest">Bookings</span>
                                </Link>

                                <Link
                                    href="/dashboard"
                                    onClick={() => setMobileOpen(false)}
                                    className="flex items-center gap-3 px-4 py-3 text-slate-500 hover:text-brand-600 transition-colors"
                                >
                                    <UserSquare2 className="w-4 h-4" />
                                    <span className="text-[10px] font-black uppercase tracking-widest">My Profile</span>
                                </Link>
                            </div>
                        </motion.div>
                    </>
                )}
            </AnimatePresence>
        </header>
    );
}
