"use client";

import { motion } from "framer-motion";

export default function BlueWavesBackground() {
    return (
        <div className="fixed inset-0 overflow-hidden pointer-events-none z-[-1] bg-white">
            {/* Ultra Soft Mesh Gradient matching the latest light-blue image */}
            <div className="absolute inset-0" 
                style={{
                    background: `
                        radial-gradient(circle at 20% 20%, #dbeafe 0%, transparent 45%),
                        radial-gradient(circle at 80% 10%, #bfdbfe 0%, transparent 55%),
                        radial-gradient(circle at 50% 50%, #eff6ff 0%, transparent 65%),
                        radial-gradient(circle at 10% 80%, #dbeafe 0%, transparent 45%),
                        radial-gradient(circle at 90% 90%, #bfdbfe 0%, transparent 45%),
                        #f8fafc
                    `,
                    filter: 'blur(60px)',
                }}
            />

            {/* Subtle Grain Overlay for Texture */}
            <div className="absolute inset-0 opacity-[0.02] pointer-events-none mix-blend-multiply"
                style={{
                    backgroundImage: `url("data:image/svg+xml,%3Csvg viewBox='0 0 200 200' xmlns='http://www.w3.org/2000/svg'%3E%3Cfilter id='n'%3E%3CfeTurbulence type='fractalNoise' baseFrequency='0.65' numOctaves='3' stitchTiles='stitch'/%3E%3C/filter%3E%3Crect width='100%25' height='100%25' filter='url(%23n)'/%3E%3C/svg%3E")`,
                    backgroundSize: '250px 250px',
                }}
            />
        </div>
    );
}
