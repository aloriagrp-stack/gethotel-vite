"use client";

import { motion } from "framer-motion";
import { Sparkles } from "lucide-react";
import SmartSearchBar from "@/components/search/SmartSearchBar";

export default function Hero() {
    return (
        <section className="relative z-20 min-h-[90vh] flex flex-col items-center justify-center pt-32 pb-16 px-6 overflow-hidden">
            {/* Atmospheric Background Elements */}
            <div className="absolute inset-0 z-0 pointer-events-none">
                <motion.div 
                    animate={{ 
                        scale: [1, 1.2, 1],
                        rotate: [0, 90, 0],
                        x: [0, 50, 0],
                        y: [0, 30, 0]
                    }}
                    transition={{ duration: 20, repeat: Infinity, ease: "linear" }}
                    className="absolute top-[-10%] left-[-10%] w-[60%] h-[60%] bg-brand-100/30 rounded-full blur-[120px]"
                />
                <motion.div 
                    animate={{ 
                        scale: [1.2, 1, 1.2],
                        rotate: [0, -90, 0],
                        x: [0, -40, 0],
                        y: [0, 60, 0]
                    }}
                    transition={{ duration: 25, repeat: Infinity, ease: "linear" }}
                    className="absolute bottom-[-10%] right-[-10%] w-[50%] h-[50%] bg-blue-100/20 rounded-full blur-[100px]"
                />
            </div>

            <div className="relative z-10 w-full max-w-7xl mx-auto flex flex-col items-center text-center">

                {/* Primary Headline */}
                <div className="overflow-hidden mb-12">
                    <motion.h1
                        initial={{ opacity: 0, y: 40 }}
                        animate={{ opacity: 1, y: 0 }}
                        transition={{ duration: 1, ease: [0.16, 1, 0.3, 1] }}
                        className="text-6xl md:text-[90px] font-display font-black text-slate-950 tracking-[-0.04em] leading-[0.95]"
                    >
                        Where would you <br />
                        <motion.span 
                            initial={{ opacity: 0, x: -20 }}
                            animate={{ opacity: 1, x: 0 }}
                            transition={{ delay: 0.4, duration: 1 }}
                            className="text-brand-600 italic font-medium"
                        >
                            like to stay?
                        </motion.span>
                    </motion.h1>
                </div>

                {/* Interactive Search Bar Component */}
                <motion.div
                    initial={{ opacity: 0, y: 30, scale: 0.98 }}
                    animate={{ opacity: 1, y: 0, scale: 1 }}
                    transition={{ duration: 1, delay: 0.2, ease: [0.16, 1, 0.3, 1] }}
                    className="w-full"
                >
                    <SmartSearchBar className="w-full" />
                </motion.div>
            </div>

        </section>
    );
}
