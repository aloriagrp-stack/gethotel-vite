:HL["/_next/static/chunks/d3cc8265880cfe8b.css","style"]
:HL["/_next/static/chunks/a3ac94733058fc60.css","style"]
0:{"buildId":"GMMOKkrcq1P4H9DMnsa5e","tree":{"name":"","paramType":null,"paramKey":"","hasRuntimePrefetch":false,"slots":{"children":{"name":"/_not-found","paramType":null,"paramKey":"/_not-found","hasRuntimePrefetch":false,"slots":{"children":{"name":"__PAGE__","paramType":null,"paramKey":"__PAGE__","hasRuntimePrefetch":false,"slots":null,"isRootLayout":false}},"isRootLayout":false}},"isRootLayout":true},"staleTime":300}
