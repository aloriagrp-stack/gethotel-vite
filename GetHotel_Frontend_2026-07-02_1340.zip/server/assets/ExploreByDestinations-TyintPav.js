import { t as Image } from "../entry-server.js";
import { Link } from "react-router-dom";
import { jsx, jsxs } from "react/jsx-runtime";
//#region src/components/home/ExploreByDestinations.tsx
var DEFAULT_DESTINATIONS = [
	{
		name: "Goa",
		image: "https://images.unsplash.com/photo-1512343879784-a960bf40e7f2?q=80&w=800&auto=format&fit=crop",
		properties: "1,240+ Hotels"
	},
	{
		name: "Kerala",
		image: "https://images.unsplash.com/photo-1602216056096-3b40cc0c9944?q=80&w=800&auto=format&fit=crop",
		properties: "850+ Hotels"
	},
	{
		name: "Shimla",
		image: "https://images.unsplash.com/photo-1626621341517-bbf3d9990a23?q=80&w=800&auto=format&fit=crop",
		properties: "420+ Hotels"
	},
	{
		name: "Udaipur",
		image: "https://images.unsplash.com/photo-1603262110263-fb0112e7cc33?q=80&w=800&auto=format&fit=crop",
		properties: "310+ Hotels"
	},
	{
		name: "Jaipur",
		image: "https://images.unsplash.com/photo-1477587458883-47145ed94245?q=80&w=800&auto=format&fit=crop",
		properties: "540+ Hotels"
	}
];
function ExploreByDestinations({ destinations, loading = false }) {
	const displayDestinations = destinations && destinations.length > 0 ? destinations : DEFAULT_DESTINATIONS;
	const getDestinationUrl = (name, index) => {
		const n = name.toLowerCase().trim();
		if ([
			"goa",
			"jaipur",
			"manali",
			"shimla",
			"udaipur"
		].includes(n)) return `/${n}-hotels`;
		return `/hotels?city=${encodeURIComponent(name)}&destination_index=${index}`;
	};
	return /* @__PURE__ */ jsx("section", {
		className: "pt-0 pb-6 bg-transparent overflow-hidden",
		children: /* @__PURE__ */ jsxs("div", {
			className: "w-full max-w-none mx-auto px-3 md:px-8",
			children: [/* @__PURE__ */ jsx("div", {
				className: "flex flex-col md:flex-row md:items-end justify-between mb-4 gap-4",
				children: /* @__PURE__ */ jsx("div", { children: /* @__PURE__ */ jsxs("h2", {
					className: "text-3xl md:text-5xl font-bold text-slate-950 tracking-tight",
					children: ["Explore ", /* @__PURE__ */ jsx("span", {
						className: "text-brand-600",
						children: "Destinations"
					})]
				}) })
			}), /* @__PURE__ */ jsxs("div", {
				className: "flex gap-4 pb-12 overflow-x-auto snap-x snap-mandatory no-scrollbar -mx-3 md:-mx-8 px-3 md:px-8",
				children: [/* @__PURE__ */ jsx("div", { className: "w-2 shrink-0 snap-start" }), loading ? Array.from({ length: 4 }).map((_, idx) => /* @__PURE__ */ jsx("div", { className: "w-[240px] md:w-[300px] aspect-[4/5] shrink-0 snap-start bg-slate-200 animate-pulse rounded-[2rem] border border-slate-100/50 shadow-sm" }, `dest-skeleton-${idx}`)) : displayDestinations.map((dest, i) => /* @__PURE__ */ jsx("div", {
					className: "w-[240px] md:w-[300px] aspect-[4/5] shrink-0 snap-start",
					children: /* @__PURE__ */ jsxs(Link, {
						to: getDestinationUrl(dest.name, i),
						className: "group block relative w-full h-full rounded-[2rem] overflow-hidden shadow-sm hover:shadow-xl transition-all duration-500",
						children: [
							/* @__PURE__ */ jsx(Image, {
								src: dest.image,
								alt: dest.name,
								fill: true,
								className: "transition-transform duration-700 group-hover:scale-110"
							}),
							/* @__PURE__ */ jsx("div", { className: "absolute inset-0 bg-gradient-to-t from-black/80 via-transparent to-transparent" }),
							/* @__PURE__ */ jsxs("div", {
								className: "absolute bottom-6 left-6 text-white",
								children: [/* @__PURE__ */ jsx("h3", {
									className: "text-2xl font-bold",
									children: dest.name
								}), /* @__PURE__ */ jsx("p", {
									className: "text-xs font-bold opacity-70 mt-1",
									children: dest.properties
								})]
							})
						]
					})
				}, dest.name))]
			})]
		})
	});
}
//#endregion
export { ExploreByDestinations as default };
