import { Link } from "react-router-dom";
import { useState } from "react";
import { Fragment as Fragment$1, jsx, jsxs } from "react/jsx-runtime";
import { Clock, Compass, MapPin, ShieldCheck, Wallet } from "lucide-react";
//#region src/components/home/HomeSEOContent.tsx
function HomeSEOContent() {
	const [isExpanded, setIsExpanded] = useState(false);
	return /* @__PURE__ */ jsx("section", {
		className: "pt-0 pb-16 md:pt-4 md:pb-24 bg-transparent border-t border-white/20",
		children: /* @__PURE__ */ jsxs("div", {
			className: "w-full max-w-none mx-auto px-4 sm:px-6 lg:px-8 space-y-10 md:space-y-16",
			children: [
				/* @__PURE__ */ jsxs("div", {
					className: "grid grid-cols-1 lg:grid-cols-12 gap-8 lg:gap-12 items-center",
					children: [/* @__PURE__ */ jsxs("div", {
						className: "lg:col-span-7 space-y-6",
						children: [/* @__PURE__ */ jsxs("h2", {
							className: "text-3xl md:text-5xl font-bold text-slate-900 tracking-tight leading-tight",
							children: [
								"About ",
								/* @__PURE__ */ jsx("span", {
									className: "text-brand-600",
									children: "GetHotelStays"
								}),
								" — India's Premier Booking Platform"
							]
						}), /* @__PURE__ */ jsxs("p", {
							className: "text-slate-600 text-sm md:text-base leading-relaxed font-medium",
							children: [
								"Welcome to GetHotelStays, the ultimate destination for seamless, flexible, and affordable ",
								/* @__PURE__ */ jsx(Link, {
									to: "/hotels",
									className: "text-brand-600 hover:underline",
									children: "hotel booking in India"
								}),
								". Designed to cater to modern travelers, corporate professionals, and tourists alike, GetHotelStays is redefining the hospitality landscape across the country.",
								!isExpanded ? "..." : /* @__PURE__ */ jsxs(Fragment$1, { children: [
									" ",
									"Whether you are searching for a ",
									/* @__PURE__ */ jsx(Link, {
										to: "/hotels?starRating=5",
										className: "text-brand-600 hover:underline",
										children: "luxurious resort"
									}),
									" for a weekend getaway, a budget-friendly hotel for business travel, or a convenient ",
									/* @__PURE__ */ jsx(Link, {
										to: "/hotels?stayType=hourly",
										className: "text-brand-600 hover:underline",
										children: "hourly stay"
									}),
									" near transit hubs, our platform has you covered. We feature a massive directory of verified hotels and properties in India's top cities and scenic hotspots. By combining state-of-the-art technology with customer-centric policies, we ensure that booking hotels online is fast, secure, and completely transparent. At GetHotelStays, we believe that travel should be flexible, which is why we offer both full-day stays and hourly stay options at unbeatable prices. Experience the next generation of lodging services with our signature 'Pay 12% Now' model, where you secure your room online with a minimal deposit and settle the balance directly at the property upon check-in. Join millions of satisfied travelers who trust us as their go-to hotel booking platform in India."
								] }),
								/* @__PURE__ */ jsx("button", {
									onClick: () => setIsExpanded(!isExpanded),
									className: "text-brand-600 hover:text-brand-500 font-bold ml-1.5 focus:outline-none inline-flex items-center gap-0.5 hover:underline cursor-pointer",
									children: isExpanded ? "Read Less" : "Read More"
								})
							]
						})]
					}), /* @__PURE__ */ jsx("div", {
						className: "lg:col-span-5 flex justify-center",
						children: /* @__PURE__ */ jsxs("div", {
							className: "relative w-full max-w-[380px] md:max-w-[450px] aspect-square rounded-[2rem] overflow-hidden bg-slate-50 border border-white/40 shadow-xl group",
							children: [/* @__PURE__ */ jsx("img", {
								src: "/seo_about_illustration.png",
								alt: "GetHotelStays Illustration",
								className: "w-full h-full object-cover transition-transform duration-700 group-hover:scale-105",
								loading: "lazy"
							}), /* @__PURE__ */ jsx("div", { className: "absolute inset-0 bg-gradient-to-t from-brand-600/10 via-transparent to-transparent pointer-events-none" })]
						})
					})]
				}),
				/* @__PURE__ */ jsxs("div", {
					className: "space-y-6",
					children: [/* @__PURE__ */ jsx("h2", {
						className: "text-2xl md:text-4xl font-bold text-slate-900 tracking-tight",
						children: "Flexible Stays for Every Type of Traveler"
					}), /* @__PURE__ */ jsxs("div", {
						className: "grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-6",
						children: [
							/* @__PURE__ */ jsxs("div", {
								className: "bg-white/60 backdrop-blur-xl border border-white/40 p-6 rounded-[2rem] hover:shadow-xl transition-all duration-300 space-y-3",
								children: [
									/* @__PURE__ */ jsx("div", {
										className: "w-10 h-10 rounded-full bg-amber-500/10 flex items-center justify-center text-amber-600",
										children: /* @__PURE__ */ jsx(Compass, { className: "w-5 h-5" })
									}),
									/* @__PURE__ */ jsx("h3", {
										className: "text-lg font-bold text-slate-950",
										children: /* @__PURE__ */ jsx(Link, {
											to: "/hotels?starRating=5",
											className: "hover:text-brand-600 hover:underline transition-colors",
											children: "Luxury Resorts & Boutique Hotels"
										})
									}),
									/* @__PURE__ */ jsx("p", {
										className: "text-slate-500 text-xs font-semibold leading-relaxed",
										children: "Indulge in the finest hospitality India has to offer. Our luxury category features world-class hotels, heritage palaces, and boutique resorts that offer premium amenities, infinity pools, fine dining restaurants, and top-tier spa services. Perfect for family holidays, honeymoons, or premium leisure stays."
									})
								]
							}),
							/* @__PURE__ */ jsxs("div", {
								className: "bg-white/60 backdrop-blur-xl border border-white/40 p-6 rounded-[2rem] hover:shadow-xl transition-all duration-300 space-y-3",
								children: [
									/* @__PURE__ */ jsx("div", {
										className: "w-10 h-10 rounded-full bg-emerald-500/10 flex items-center justify-center text-emerald-600",
										children: /* @__PURE__ */ jsx(Wallet, { className: "w-5 h-5" })
									}),
									/* @__PURE__ */ jsx("h3", {
										className: "text-lg font-bold text-slate-950",
										children: /* @__PURE__ */ jsx(Link, {
											to: "/hotels?priceRange=budget",
											className: "hover:text-brand-600 hover:underline transition-colors",
											children: "Budget-Friendly Hotels"
										})
									}),
									/* @__PURE__ */ jsx("p", {
										className: "text-slate-500 text-xs font-semibold leading-relaxed",
										children: "Travel smart without compromising on comfort. Our budget category includes highly rated, clean, and safe rooms equipped with all essential amenities like free Wi-Fi, air conditioning, clean linen, and breakfast options. Ideal for solo travelers, backpackers, and business executives looking for value-for-money stays."
									})
								]
							}),
							/* @__PURE__ */ jsxs("div", {
								className: "bg-white/60 backdrop-blur-xl border border-white/40 p-6 rounded-[2rem] hover:shadow-xl transition-all duration-300 space-y-3",
								children: [
									/* @__PURE__ */ jsx("div", {
										className: "w-10 h-10 rounded-full bg-rose-500/10 flex items-center justify-center text-rose-600",
										children: /* @__PURE__ */ jsx(ShieldCheck, { className: "w-5 h-5" })
									}),
									/* @__PURE__ */ jsx("h3", {
										className: "text-lg font-bold text-slate-950",
										children: /* @__PURE__ */ jsx(Link, {
											to: "/hotels",
											className: "hover:text-brand-600 hover:underline transition-colors",
											children: "Couple-Friendly Retreats"
										})
									}),
									/* @__PURE__ */ jsx("p", {
										className: "text-slate-500 text-xs font-semibold leading-relaxed",
										children: "We prioritize your privacy and peace of mind. Our curated couple-friendly hotels guarantee a welcoming atmosphere for consenting adults, complete with secure surroundings, hassle-free check-ins using local ID cards, and exceptional service."
									})
								]
							}),
							/* @__PURE__ */ jsxs("div", {
								className: "bg-white/60 backdrop-blur-xl border border-white/40 p-6 rounded-[2rem] hover:shadow-xl transition-all duration-300 space-y-3",
								children: [
									/* @__PURE__ */ jsx("div", {
										className: "w-10 h-10 rounded-full bg-blue-500/10 flex items-center justify-center text-blue-600",
										children: /* @__PURE__ */ jsx(Clock, { className: "w-5 h-5" })
									}),
									/* @__PURE__ */ jsx("h3", {
										className: "text-lg font-bold text-slate-950",
										children: /* @__PURE__ */ jsx(Link, {
											to: "/hotels?stayType=hourly",
											className: "hover:text-brand-600 hover:underline transition-colors",
											children: "Hourly Stays & Transit Rooms"
										})
									}),
									/* @__PURE__ */ jsx("p", {
										className: "text-slate-500 text-xs font-semibold leading-relaxed",
										children: "Why pay for a full day when you only need a room for a few hours? Our pioneering hourly stay booking service allows you to book micro-stays for 3, 6, or 12 hours. It is the perfect solution for travelers with long layovers, quick freshen-ups, business meetings, or short transits near major airports."
									})
								]
							})
						]
					})]
				}),
				/* @__PURE__ */ jsxs("div", {
					className: "space-y-6",
					children: [/* @__PURE__ */ jsx("h2", {
						className: "text-2xl md:text-4xl font-bold text-slate-900 tracking-tight",
						children: "How It Works — Simple & Transparent Bookings"
					}), /* @__PURE__ */ jsxs("div", {
						className: "grid grid-cols-1 md:grid-cols-3 gap-8",
						children: [
							/* @__PURE__ */ jsxs("div", {
								className: "space-y-3",
								children: [
									/* @__PURE__ */ jsx("span", {
										className: "text-5xl font-black text-slate-300",
										children: "01"
									}),
									/* @__PURE__ */ jsx("h3", {
										className: "text-lg font-bold text-slate-950",
										children: "Search and Filter"
									}),
									/* @__PURE__ */ jsx("p", {
										className: "text-slate-600 text-xs font-medium leading-relaxed",
										children: "Enter your destination city or search for a specific hotel name. Pick your check-in dates and select whether you want a 'Full Day Stay' or an 'Hourly Stay'. Use our advanced smart filters to narrow down options by price range, star rating, verified amenities, or hourly durations."
									})
								]
							}),
							/* @__PURE__ */ jsxs("div", {
								className: "space-y-3",
								children: [
									/* @__PURE__ */ jsx("span", {
										className: "text-5xl font-black text-slate-300",
										children: "02"
									}),
									/* @__PURE__ */ jsx("h3", {
										className: "text-lg font-bold text-slate-950",
										children: "Select Room & Review"
									}),
									/* @__PURE__ */ jsx("p", {
										className: "text-slate-600 text-xs font-medium leading-relaxed",
										children: "Explore detailed property listings complete with verified high-resolution photo galleries, room inventories, check-in policies, and authentic guest reviews. Compare room rates, check what amenities are included, and choose the deal that best fits your itinerary."
									})
								]
							}),
							/* @__PURE__ */ jsxs("div", {
								className: "space-y-3",
								children: [
									/* @__PURE__ */ jsx("span", {
										className: "text-5xl font-black text-slate-300",
										children: "03"
									}),
									/* @__PURE__ */ jsx("h3", {
										className: "text-lg font-bold text-slate-950",
										children: "Pay 12% Deposit & Confirm"
									}),
									/* @__PURE__ */ jsx("p", {
										className: "text-slate-600 text-xs font-medium leading-relaxed",
										children: "Confirm your reservation by paying a secure 12% booking deposit online using credit/debit cards, UPI, net banking, or international payment systems. The remaining 88% is paid directly at the hotel front desk when you check in. Receive instant email confirmation and your booking ID within seconds!"
									})
								]
							})
						]
					})]
				}),
				/* @__PURE__ */ jsxs("div", {
					className: "space-y-6",
					children: [
						/* @__PURE__ */ jsx("h2", {
							className: "text-2xl md:text-4xl font-bold text-slate-900 tracking-tight",
							children: "Top Indian Destinations to Book Stays"
						}),
						/* @__PURE__ */ jsxs("div", {
							className: "grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6",
							children: [
								/* @__PURE__ */ jsxs("div", {
									className: "bg-white/40 backdrop-blur-md border border-white/30 p-6 rounded-3xl space-y-2",
									children: [/* @__PURE__ */ jsxs("div", {
										className: "flex items-center gap-2 text-slate-950",
										children: [/* @__PURE__ */ jsx(MapPin, { className: "w-4 h-4 text-blue-500" }), /* @__PURE__ */ jsx("h3", {
											className: "font-bold",
											children: /* @__PURE__ */ jsx(Link, {
												to: "/delhi-hotels",
												className: "hover:text-brand-600 hover:underline transition-colors",
												children: "Delhi"
											})
										})]
									}), /* @__PURE__ */ jsxs("p", {
										className: "text-slate-500 text-xs font-semibold leading-relaxed",
										children: [
											"Budget to luxury hotels in India's capital. Book affordable stays in Paharganj or 5-star luxury in Aerocity & Connaught Place. ",
											/* @__PURE__ */ jsx(Link, {
												to: "/delhi-hotels",
												className: "text-brand-600 hover:underline",
												children: "Delhi Hotels"
											}),
											" starting ₹699/night."
										]
									})]
								}),
								/* @__PURE__ */ jsxs("div", {
									className: "bg-white/40 backdrop-blur-md border border-white/30 p-6 rounded-3xl space-y-2",
									children: [/* @__PURE__ */ jsxs("div", {
										className: "flex items-center gap-2 text-slate-950",
										children: [/* @__PURE__ */ jsx(MapPin, { className: "w-4 h-4 text-blue-500" }), /* @__PURE__ */ jsxs("h3", {
											className: "font-bold",
											children: [
												/* @__PURE__ */ jsx(Link, {
													to: "/hotels-in/mumbai",
													className: "hover:text-brand-600 hover:underline transition-colors",
													children: "Mumbai"
												}),
												" & ",
												/* @__PURE__ */ jsx(Link, {
													to: "/hotels-in/pune",
													className: "hover:text-brand-600 hover:underline transition-colors",
													children: "Pune"
												})
											]
										})]
									}), /* @__PURE__ */ jsxs("p", {
										className: "text-slate-500 text-xs font-semibold leading-relaxed",
										children: [
											"Financial capital & IT hub. Book business hotels in BKC, luxury stays at Juhu beach, or corporate hotels in Pune. ",
											/* @__PURE__ */ jsx(Link, {
												to: "/hotels-in/mumbai",
												className: "text-brand-600 hover:underline",
												children: "Mumbai Hotels"
											}),
											" from ₹999."
										]
									})]
								}),
								/* @__PURE__ */ jsxs("div", {
									className: "bg-white/40 backdrop-blur-md border border-white/30 p-6 rounded-3xl space-y-2",
									children: [/* @__PURE__ */ jsxs("div", {
										className: "flex items-center gap-2 text-slate-950",
										children: [/* @__PURE__ */ jsx(MapPin, { className: "w-4 h-4 text-blue-500" }), /* @__PURE__ */ jsxs("h3", {
											className: "font-bold",
											children: [
												/* @__PURE__ */ jsx(Link, {
													to: "/hotels-in/bangalore",
													className: "hover:text-brand-600 hover:underline transition-colors",
													children: "Bangalore"
												}),
												" & ",
												/* @__PURE__ */ jsx(Link, {
													to: "/hotels-in/hyderabad",
													className: "hover:text-brand-600 hover:underline transition-colors",
													children: "Hyderabad"
												})
											]
										})]
									}), /* @__PURE__ */ jsxs("p", {
										className: "text-slate-500 text-xs font-semibold leading-relaxed",
										children: [
											"India's tech capitals. Find hourly stays near business parks or premium hotels in city centers. ",
											/* @__PURE__ */ jsx(Link, {
												to: "/hotels-in/bangalore",
												className: "text-brand-600 hover:underline",
												children: "Bangalore Hotels"
											}),
											" & ",
											/* @__PURE__ */ jsx(Link, {
												to: "/hotels-in/hyderabad",
												className: "text-brand-600 hover:underline",
												children: "Hyderabad Hotels"
											}),
											"."
										]
									})]
								}),
								/* @__PURE__ */ jsxs("div", {
									className: "bg-white/40 backdrop-blur-md border border-white/30 p-6 rounded-3xl space-y-2",
									children: [/* @__PURE__ */ jsxs("div", {
										className: "flex items-center gap-2 text-slate-950",
										children: [/* @__PURE__ */ jsx(MapPin, { className: "w-4 h-4 text-blue-500" }), /* @__PURE__ */ jsx("h3", {
											className: "font-bold",
											children: /* @__PURE__ */ jsx(Link, {
												to: "/goa-hotels",
												className: "hover:text-brand-600 hover:underline transition-colors",
												children: "Goa Beach Resorts"
											})
										})]
									}), /* @__PURE__ */ jsxs("p", {
										className: "text-slate-500 text-xs font-semibold leading-relaxed",
										children: [
											"Beach holiday paradise. Serene resorts in South Goa, party stays in North Goa. ",
											/* @__PURE__ */ jsx(Link, {
												to: "/goa-hotels",
												className: "text-brand-600 hover:underline",
												children: "Hotels in Goa"
											}),
											" with hourly stays & beach access."
										]
									})]
								}),
								/* @__PURE__ */ jsxs("div", {
									className: "bg-white/40 backdrop-blur-md border border-white/30 p-6 rounded-3xl space-y-2",
									children: [/* @__PURE__ */ jsxs("div", {
										className: "flex items-center gap-2 text-slate-950",
										children: [/* @__PURE__ */ jsx(MapPin, { className: "w-4 h-4 text-blue-500" }), /* @__PURE__ */ jsxs("h3", {
											className: "font-bold",
											children: [
												/* @__PURE__ */ jsx(Link, {
													to: "/jaipur-hotels",
													className: "hover:text-brand-600 hover:underline transition-colors",
													children: "Jaipur"
												}),
												" & ",
												/* @__PURE__ */ jsx(Link, {
													to: "/udaipur-hotels",
													className: "hover:text-brand-600 hover:underline transition-colors",
													children: "Udaipur"
												})
											]
										})]
									}), /* @__PURE__ */ jsxs("p", {
										className: "text-slate-500 text-xs font-semibold leading-relaxed",
										children: [
											"Royal Rajasthan. Heritage properties, palace stays in Udaipur & boutique hotels in Pink City Jaipur. ",
											/* @__PURE__ */ jsx(Link, {
												to: "/jaipur-hotels",
												className: "text-brand-600 hover:underline",
												children: "Jaipur Hotels"
											}),
											" & ",
											/* @__PURE__ */ jsx(Link, {
												to: "/hotels-in/jodhpur",
												className: "text-brand-600 hover:underline",
												children: "Jodhpur Hotels"
											}),
											"."
										]
									})]
								}),
								/* @__PURE__ */ jsxs("div", {
									className: "bg-white/40 backdrop-blur-md border border-white/30 p-6 rounded-3xl space-y-2",
									children: [/* @__PURE__ */ jsxs("div", {
										className: "flex items-center gap-2 text-slate-950",
										children: [/* @__PURE__ */ jsx(MapPin, { className: "w-4 h-4 text-blue-500" }), /* @__PURE__ */ jsxs("h3", {
											className: "font-bold",
											children: [
												/* @__PURE__ */ jsx(Link, {
													to: "/shimla-hotels",
													className: "hover:text-brand-600 hover:underline transition-colors",
													children: "Shimla"
												}),
												" & ",
												/* @__PURE__ */ jsx(Link, {
													to: "/manali-hotels",
													className: "hover:text-brand-600 hover:underline transition-colors",
													children: "Manali"
												})
											]
										})]
									}), /* @__PURE__ */ jsxs("p", {
										className: "text-slate-500 text-xs font-semibold leading-relaxed",
										children: [
											"Himalayan getaways. Forest lodges on Mall Road, luxury mountain resorts in Manali. ",
											/* @__PURE__ */ jsx(Link, {
												to: "/shimla-hotels",
												className: "text-brand-600 hover:underline",
												children: "Shimla Hotels"
											}),
											" & ",
											/* @__PURE__ */ jsx(Link, {
												to: "/hotels-in/darjeeling",
												className: "text-brand-600 hover:underline",
												children: "Darjeeling Hotels"
											}),
											"."
										]
									})]
								})
							]
						}),
						/* @__PURE__ */ jsxs("div", {
							className: "flex flex-wrap justify-center gap-3 pt-4",
							children: [
								/* @__PURE__ */ jsx(Link, {
									to: "/hotels-in/chennai",
									className: "px-4 py-2 bg-white/60 border border-slate-200 rounded-xl text-xs font-bold text-slate-700 hover:bg-brand-50 hover:text-brand-700 transition-all",
									children: "Chennai Hotels"
								}),
								/* @__PURE__ */ jsx(Link, {
									to: "/hotels-in/kolkata",
									className: "px-4 py-2 bg-white/60 border border-slate-200 rounded-xl text-xs font-bold text-slate-700 hover:bg-brand-50 hover:text-brand-700 transition-all",
									children: "Kolkata Hotels"
								}),
								/* @__PURE__ */ jsx(Link, {
									to: "/hotels-in/ahmedabad",
									className: "px-4 py-2 bg-white/60 border border-slate-200 rounded-xl text-xs font-bold text-slate-700 hover:bg-brand-50 hover:text-brand-700 transition-all",
									children: "Ahmedabad Hotels"
								}),
								/* @__PURE__ */ jsx(Link, {
									to: "/hotels-in/lucknow",
									className: "px-4 py-2 bg-white/60 border border-slate-200 rounded-xl text-xs font-bold text-slate-700 hover:bg-brand-50 hover:text-brand-700 transition-all",
									children: "Lucknow Hotels"
								}),
								/* @__PURE__ */ jsx(Link, {
									to: "/hotels-in/amritsar",
									className: "px-4 py-2 bg-white/60 border border-slate-200 rounded-xl text-xs font-bold text-slate-700 hover:bg-brand-50 hover:text-brand-700 transition-all",
									children: "Amritsar Hotels"
								}),
								/* @__PURE__ */ jsx(Link, {
									to: "/hotels-in/varanasi",
									className: "px-4 py-2 bg-white/60 border border-slate-200 rounded-xl text-xs font-bold text-slate-700 hover:bg-brand-50 hover:text-brand-700 transition-all",
									children: "Varanasi Hotels"
								}),
								/* @__PURE__ */ jsx(Link, {
									to: "/hotels-in/agra",
									className: "px-4 py-2 bg-white/60 border border-slate-200 rounded-xl text-xs font-bold text-slate-700 hover:bg-brand-50 hover:text-brand-700 transition-all",
									children: "Agra Hotels"
								}),
								/* @__PURE__ */ jsx(Link, {
									to: "/hotels-in/coimbatore",
									className: "px-4 py-2 bg-white/60 border border-slate-200 rounded-xl text-xs font-bold text-slate-700 hover:bg-brand-50 hover:text-brand-700 transition-all",
									children: "Coimbatore Hotels"
								}),
								/* @__PURE__ */ jsx(Link, {
									to: "/hotels-in/indore",
									className: "px-4 py-2 bg-white/60 border border-slate-200 rounded-xl text-xs font-bold text-slate-700 hover:bg-brand-50 hover:text-brand-700 transition-all",
									children: "Indore Hotels"
								}),
								/* @__PURE__ */ jsx(Link, {
									to: "/hotels-in/bhopal",
									className: "px-4 py-2 bg-white/60 border border-slate-200 rounded-xl text-xs font-bold text-slate-700 hover:bg-brand-50 hover:text-brand-700 transition-all",
									children: "Bhopal Hotels"
								}),
								/* @__PURE__ */ jsx(Link, {
									to: "/hotels-in/chandigarh",
									className: "px-4 py-2 bg-white/60 border border-slate-200 rounded-xl text-xs font-bold text-slate-700 hover:bg-brand-50 hover:text-brand-700 transition-all",
									children: "Chandigarh Hotels"
								}),
								/* @__PURE__ */ jsx(Link, {
									to: "/hotels-in/nagpur",
									className: "px-4 py-2 bg-white/60 border border-slate-200 rounded-xl text-xs font-bold text-slate-700 hover:bg-brand-50 hover:text-brand-700 transition-all",
									children: "Nagpur Hotels"
								}),
								/* @__PURE__ */ jsx(Link, {
									to: "/hotels-in/kochi",
									className: "px-4 py-2 bg-white/60 border border-slate-200 rounded-xl text-xs font-bold text-slate-700 hover:bg-brand-50 hover:text-brand-700 transition-all",
									children: "Kochi Hotels"
								}),
								/* @__PURE__ */ jsx(Link, {
									to: "/hotels-in/mysore",
									className: "px-4 py-2 bg-white/60 border border-slate-200 rounded-xl text-xs font-bold text-slate-700 hover:bg-brand-50 hover:text-brand-700 transition-all",
									children: "Mysore Hotels"
								}),
								/* @__PURE__ */ jsx(Link, {
									to: "/hotels-in/madurai",
									className: "px-4 py-2 bg-white/60 border border-slate-200 rounded-xl text-xs font-bold text-slate-700 hover:bg-brand-50 hover:text-brand-700 transition-all",
									children: "Madurai Hotels"
								}),
								/* @__PURE__ */ jsx(Link, {
									to: "/hotels-in/surat",
									className: "px-4 py-2 bg-white/60 border border-slate-200 rounded-xl text-xs font-bold text-slate-700 hover:bg-brand-50 hover:text-brand-700 transition-all",
									children: "Surat Hotels"
								}),
								/* @__PURE__ */ jsx(Link, {
									to: "/hotels-in/srinagar",
									className: "px-4 py-2 bg-white/60 border border-slate-200 rounded-xl text-xs font-bold text-slate-700 hover:bg-brand-50 hover:text-brand-700 transition-all",
									children: "Srinagar Hotels"
								}),
								/* @__PURE__ */ jsx(Link, {
									to: "/hotels-in/rishikesh",
									className: "px-4 py-2 bg-white/60 border border-slate-200 rounded-xl text-xs font-bold text-slate-700 hover:bg-brand-50 hover:text-brand-700 transition-all",
									children: "Rishikesh Hotels"
								}),
								/* @__PURE__ */ jsx(Link, {
									to: "/hotels-in/haridwar",
									className: "px-4 py-2 bg-white/60 border border-slate-200 rounded-xl text-xs font-bold text-slate-700 hover:bg-brand-50 hover:text-brand-700 transition-all",
									children: "Haridwar Hotels"
								}),
								/* @__PURE__ */ jsx(Link, {
									to: "/hotels-in/jaisalmer",
									className: "px-4 py-2 bg-white/60 border border-slate-200 rounded-xl text-xs font-bold text-slate-700 hover:bg-brand-50 hover:text-brand-700 transition-all",
									children: "Jaisalmer Hotels"
								}),
								/* @__PURE__ */ jsx(Link, {
									to: "/hotels-in/ooty",
									className: "px-4 py-2 bg-white/60 border border-slate-200 rounded-xl text-xs font-bold text-slate-700 hover:bg-brand-50 hover:text-brand-700 transition-all",
									children: "Ooty Hotels"
								}),
								/* @__PURE__ */ jsx(Link, {
									to: "/hotels-in/munnar",
									className: "px-4 py-2 bg-white/60 border border-slate-200 rounded-xl text-xs font-bold text-slate-700 hover:bg-brand-50 hover:text-brand-700 transition-all",
									children: "Munnar Hotels"
								}),
								/* @__PURE__ */ jsx(Link, {
									to: "/hotels-in/alleppey",
									className: "px-4 py-2 bg-white/60 border border-slate-200 rounded-xl text-xs font-bold text-slate-700 hover:bg-brand-50 hover:text-brand-700 transition-all",
									children: "Alleppey Hotels"
								}),
								/* @__PURE__ */ jsx(Link, {
									to: "/hotels-in/coorg",
									className: "px-4 py-2 bg-white/60 border border-slate-200 rounded-xl text-xs font-bold text-slate-700 hover:bg-brand-50 hover:text-brand-700 transition-all",
									children: "Coorg Hotels"
								}),
								/* @__PURE__ */ jsx(Link, {
									to: "/hotels-in/puducherry",
									className: "px-4 py-2 bg-white/60 border border-slate-200 rounded-xl text-xs font-bold text-slate-700 hover:bg-brand-50 hover:text-brand-700 transition-all",
									children: "Puducherry Hotels"
								})
							]
						})
					]
				}),
				/* @__PURE__ */ jsxs("div", {
					className: "space-y-6 bg-gradient-to-br from-blue-50/80 to-white border border-blue-100/60 rounded-[2.5rem] p-8 md:p-12",
					children: [
						/* @__PURE__ */ jsxs("div", {
							className: "max-w-3xl",
							children: [/* @__PURE__ */ jsx("h2", {
								className: "text-2xl md:text-4xl font-bold text-slate-900 tracking-tight mb-4",
								children: "Book Hotels in Delhi — Affordable Stays for NRIs & International Travelers"
							}), /* @__PURE__ */ jsxs("p", {
								className: "text-slate-600 text-xs md:text-sm font-semibold leading-relaxed",
								children: [
									"Planning a trip to India this season? ",
									/* @__PURE__ */ jsx(Link, {
										to: "/delhi-hotels",
										className: "text-brand-600 hover:underline font-bold",
										children: "Hotels in Delhi"
									}),
									" are your gateway to India's rich history, culture, and business opportunities. Whether you are an NRI flying in from ",
									/* @__PURE__ */ jsx("strong", { children: "USA, UK, UAE, Canada, or Australia" }),
									", or an international tourist exploring the capital, GetHotelStays makes it easy to ",
									/* @__PURE__ */ jsx(Link, {
										to: "/delhi-hotels",
										className: "text-brand-600 hover:underline font-bold",
										children: "book affordable hotels in Delhi"
									}),
									" with just 12% payment online."
								]
							})]
						}),
						/* @__PURE__ */ jsxs("div", {
							className: "grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-5",
							children: [
								/* @__PURE__ */ jsxs("div", {
									className: "bg-white/80 backdrop-blur-sm rounded-2xl p-5 border border-blue-50 space-y-2",
									children: [/* @__PURE__ */ jsx("h3", {
										className: "font-bold text-slate-950 text-sm",
										children: /* @__PURE__ */ jsx(Link, {
											to: "/delhi-hotels",
											className: "hover:text-brand-600",
											children: "Affordable Hotels Near Delhi Airport"
										})
									}), /* @__PURE__ */ jsx("p", {
										className: "text-slate-500 text-xs font-medium",
										children: "Budget hotels in Mahipalpur & Aerocity from ₹699/night. Free airport pickup, soundproof rooms, hourly stays available for transit travelers. Book from anywhere in the world."
									})]
								}),
								/* @__PURE__ */ jsxs("div", {
									className: "bg-white/80 backdrop-blur-sm rounded-2xl p-5 border border-blue-50 space-y-2",
									children: [/* @__PURE__ */ jsx("h3", {
										className: "font-bold text-slate-950 text-sm",
										children: /* @__PURE__ */ jsx(Link, {
											to: "/delhi-hotels",
											className: "hover:text-brand-600",
											children: "Budget Hotels in Paharganj & Karol Bagh"
										})
									}), /* @__PURE__ */ jsx("p", {
										className: "text-slate-500 text-xs font-medium",
										children: "Delhi's most affordable areas for budget travelers. Clean rooms starting from ₹500/night. Walking distance to New Delhi Railway Station, local markets & street food. Verified & safe."
									})]
								}),
								/* @__PURE__ */ jsxs("div", {
									className: "bg-white/80 backdrop-blur-sm rounded-2xl p-5 border border-blue-50 space-y-2",
									children: [/* @__PURE__ */ jsx("h3", {
										className: "font-bold text-slate-950 text-sm",
										children: /* @__PURE__ */ jsx(Link, {
											to: "/delhi-hotels",
											className: "hover:text-brand-600",
											children: "Luxury Hotels in Connaught Place & Aerocity"
										})
									}), /* @__PURE__ */ jsx("p", {
										className: "text-slate-500 text-xs font-medium",
										children: "5-star luxury in central Delhi. World-class hotels near India Gate, shopping districts & business hubs. Premium amenities, fine dining, pool & spa. Pay 12% now, rest at hotel."
									})]
								}),
								/* @__PURE__ */ jsxs("div", {
									className: "bg-white/80 backdrop-blur-sm rounded-2xl p-5 border border-blue-50 space-y-2",
									children: [/* @__PURE__ */ jsx("h3", {
										className: "font-bold text-slate-950 text-sm",
										children: /* @__PURE__ */ jsx(Link, {
											to: "/delhi-hotels",
											className: "hover:text-brand-600",
											children: "NRI Hotel Booking — Pay in Your Currency"
										})
									}), /* @__PURE__ */ jsx("p", {
										className: "text-slate-500 text-xs font-medium",
										children: "NRIs can book Delhi hotels using international cards, PayPal, or bank transfer. Pay only 12% online in USD, GBP, or AED. Rest at hotel in INR. Trusted by 10,000+ overseas travelers."
									})]
								})
							]
						}),
						/* @__PURE__ */ jsx("div", {
							className: "pt-2",
							children: /* @__PURE__ */ jsx(Link, {
								to: "/delhi-hotels",
								className: "inline-flex items-center gap-2 px-6 py-3 bg-brand-600 hover:bg-brand-500 text-white font-bold text-xs uppercase tracking-wider rounded-xl transition-all shadow-md active:scale-95",
								children: "Explore All Delhi Hotels →"
							})
						})
					]
				}),
				/* @__PURE__ */ jsxs("div", {
					className: "bg-white/70 backdrop-blur-xl border border-white/40 rounded-[2.5rem] p-8 md:p-12 space-y-8",
					children: [/* @__PURE__ */ jsxs("div", {
						className: "max-w-3xl",
						children: [/* @__PURE__ */ jsx("h2", {
							className: "text-2xl md:text-4xl font-bold text-slate-900 tracking-tight mb-4",
							children: "Why Travelers Trust GetHotelStays"
						}), /* @__PURE__ */ jsx("p", {
							className: "text-slate-600 text-xs md:text-sm font-semibold leading-relaxed",
							children: "When you choose GetHotelStays for your next hotel booking in India, you are choosing a partner dedicated to your comfort and security. We maintain absolute transparency to guarantee peace of mind."
						})]
					}), /* @__PURE__ */ jsxs("div", {
						className: "grid grid-cols-1 md:grid-cols-2 gap-8",
						children: [
							/* @__PURE__ */ jsxs("div", {
								className: "space-y-2",
								children: [/* @__PURE__ */ jsxs("h3", {
									className: "font-bold text-slate-950 flex items-center gap-2",
									children: [/* @__PURE__ */ jsx("span", { className: "w-1.5 h-1.5 rounded-full bg-emerald-500" }), "Zero Hidden Booking Charges"]
								}), /* @__PURE__ */ jsx("p", {
									className: "text-slate-500 text-xs leading-relaxed font-semibold",
									children: "What you see is what you pay. We do not add surprise booking fees, service taxes, or processing charges at checkout. All taxes are clearly detailed upfront so you can stay within your budget."
								})]
							}),
							/* @__PURE__ */ jsxs("div", {
								className: "space-y-2",
								children: [/* @__PURE__ */ jsxs("h3", {
									className: "font-bold text-slate-950 flex items-center gap-2",
									children: [/* @__PURE__ */ jsx("span", { className: "w-1.5 h-1.5 rounded-full bg-emerald-500" }), "Rigorous 50-Point Quality Audit"]
								}), /* @__PURE__ */ jsx("p", {
									className: "text-slate-500 text-xs leading-relaxed font-semibold",
									children: "Every single hotel listed on our platform undergoes strict quality audits. We inspect clean bathrooms, functioning air conditioning, high-speed Wi-Fi, property safety measures, and staff hospitality to ensure consistency."
								})]
							}),
							/* @__PURE__ */ jsxs("div", {
								className: "space-y-2",
								children: [/* @__PURE__ */ jsxs("h3", {
									className: "font-bold text-slate-950 flex items-center gap-2",
									children: [/* @__PURE__ */ jsx("span", { className: "w-1.5 h-1.5 rounded-full bg-emerald-500" }), "Zero Risk Booking (Pay 12% Now)"]
								}), /* @__PURE__ */ jsx("p", {
									className: "text-slate-500 text-xs leading-relaxed font-semibold",
									children: "Protect your finances by avoiding massive advance payments. Our unique booking model keeps you in control, allowing you to pay the majority of the room rate only after verifying the property in person during check-in."
								})]
							}),
							/* @__PURE__ */ jsxs("div", {
								className: "space-y-2",
								children: [/* @__PURE__ */ jsxs("h3", {
									className: "font-bold text-slate-950 flex items-center gap-2",
									children: [/* @__PURE__ */ jsx("span", { className: "w-1.5 h-1.5 rounded-full bg-emerald-500" }), "Flexible Cancellation & Refund Policies"]
								}), /* @__PURE__ */ jsx("p", {
									className: "text-slate-500 text-xs leading-relaxed font-semibold",
									children: "Plans can change unexpectedly. That is why most of our partner hotels offer free cancellation and modification options up to 24 hours prior to check-in, giving you absolute freedom to adapt."
								})]
							})
						]
					})]
				})
			]
		})
	});
}
//#endregion
export { HomeSEOContent as default };
