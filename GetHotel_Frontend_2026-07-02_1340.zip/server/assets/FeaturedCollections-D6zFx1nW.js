import { t as Image$1 } from "../entry-server.js";
import { Link } from "react-router-dom";
import { jsx, jsxs } from "react/jsx-runtime";
import { ArrowUpRight, Crown, Heart, Users, Wallet } from "lucide-react";
//#region src/components/home/FeaturedCollections.tsx
var ICONS = {
	"Luxury Stays": Crown,
	"Budget Friendly": Wallet,
	"Couple Retreats": Heart,
	"Family Friendly": Users
};
var COLORS = [
	"from-amber-500/20 to-amber-600/20",
	"from-emerald-500/20 to-emerald-600/20",
	"from-rose-500/20 to-rose-600/20",
	"from-blue-500/20 to-blue-600/20"
];
var DEFAULT_COLLECTIONS = [
	{
		title: "Luxury Stays",
		subtitle: "The ultimate premium experience",
		image: "https://images.unsplash.com/photo-1542314831-068cd1dbfeeb?q=80&w=800&auto=format&fit=crop",
		label: "Premium"
	},
	{
		title: "Budget Friendly",
		subtitle: "Best value without compromise",
		image: "https://images.unsplash.com/photo-1566073771259-6a8506099945?q=80&w=800&auto=format&fit=crop",
		label: "Affordable"
	},
	{
		title: "Couple Retreats",
		subtitle: "Romantic getaways for two",
		image: "https://images.unsplash.com/photo-1510414842594-a61c69b5ae57?q=80&w=800&auto=format&fit=crop",
		label: "Romantic"
	},
	{
		title: "Family Friendly",
		subtitle: "Memorable stays for all ages",
		image: "https://images.unsplash.com/photo-1566665797739-1674de7a421a?q=80&w=800&auto=format&fit=crop",
		label: "Spacious"
	}
];
function FeaturedCollections({ collections, loading = false }) {
	const displayCollections = collections && collections.length > 0 ? collections : DEFAULT_COLLECTIONS;
	return /* @__PURE__ */ jsx("section", {
		className: "pt-0 pb-0 bg-transparent",
		children: /* @__PURE__ */ jsxs("div", {
			className: "w-full max-w-none mx-auto px-3 md:px-8",
			children: [/* @__PURE__ */ jsx("div", {
				className: "mb-4",
				children: /* @__PURE__ */ jsxs("h2", {
					className: "text-3xl md:text-5xl font-bold text-slate-900 tracking-tight",
					children: ["Featured ", /* @__PURE__ */ jsx("span", {
						className: "text-brand-600",
						children: "Collections"
					})]
				})
			}), /* @__PURE__ */ jsxs("div", {
				className: "flex gap-4 pb-4 overflow-x-auto snap-x snap-mandatory no-scrollbar -mx-3 md:-mx-8 px-3 md:px-8 lg:-mx-0",
				children: [/* @__PURE__ */ jsx("div", { className: "w-2 shrink-0 snap-start md:hidden" }), loading ? Array.from({ length: 4 }).map((_, idx) => /* @__PURE__ */ jsx("div", { className: "min-w-[210px] md:min-w-[320px] aspect-[4/5] md:aspect-[4/3] shrink-0 snap-start bg-slate-200 animate-pulse rounded-[2rem] border border-slate-100/50 shadow-sm" }, `coll-skeleton-${idx}`)) : displayCollections.map((item, i) => {
					ICONS[item.title];
					COLORS[i % COLORS.length];
					return /* @__PURE__ */ jsx("div", {
						className: "min-w-[210px] md:min-w-[320px] snap-start flex",
						children: /* @__PURE__ */ jsx("div", {
							className: "flex flex-col flex-1 h-full bg-white/70 backdrop-blur-xl rounded-[2rem] overflow-hidden shadow-sm hover:shadow-2xl transition-all duration-300 border border-white/40 group cursor-pointer",
							children: /* @__PURE__ */ jsxs(Link, {
								to: collections && collections.length > 0 ? `/hotels?collection_index=${i}` : `/hotels?collection=${item.title.toLowerCase().split(" ")[0]}`,
								className: "block h-full w-full flex flex-col",
								children: [/* @__PURE__ */ jsxs("div", {
									className: "relative aspect-[4/5] md:aspect-[4/3] w-full overflow-hidden bg-slate-100",
									children: [/* @__PURE__ */ jsx(Image$1, {
										src: item.image,
										alt: item.title,
										fill: true,
										className: "transition-transform duration-700 group-hover:scale-110"
									}), /* @__PURE__ */ jsx("div", {
										className: "absolute top-4 left-4",
										children: /* @__PURE__ */ jsx("span", {
											className: "bg-white px-3 py-1 rounded-full text-[9px] font-bold text-slate-900 uppercase tracking-widest shadow-lg",
											children: item.label
										})
									})]
								}), /* @__PURE__ */ jsxs("div", {
									className: "p-5 flex flex-col flex-1 gap-2",
									children: [
										/* @__PURE__ */ jsx("h3", {
											className: "text-xl md:text-2xl font-bold text-slate-900 leading-tight tracking-tight",
											children: item.title
										}),
										/* @__PURE__ */ jsx("p", {
											className: "text-slate-500 text-xs font-semibold",
											children: item.subtitle
										}),
										/* @__PURE__ */ jsx("div", {
											className: "mt-auto pt-3 flex items-center justify-between",
											children: /* @__PURE__ */ jsxs("div", {
												className: "flex items-center gap-2 text-brand-600 font-bold text-xs uppercase tracking-widest",
												children: ["View All", /* @__PURE__ */ jsx(ArrowUpRight, { className: "w-3.5 h-3.5 transform transition-transform duration-300 group-hover:-rotate-12" })]
											})
										})
									]
								})]
							})
						})
					}, item.title);
				})]
			})]
		})
	});
}
//#endregion
export { FeaturedCollections as default };
