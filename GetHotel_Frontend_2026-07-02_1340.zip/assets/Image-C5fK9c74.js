import{o as e,t}from"./jsx-runtime-DBS2Xqfh.js";import{t as n}from"./react-C2WwSdKL.js";var r=e(n(),1),i=t(),a=(e,t,n)=>{if(!e||!e.includes(`images.unsplash.com`))return e;try{let r=new URL(e);return r.searchParams.set(`auto`,`format`),r.searchParams.set(`fit`,`crop`),r.searchParams.set(`q`,n?`75`:`60`),t&&!isNaN(Number(t))?r.searchParams.set(`w`,String(t)):r.searchParams.set(`w`,n?`1200`:`600`),r.toString()}catch{return e}},o=({src:e,alt:t,width:n,height:o,fill:s,priority:c,unoptimized:l,className:u,...d})=>{let[f,p]=r.useState(!1),m=r.useRef(null);r.useEffect(()=>{p(!1),m.current&&m.current.complete&&p(!0)},[e]);let h=s?{position:`relative`,height:`100%`,width:`100%`,overflow:`hidden`}:{position:`relative`,display:`inline-block`,width:n||`auto`,height:o||`auto`,overflow:`hidden`},g=s?{position:`absolute`,height:`100%`,width:`100%`,left:0,top:0,right:0,bottom:0,objectFit:`cover`,opacity:+!!f,transition:`opacity 0.4s ease-in-out`}:{opacity:+!!f,transition:`opacity 0.4s ease-in-out`},_=l?e:a(e,n,c);return(0,i.jsxs)(`div`,{style:h,className:u,children:[(0,i.jsx)(`style`,{dangerouslySetInnerHTML:{__html:`
        @keyframes gh-shimmer {
          0% { transform: translateX(-100%); }
          100% { transform: translateX(100%); }
        }
        @keyframes gh-pulse {
          0%, 100% { opacity: 0.35; transform: scale(0.96); }
          50% { opacity: 0.75; transform: scale(1.04); }
        }
        .gh-shimmer-bg {
          animation: gh-shimmer 2.2s infinite ease-in-out;
        }
        .gh-logo-pulse {
          animation: gh-pulse 1.8s ease-in-out infinite;
        }
      `}}),!f&&(0,i.jsxs)(`div`,{style:{position:`absolute`,inset:0,display:`flex`,alignItems:`center`,justifyContent:`center`,backgroundColor:`#f8fafc`,overflow:`hidden`,zIndex:1},children:[(0,i.jsx)(`div`,{className:`gh-shimmer-bg`,style:{position:`absolute`,inset:0,background:`linear-gradient(90deg, transparent, rgba(255,255,255,0.6), transparent)`}}),(0,i.jsxs)(`span`,{className:`gh-logo-pulse`,style:{fontSize:`11px`,fontWeight:900,letterSpacing:`-0.05em`,color:`#cbd5e1`,userSelect:`none`,fontFamily:`sans-serif`},children:[`GetHotelStays`,(0,i.jsx)(`span`,{style:{color:`#2563eb`},children:`.`})]})]}),(0,i.jsx)(`img`,{ref:m,src:_,alt:t,width:n,height:o,className:u,style:{...g,...d.style},onLoad:()=>p(!0),loading:c?`eager`:`lazy`,decoding:`async`,...d})]})};export{o as t};